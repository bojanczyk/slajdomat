/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/common/animate-params.ts":
/*!**************************************!*\
  !*** ./src/common/animate-params.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.currentParams = exports.modifyingEvents = void 0;
// returns the events that modify the given id, and occur < the given index
// the xy property is modified by animate events, while the opacity property is modified by show/hide events. Evenentually, animate events will also modify the opacity, but this is not implemented yet.
function modifyingEvents(id, index, events) {
    const retval = {
        xy: 'not modified',
        opacity: 'not modified'
    };
    for (let i = 0; i < events.length; i++) {
        const event = events[i];
        if (event.type == 'animate' && event.id == id) {
            if (i < index)
                retval.xy = event;
            else if (retval.xy == 'not modified')
                retval.xy = 'original';
        }
        if ((event.type == 'show' || event.type == 'hide') && event.id == id) {
            if (i < index)
                retval.opacity = event;
            else if (retval.opacity == 'not modified')
                if (event.type == 'show')
                    retval.opacity = 'before first show';
                else
                    retval.opacity = 'before first hide';
        }
    }
    return retval;
}
exports.modifyingEvents = modifyingEvents;
// returns the animation parameters, i.e. opacity and xy, for the svg with id id, after executing all overlays with position < index
// if the event is hidden, then the hiddenOpacity is used
// we pass the list of events and the original parameters
function currentParams(id, index, events, originalParams, hiddenOpacity) {
    const retval = {};
    const modifying = modifyingEvents(id, index, events);
    switch (modifying.xy) {
        case 'not modified':
            break;
        case 'original':
            retval.x = originalParams[id].x;
            retval.y = originalParams[id].y;
            break;
        default:
            retval.x = modifying.xy.params.x;
            retval.y = modifying.xy.params.y;
    }
    let mode;
    switch (modifying.opacity) {
        case 'not modified':
            break;
        case 'before first show':
            mode = 'hidden';
            break;
        case 'before first hide':
            mode = 'visible';
            break;
        default:
            if (modifying.opacity.type == 'show')
                mode = 'visible';
            else
                mode = 'hidden';
    }
    if (mode == 'hidden') {
        retval.opacity = hiddenOpacity;
    }
    if (mode == 'visible') {
        if (originalParams[id] != undefined && originalParams[id].opacity != undefined)
            retval.opacity = originalParams[id].opacity;
        else
            retval.opacity = 1;
    }
    return retval;
}
exports.currentParams = currentParams;


/***/ }),

/***/ "./src/common/helper.ts":
/*!******************************!*\
  !*** ./src/common/helper.ts ***!
  \******************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.toAlphaNumeric = exports.freshRect = exports.sanitize = exports.freshName = void 0;
//gives a name, starting with base, which is not on the avoid list
function freshName(base, avoid) {
    let candidate = base;
    if (avoid.indexOf(candidate) > -1) {
        //we need to decorate the name;
        let index = 2;
        do {
            candidate = base + index.toString();
            index++;
        } while (avoid.indexOf(candidate) > -1);
    }
    return candidate;
}
exports.freshName = freshName;
//finds a place for the new slide, by searching in a spiral around the current slide (or the origin, if there is no current slide)
function freshRect(x, y, width, height, avoidList, dimensions) {
    let insideFrame;
    //this is the frame that we should stay inside
    if (dimensions != undefined)
        insideFrame = { x: 0, y: 0, width: dimensions.width, height: dimensions.height };
    let initial = { x: x, y: y, width: width, height: height };
    function intersects(a, b) {
        if (b == undefined)
            return true;
        if (a.x > b.x + b.width || a.x + a.width < b.x)
            return false;
        if (a.y > b.y + b.height || a.y + a.height < b.y)
            return false;
        return true;
    }
    //search for free space below the current slide,
    //using the city metric (i.e. the search follows a square spiral pattern) 
    const xoffset = width * 1.1;
    const yoffset = height * 1.1;
    for (let i = 0; true; i++)
        for (let j = 0; j <= i; j++) {
            let candidates = [];
            candidates.push({ width: initial.width, height: initial.height, x: initial.x + j * xoffset, y: initial.y + i * yoffset });
            candidates.push({ width: initial.width, height: initial.height, x: initial.x + i * xoffset, y: initial.y + j * yoffset });
            candidates.push({ width: initial.width, height: initial.height, x: initial.x - j * xoffset, y: initial.y + i * yoffset });
            candidates.push({ width: initial.width, height: initial.height, x: initial.x - i * xoffset, y: initial.y + j * yoffset });
            let someFits = false;
            for (const candidate of candidates) {
                if (intersects(candidate, insideFrame)) {
                    someFits = true;
                    let intersectsAvoidList = false;
                    for (const avoid of avoidList) {
                        if (intersects(candidate, avoid))
                            intersectsAvoidList = true;
                    }
                    if (!intersectsAvoidList)
                        return candidate;
                }
            }
            if (!someFits)
                return initial;
        }
}
exports.freshRect = freshRect;
function toAlphaNumeric(s) {
    return s.replace(/[^a-zA-Z0-9]/g, '_');
}
exports.toAlphaNumeric = toAlphaNumeric;
//sanitize a string so that it is a good filename 
function sanitize(s) {
    const replaces = [
        [':', '_colon'],
        ['%20', '_'],
        ['%', '_percent'],
        ['*', '_star'],
        ['?', '_question']
    ];
    let retval = encodeURI(s);
    for (const replace of replaces)
        retval = retval.replace(replace[0], replace[1]);
    return retval;
}
exports.sanitize = sanitize;


/***/ }),

/***/ "./src/plugin/code-child-events.ts":
/*!*****************************************!*\
  !*** ./src/plugin/code-child-events.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


/* This file contains the code for creating child events in a slide. */
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.createThumbnail = exports.createNewSlide = exports.createChildEvent = void 0;
const helper_1 = __webpack_require__(/*! ../common/helper */ "./src/common/helper.ts");
const code_1 = __webpack_require__(/*! ./code */ "./src/plugin/code.ts");
const code_name_management_1 = __webpack_require__(/*! ./code-name-management */ "./src/plugin/code-name-management.ts");
const code_thumbnails_1 = __webpack_require__(/*! ./code-thumbnails */ "./src/plugin/code-thumbnails.ts");
Object.defineProperty(exports, "createThumbnail", ({ enumerable: true, get: function () { return code_thumbnails_1.createThumbnail; } }));
//Creates a new slide of given width and height. The place for the new slide is chosen to be close to the current slide.
function createNewSlide(width, height, name) {
    let basex, basey = 0;
    try {
        basex = code_1.state.currentSlide.x;
        basey = code_1.state.currentSlide.y;
    }
    catch (e) {
        //the slide might not be defined, or defined and removed
        basex = 0;
        basey = 0;
    }
    const place = (0, helper_1.freshRect)(basex, basey, width, height, (0, code_1.allSlides)(), undefined);
    const newSlide = figma.createFrame();
    newSlide.name = name;
    newSlide.x = place.x;
    newSlide.y = place.y;
    newSlide.resize(width, height);
    const id = (0, helper_1.freshName)((0, helper_1.toAlphaNumeric)(newSlide.name), (0, code_name_management_1.avoidList)(undefined));
    const database = {
        name: newSlide.name,
        id: id,
        selected: undefined,
        events: [],
        originalParams: {}
    };
    newSlide.setPluginData("database", JSON.stringify(database));
    return newSlide;
}
exports.createNewSlide = createNewSlide;
//Creates a child event in the current slide, together with a child link (as described in the previous function) that represents the child. 
function createChildEvent(id) {
    const slide = (0, code_1.findSlide)(id);
    const newEvent = {
        type: "child",
        id: id,
        name: slide.name,
        enabled: 'enabled',
        merged: false,
        children: [],
        keywords: [],
        eventId: (0, code_name_management_1.newEventId)(),
        originalParams: undefined
    };
    const newplace = (0, helper_1.freshRect)(slide.width / 2, slide.height / 2, 100, 100 * slide.height / slide.width, code_1.state.currentSlide.children, code_1.state.currentSlide);
    const thumbnail = (0, code_thumbnails_1.createThumbnail)(code_1.state.currentSlide, id, newplace);
    figma.currentPage.selection = [thumbnail];
    return [newEvent];
}
exports.createChildEvent = createChildEvent;


/***/ }),

/***/ "./src/plugin/code-name-management.ts":
/*!********************************************!*\
  !*** ./src/plugin/code-name-management.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.slideId = exports.overlayId = exports.newEventId = exports.goodName = exports.findSlide = exports.avoidList = exports.allTexts = void 0;
const helper_1 = __webpack_require__(/*! ../common/helper */ "./src/common/helper.ts");
const code_1 = __webpack_require__(/*! ./code */ "./src/plugin/code.ts");
const code_overlay_events_1 = __webpack_require__(/*! ./code-overlay-events */ "./src/plugin/code-overlay-events.ts");
//find a slide in the document with the given id
function findSlide(id) {
    for (const node of (0, code_1.allSlides)())
        if (slideId(node) == id)
            return node;
    return null;
}
exports.findSlide = findSlide;
//returns a unique id for an event, inside the current slide
function newEventId() {
    //the id is a number (stored as a string). In order to achieve uniqueness, we store the maximal id used so far inside the attribute eventId.
    let retval;
    const maxId = code_1.state.currentSlide.getPluginData('eventId');
    if (maxId == '')
        retval = 1;
    else
        retval = parseInt(maxId) + 1;
    code_1.state.currentSlide.setPluginData('eventId', retval.toString());
    return retval.toString();
}
exports.newEventId = newEventId;
//give the list of all texts used in descendants
//this function is used in goodName below, and also to export keywords
function allTexts(n, avoid = []) {
    if (avoid.includes(n))
        return [];
    if (n.type == 'TEXT') {
        return [n.name];
    }
    if (n.type == 'GROUP' || n.type == 'FRAME') {
        let retval = [];
        for (const child of n.children) {
            retval = retval.concat(allTexts(child, avoid));
        }
        return retval;
    }
    //otherwise there are no strings
    return [];
}
exports.allTexts = allTexts;
//Creates a descriptive string name for a node. It will be called if the node is a group node with a name like "Group 2". The current implementation returns the contents the longest text node in the descendants. 
function goodName(node) {
    const texts = allTexts(node);
    //if there is no text, do not change the name
    if (texts.length == 0)
        return node.name;
    //otherwise, return the longest text    
    let retval = texts[0];
    for (const text of texts) {
        if (text.length > retval.length)
            retval = text;
    }
    return retval;
}
exports.goodName = goodName;
// I use my own id's, instead of those of figma, so that copy and paste between presentations works
//the id for a slide is stored in its database
function slideId(slide) {
    const database = (0, code_1.getDatabase)(slide);
    if (database != undefined)
        return database.id;
    else
        return undefined;
}
exports.slideId = slideId;
//list of id's to avoid when creating a new id in a slide
/*If the argument is defined, then we are generating an id for an event inside slideWithEvent. If it is undefined then we are generating an id for slide. The conflicts to be avoided are: 1. two id's in the same slide; 2. an event id with a slide id anywhere; 3. two slide id's. */
function avoidList(slideWithEvent) {
    const avoid = [];
    //we definitely want to avoid conflicts with all slide id's
    for (const slide of (0, code_1.allSlides)())
        avoid.push(slideId(slide));
    //we want to avoid avoid conflicts with event id's in the list slides, which is either a singleton [slideWithEvent] if we are generating an id for an event inside slideEvent, or otherwise all slides.
    let slides = [];
    if (slideWithEvent != undefined)
        slides.push(slideWithEvent);
    else
        slides = (0, code_1.allSlides)();
    for (const slide of slides)
        for (const child of slide.children)
            avoid.push(child.getPluginData('id'));
    return avoid;
}
exports.avoidList = avoidList;
//returns an id for an overlay, creating a new one if necessary, and fixing the old one if necessary
// the output is always defined, since a new id is created if necessary
function overlayId(node) {
    if (!(0, code_overlay_events_1.canBeOverlayTarget)(node))
        return undefined;
    let retval = node.getPluginData('id');
    const slide = node.parent;
    if (retval != '') {
        //check if the proposed id is already present in the current slide. This can happen if a node is copied by the user, then the plugin data is also copied, which includes the id, thus leading to duplicate id's 
        //tells us if node x is older than node y
        function olderNode(x, y) {
            //figma id's store a number, such as 12:35, where 12 identifies the frame, and 35 identifies the child. In this case, the value of 12 is fixed, so we compare the value of 35, which grows as the objects get newer. 
            if (x.id.length == y.id.length)
                return (x.id < y.id);
            else
                return (x.id.length < y.id.length);
        }
        for (const other of slide.children) {
            if ((olderNode(other, node)) && (other.getPluginData('id') == retval)) {
                retval = '';
            }
        }
    }
    if (retval == '') {
        //generate a new id, because the id is empty. It could be empty because of the above deduplication code.
        retval = (0, helper_1.freshName)((0, helper_1.toAlphaNumeric)(node.name), avoidList(slide));
        //save the name in the node
        node.setPluginData('id', retval);
    }
    return retval;
}
exports.overlayId = overlayId;


/***/ }),

/***/ "./src/plugin/code-overlay-events.ts":
/*!*******************************************!*\
  !*** ./src/plugin/code-overlay-events.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.createOverlayEvent = exports.canBeOverlayTarget = void 0;
const code_1 = __webpack_require__(/*! ./code */ "./src/plugin/code.ts");
const code_name_management_1 = __webpack_require__(/*! ./code-name-management */ "./src/plugin/code-name-management.ts");
//says if the node is a possible target for a show/hide event
function canBeOverlayTarget(node) {
    if (node.parent != code_1.state.currentSlide || node.getPluginData('childLink') != '')
        return false;
    return true;
}
exports.canBeOverlayTarget = canBeOverlayTarget;
//creates an overlay event in the current slide
function createOverlayEvent(type) {
    const retval = [];
    // we are creating an overlay event
    //we first sort the listed items, in an order that is more convenient for the user
    let sorted = [];
    //we look at the set of x values and y values of the selected objects, to determine if this set is more vertical or more horizontal, so that we can determine the sorting order
    const xarray = [];
    const yarray = [];
    for (const item of figma.currentPage.selection) {
        if (canBeOverlayTarget(item)) {
            xarray.push(item.x);
            yarray.push(item.y);
            sorted.push(item);
        }
    }
    //dx is the maximal difference between x coordinates, likewise for dy
    const dx = Math.max(...xarray) - Math.min(...xarray);
    const dy = Math.max(...yarray) - Math.min(...yarray);
    //the events are sorted by x or y depending on which of dx, dy is bigger
    const sortIndex = (a) => {
        if (dx > dy)
            return a.x;
        else
            return a.y;
    };
    //the order of events is so that it progresses in the down-right direction
    sorted = sorted.sort((a, b) => sortIndex(a) - sortIndex(b));
    // for each element in the sorted list of events, we create an overlay event
    for (const item of sorted) {
        let newEvent;
        if (item.type === 'GROUP' && item.name.startsWith('Group')) {
            //improve the name
            item.name = (0, code_name_management_1.goodName)(item);
        }
        const id = (0, code_name_management_1.overlayId)(item);
        switch (type) {
            case 'show':
            case 'hide':
                if ('opacity' in item) {
                    if (code_1.state.database.originalParams[id] == undefined)
                        code_1.state.database.originalParams[id] = { opacity: item.opacity };
                    if (code_1.state.database.originalParams[id].opacity == undefined) {
                        // this will happen if the object was created with an animate event, and therefore it only had an x/y parameter initially
                        code_1.state.database.originalParams[id].opacity = item.opacity;
                    }
                    newEvent =
                        {
                            type: type,
                            id: id,
                            enabled: 'enabled',
                            name: item.name,
                            merged: false,
                            keywords: [],
                            eventId: (0, code_name_management_1.newEventId)()
                        };
                }
                break;
            case 'animate':
                const params = { x: item.x, y: item.y };
                if (code_1.state.database.originalParams[id] == undefined)
                    code_1.state.database.originalParams[id] = Object.assign({}, params);
                if (code_1.state.database.originalParams[id].x == undefined) {
                    // this will happen if the object was created with a show/hide event, and therefore it only had an opacity parameter initially
                    code_1.state.database.originalParams[id].x = item.x;
                    code_1.state.database.originalParams[id].y = item.y;
                }
                newEvent =
                    {
                        type: 'animate',
                        id: id,
                        enabled: 'enabled',
                        name: item.name,
                        merged: false,
                        keywords: [],
                        eventId: (0, code_name_management_1.newEventId)(),
                        params: params
                    };
                break;
        }
        retval.push(newEvent);
    }
    return retval;
}
exports.createOverlayEvent = createOverlayEvent;


/***/ }),

/***/ "./src/plugin/code-settings.ts":
/*!*************************************!*\
  !*** ./src/plugin/code-settings.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.sendSettings = exports.pluginSettings = exports.initSettings = exports.getLatexSettings = void 0;
const code_1 = __webpack_require__(/*! ./code */ "./src/plugin/code.ts");
const plugin_version_1 = __webpack_require__(/*! ./plugin-version */ "./src/plugin/plugin-version.ts");
//the plugin settings
let pluginSettings;
exports.pluginSettings = pluginSettings;
//get the settings from the ui
function getLatexSettings(settings) {
    exports.pluginSettings = pluginSettings = settings;
    figma.clientStorage.setAsync('slajdomat', JSON.stringify(settings));
    sendSettings();
}
exports.getLatexSettings = getLatexSettings;
//send the settings to the ui
function sendSettings() {
    (0, code_1.sendToUI)({
        type: 'settings',
        settings: pluginSettings
    });
}
exports.sendSettings = sendSettings;
//initialize the settings for the plugin
function initSettings() {
    (0, plugin_version_1.upgradeVersion)();
    figma.clientStorage.getAsync('slajdomat').then(x => {
        //the default plugin settings
        const defaultSettings = {
            words: ['∀', '∃', '∧', '∨', '∈'],
            active: false,
            mathFont: {
                family: 'STIXGeneral',
                style: 'Regular'
            },
            mathFontSize: 1,
            serverURL: 'http://localhost:3001',
            latexitURL: 'https://latex.codecogs.com/svg.latex?'
        };
        try {
            exports.pluginSettings = pluginSettings = Object.assign(Object.assign({}, defaultSettings), JSON.parse(x));
        }
        catch (e) {
            exports.pluginSettings = pluginSettings = defaultSettings;
        }
        sendSettings();
        (0, code_1.selChange)();
    });
}
exports.initSettings = initSettings;


/***/ }),

/***/ "./src/plugin/code-thumbnails.ts":
/*!***************************************!*\
  !*** ./src/plugin/code-thumbnails.ts ***!
  \***************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.updateThumbnails = exports.createThumbnail = void 0;
const code_1 = __webpack_require__(/*! ./code */ "./src/plugin/code.ts");
// this is the colour that will be used for the thumbnail frame, and also for its fill when the thumbnail is not available
const redColor = {
    type: 'SOLID',
    color: {
        r: 1,
        g: 0,
        b: 0
    }
};
// creates a thumbnail of slide targetSlideId and places it in the current slide in the position where
function createThumbnail(sourceSlide, targetSlideId, where) {
    const targetSlide = (0, code_1.findSlide)(targetSlideId);
    // red semi-transparent rectangle, which will be later filled with the thumbnail
    const rectNode = figma.createRectangle();
    rectNode.resize(where.width, where.width);
    rectNode.x = where.x;
    rectNode.y = where.y;
    rectNode.opacity = 0.5;
    rectNode.setPluginData('thumbnail', 'yes');
    code_1.state.currentSlide.appendChild(rectNode);
    // a red frame, which will stay even when the thumbnail appears
    const frameNode = figma.createRectangle();
    frameNode.resize(where.width, where.width);
    frameNode.x = where.x;
    frameNode.y = where.y;
    frameNode.fills = [];
    frameNode.strokes = [redColor];
    code_1.state.currentSlide.appendChild(frameNode);
    //  a group with the nodes
    const groupNode = figma.group([rectNode, frameNode], code_1.state.currentSlide);
    groupNode.setPluginData("childLink", targetSlideId);
    groupNode.expanded = false;
    // this creates the actual picture. it is separate code, since it will be called later when the thumbnail is updated but the rectagles created here stay the same
    updateThumbnail(rectNode, targetSlide);
    return groupNode;
}
exports.createThumbnail = createThumbnail;
function updateThumbnail(rect, slide) {
    return __awaiter(this, void 0, void 0, function* () {
        if (slide == undefined || slide.removed) {
            // the target slide has been removed
            rect.fills = [redColor];
        }
        else {
            // the target slide exists, so we can generate a thumbnail
            const image = figma.createImage(yield slide.exportAsync({
                format: 'PNG'
            }));
            rect.fills = [
                {
                    type: 'IMAGE',
                    imageHash: image.hash,
                    scaleMode: 'FILL'
                }
            ];
        }
    });
}
//update the thumbnails for slide children
function updateThumbnails() {
    return __awaiter(this, void 0, void 0, function* () {
        const nodes = code_1.state.currentSlide.findAll((node) => node.getPluginData("childLink") != '');
        for (const child of nodes) {
            const slide = (0, code_1.findSlide)(child.getPluginData('childLink'));
            //if the child link was created in an old version of Slajdomat, then it is simply a rectangle. In this case it needs to be upgraded to a new version, where it is a group containing two rectangles.
            if (child.type == 'RECTANGLE') {
                const where = { width: child.width, height: child.height, x: child.x, y: child.y };
                child.remove();
                createThumbnail(code_1.state.currentSlide, (0, code_1.slideId)(slide), where);
            }
            let rect;
            //finds the rectangle where the thumbnail should go; this is indicated by plugin data
            if (child.type == 'GROUP') {
                for (const grandchild of child.children)
                    if (grandchild.getPluginData('thumbnail')) {
                        rect = grandchild;
                    }
            }
            //if such a rectangle has been found, then its fill should be replaced with the thumbnail
            if (rect != null) {
                updateThumbnail(rect, slide);
            }
        }
    });
}
exports.updateThumbnails = updateThumbnails;


/***/ }),

/***/ "./src/plugin/code-timeline.ts":
/*!*************************************!*\
  !*** ./src/plugin/code-timeline.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


/* This is code for the plugin backend that manages the timeline of the presentation. It takes care of updating the opacity and xy values of figma elements as the user clicks on the timeline in the plugin.
*/
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.loadAnimationParams = exports.saveAnimationParams = void 0;
const animate_params_1 = __webpack_require__(/*! ../common/animate-params */ "./src/common/animate-params.ts");
const code_1 = __webpack_require__(/*! ./code */ "./src/plugin/code.ts");
const code_name_management_1 = __webpack_require__(/*! ./code-name-management */ "./src/plugin/code-name-management.ts");
// the x and y values go to the animate events, and the opacity goes to original parameters
function saveAnimationParams() {
    const haveEvents = idsThatHaveEvents();
    // remove the unused keys from the originalParams dictionary
    for (const key of Object.keys(code_1.state.database.originalParams)) {
        if (!haveEvents.has(key))
            delete code_1.state.database.originalParams[key];
    }
    for (const node of code_1.state.currentSlide.children) {
        const id = (0, code_name_management_1.overlayId)(node);
        if (haveEvents.has(id)) {
            // the id has events
            // we need to find the appropriate place to store the animation parameters, which may be an event, or otherwise the originalParams dictionary
            const modifying = (0, animate_params_1.modifyingEvents)(id, code_1.state.database.selected, code_1.state.database.events);
            if (modifying.xy != 'not modified' || modifying.opacity != 'not modified') {
                if (code_1.state.database.originalParams[id] == undefined)
                    code_1.state.database.originalParams[id] = {};
            }
            switch (modifying.xy) {
                case 'original':
                    code_1.state.database.originalParams[id].x = node.x;
                    code_1.state.database.originalParams[id].y = node.y;
                    break;
                case 'not modified':
                    break;
                default:
                    modifying.xy.params.x = node.x;
                    modifying.xy.params.y = node.y;
            }
            // the opacity is saved to the original parameters if it is modified, and the last show/hide event is not hide
            if ('opacity' in node) {
                switch (modifying.opacity) {
                    case 'not modified':
                    case 'before first show':
                        break;
                    default:
                        if (modifying.opacity == 'before first hide' || modifying.opacity.type == 'show') {
                            code_1.state.database.originalParams[id].opacity = node.opacity;
                        }
                }
            }
        }
    }
}
exports.saveAnimationParams = saveAnimationParams;
function idsThatHaveEvents() {
    const idsThatHaveEvents = new Set();
    for (const event of code_1.state.database.events) {
        if (event.type != 'child')
            idsThatHaveEvents.add(event.id);
    }
    return idsThatHaveEvents;
}
// the opposite of the previous function
function loadAnimationParams() {
    // a little optimization, not sure if necessary: we will only look at ids of objects that have some overlay associated to them
    const haveEvents = idsThatHaveEvents();
    for (const id of haveEvents) {
        for (const node of code_1.state.currentSlide.children) {
            if ((0, code_name_management_1.overlayId)(node) == id) {
                // the last argument is 0.1, since we want hidden events to be a bit visible
                const params = (0, animate_params_1.currentParams)(id, code_1.state.database.selected, code_1.state.database.events, code_1.state.database.originalParams, 0.1);
                if ('x' in params) {
                    node.x = params.x;
                    node.y = params.y;
                }
                if (params.opacity != undefined && 'opacity' in node) {
                    node.opacity = params.opacity;
                }
            }
        }
    }
}
exports.loadAnimationParams = loadAnimationParams;


/***/ }),

/***/ "./src/plugin/code.ts":
/*!****************************!*\
  !*** ./src/plugin/code.ts ***!
  \****************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


/*
// This is the backend of the plugin. It edits the figma artboard. It sends messages to the frontend (in the file src/plugin/ui.ts), which handles user interaction and the contents of the plugin window.
*/
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.state = exports.slideId = exports.sendToUI = exports.selChange = exports.saveCurrentData = exports.loadCurrentData = exports.getRoot = exports.getDatabase = exports.findSlide = exports.findOverlayNodeById = exports.findEventObject = exports.deleteHoverFrames = exports.allSlides = void 0;
const code_child_events_1 = __webpack_require__(/*! ./code-child-events */ "./src/plugin/code-child-events.ts");
const code_name_management_1 = __webpack_require__(/*! ./code-name-management */ "./src/plugin/code-name-management.ts");
Object.defineProperty(exports, "findSlide", ({ enumerable: true, get: function () { return code_name_management_1.findSlide; } }));
Object.defineProperty(exports, "slideId", ({ enumerable: true, get: function () { return code_name_management_1.slideId; } }));
const code_overlay_events_1 = __webpack_require__(/*! ./code-overlay-events */ "./src/plugin/code-overlay-events.ts");
const code_settings_1 = __webpack_require__(/*! ./code-settings */ "./src/plugin/code-settings.ts");
const code_thumbnails_1 = __webpack_require__(/*! ./code-thumbnails */ "./src/plugin/code-thumbnails.ts");
const code_timeline_1 = __webpack_require__(/*! ./code-timeline */ "./src/plugin/code-timeline.ts");
const export_1 = __webpack_require__(/*! ./export */ "./src/plugin/export.ts");
const matematyk_1 = __webpack_require__(/*! ./matematyk */ "./src/plugin/matematyk.ts");
const plugin_types_1 = __webpack_require__(/*! ./plugin-types */ "./src/plugin/plugin-types.ts");
//*** global variables */
const state = {
    //the data for the current slide, mainly the event list
    database: null,
    //the current slide, as a frame of figma
    currentSlide: null,
};
exports.state = state;
function sendToUI(msg) {
    figma.ui.postMessage(msg);
}
exports.sendToUI = sendToUI;
//send the  list which says what are the possible candidates for child slides. 
function sendDropDownList() {
    const msg = {
        type: 'dropDownContents',
        slides: []
    };
    for (const node of allSlides())
        if (node != state.currentSlide) {
            let alreadyChild = false;
            for (const e of state.database.events) {
                if (e.type == "child" && e.id == (0, code_name_management_1.slideId)(node)) {
                    alreadyChild = true;
                }
            }
            if (!alreadyChild)
                msg.slides.push({
                    name: node.name,
                    id: (0, code_name_management_1.slideId)(node)
                });
        }
    sendToUI(msg);
}
//send the event list of the current slide
function sendEventList() {
    //the slide might be removed
    if (state.currentSlide != null && !state.currentSlide.removed) {
        cleanDatabase();
        sendToUI({
            type: 'eventList',
            events: state.database.events,
            selected: state.database.selected
        });
    }
}
// create new event 
//msg.id is used for the 'child' event
function createEvent(eventInfo) {
    (0, code_timeline_1.saveAnimationParams)();
    let createdEvents;
    if (eventInfo.subtype == 'child') {
        // we are creating a child event
        if (eventInfo.id == null) {
            const newSlide = (0, code_child_events_1.createNewSlide)(state.currentSlide.width, state.currentSlide.height, eventInfo.name);
            eventInfo.id = (0, code_name_management_1.slideId)(newSlide);
        }
        createdEvents = (0, code_child_events_1.createChildEvent)(eventInfo.id);
    }
    else {
        //we are creating an overlay event
        createdEvents = (0, code_overlay_events_1.createOverlayEvent)(eventInfo.subtype);
    }
    // insert the new event into the database, at position selected
    for (const newEvent of createdEvents) {
        state.database.events.splice(state.database.selected, 0, newEvent);
        state.database.selected++;
    }
    saveCurrentData();
    console.log('before load animation params', JSON.stringify(state.database));
    (0, code_timeline_1.loadAnimationParams)();
    console.log('after load animation params', JSON.stringify(state.database));
    sendEventList();
}
//remove an event from the current event list
function removeEvent(index) {
    (0, code_timeline_1.saveAnimationParams)();
    const event = state.database.events[index];
    if (event.type == "child") {
        const rect = findEventObject(event, state.currentSlide);
        if (rect != null)
            rect.remove();
    }
    if (state.database.selected > index)
        state.database.selected--;
    state.database.events.splice(index, 1);
    saveCurrentData();
    (0, code_timeline_1.loadAnimationParams)();
    sendEventList();
}
//merge or de-merge an event with the previous one 
function mergeEvent(index) {
    const event = state.database.events[index];
    event.merged = !event.merged;
    saveCurrentData();
    sendEventList();
}
//change order of event list so that source becomes target. The source and target are counted among merged blocks of events
function reorderEvents(sourceBlock, targetBlock) {
    (0, code_timeline_1.saveAnimationParams)();
    //the source is a block, and so is the target
    const blockStarts = [];
    let i;
    for (i = 0; i < state.database.events.length; i++) {
        if (state.database.events[i].merged == false)
            blockStarts.push(i);
    }
    blockStarts.push(i);
    const source = blockStarts[sourceBlock];
    const target = blockStarts[targetBlock];
    const sourceCount = blockStarts[sourceBlock + 1] - source;
    const targetCount = blockStarts[targetBlock + 1] - target;
    let realTarget;
    if (source > target) {
        realTarget = target;
    }
    else {
        realTarget = target + targetCount - sourceCount;
    }
    const block = state.database.events.splice(source, sourceCount);
    while (block.length > 0) {
        state.database.events.splice(realTarget, 0, block.pop());
    }
    saveCurrentData();
    (0, code_timeline_1.loadAnimationParams)();
    sendEventList();
}
// this function is clicked when the user clicks on the animate bar
function clickAnimateBar(newIndex) {
    if (newIndex == state.database.selected)
        return;
    deleteHoverFrames();
    (0, code_timeline_1.saveAnimationParams)();
    state.database.selected = newIndex;
    saveCurrentData();
    (0, code_timeline_1.loadAnimationParams)();
    sendEventList();
}
//these frames are displayed when the mouse hovers over an event. In principle, there should be at most one, but for some reason the delete events are not matched with the create events, and therefore I keep a list of all frames, and delete all of them.
const hoverFrames = [];
//deletes all hover frames
function deleteHoverFrames() {
    while (hoverFrames.length > 0)
        hoverFrames.pop().remove();
}
exports.deleteHoverFrames = deleteHoverFrames;
//when the mouse hovers over an event, then it should be highlighted a little frame
function hoverEvent(index) {
    if (index == -1) {
        //if the index is -1, then the mouse has left, and the frames should be deleted
        deleteHoverFrames();
    }
    else {
        //otherwise, the index says which event is hovered over. It will be surrounded by a frame
        const event = state.database.events[index];
        const link = findEventObject(event, state.currentSlide);
        if (link != null) {
            const margin = 20;
            // create a hover frame
            const hoverFrame = figma.createRectangle();
            hoverFrame.resize(link.width + 2 * margin, link.height + 2 * margin);
            hoverFrame.x = link.x - margin;
            hoverFrame.y = link.y - margin;
            hoverFrame.fills = [{
                    type: 'SOLID',
                    color: {
                        r: 173 / 255,
                        g: 216 / 255,
                        b: 230 / 255
                    }
                }];
            hoverFrame.name = 'slajdomat selection';
            hoverFrame.opacity = 0.5;
            // make the hoverframe be behind everything
            state.currentSlide.insertChild(0, hoverFrame);
            hoverFrames.push(hoverFrame);
        }
    }
}
//code that is run when the plugin is closed
function closePlugin() {
    deleteHoverFrames();
}
//if the event on a plugin is clicked, then the corresponding object in figma should be selected
function clickEvent(index) {
    const event = state.database.events[index];
    if (event.type == 'child') {
        gotoSlide((0, code_name_management_1.findSlide)(event.id));
    }
}
// save the plugin data, for the current slide, to the file
function saveCurrentData() {
    state.database.name = state.currentSlide.name;
    state.currentSlide.setPluginData("database", JSON.stringify(state.database));
}
exports.saveCurrentData = saveCurrentData;
// the opposite of the previous function
function loadCurrentData(slide) {
    state.currentSlide = slide;
    state.database = getDatabase(state.currentSlide);
    cleanDatabase();
}
exports.loadCurrentData = loadCurrentData;
function fixVersion(database) {
    if (database.originalParams == undefined)
        database.originalParams = {};
}
//get the database for a slide
function getDatabase(slide) {
    const s = slide.getPluginData("database");
    if (s == '')
        return undefined;
    else {
        const parsed = JSON.parse(s);
        fixVersion(parsed);
        return parsed;
    }
}
exports.getDatabase = getDatabase;
//a node is a slide if it contains a database
function isSlideNode(node) {
    if (node == null)
        return false;
    return (getDatabase(node) != null);
}
//return the list of all slides
function allSlides() {
    const retval = [];
    for (const node of figma.currentPage.children) {
        if (isSlideNode(node))
            retval.push(node);
    }
    return retval;
}
exports.allSlides = allSlides;
//find an node in the current slicde with the given id
function findOverlayNodeById(id, slide) {
    for (const child of slide.children)
        if (id == (0, code_name_management_1.overlayId)(child))
            return child;
}
exports.findOverlayNodeById = findOverlayNodeById;
//Gives the object in the slide that corresponds to the event. For a show/hide event this is the node that is shown/hidden. For a child event, this is the link to the child.
function findEventObject(event, slide) {
    if (event.type == 'child') {
        //find the object in the current slide, which represents a link to a child slide. This object is indicated by plugin data. Currently, it is a semi-transparent red rectangle.
        const nodes = slide.findAll((node) => node.getPluginData("childLink") == event.id);
        if (nodes.length > 0)
            return nodes[0];
    }
    else {
        // for overlay events, we search if the corresponding object exists in the current slide
        return findOverlayNodeById(event.id, slide);
    }
    return null;
}
exports.findEventObject = findEventObject;
// disable events that are not available, and fix stuff from older versions
function cleanDatabase() {
    state.database.name = state.currentSlide.name;
    // this will be called when opening the slide for the first time, or 
    // when using a slide created in older versions
    if (state.database.selected == undefined)
        state.database.selected = state.database.events.length;
    //for each event, check if it is active
    // a child event is active if the linked frame exists
    // a show/hide event is active if the linked object exists
    // for the active show/hide events, store the index of the corresponding item
    for (const event of state.database.events) {
        event.enabled = 'disabled';
        const node = findEventObject(event, state.currentSlide);
        if (node != null) {
            if (event.type == "child") {
                const f = (0, code_name_management_1.findSlide)(event.id);
                if (f != null) {
                    event.name = f.name;
                    node.name = 'link to ' + f.name;
                    event.enabled = 'enabled';
                }
            }
            if (event.type == "show" || event.type == "hide" || event.type == "animate") {
                event.name = node.name;
                event.enabled = 'enabled';
            }
        }
    }
}
//return any slide that points to slide as a child
function parentSlide(slide) {
    for (const other of allSlides()) {
        const db = getDatabase(other);
        if (db != undefined)
            for (const event of db.events)
                if (event.type == 'child' && event.id == (0, code_name_management_1.slideId)(slide))
                    return other;
    }
    return null;
}
//set the current slide of the plugin
function setCurrentSlide(slide) {
    if (slide != null) {
        loadCurrentData(slide);
        const isRoot = getRoot() == state.currentSlide;
        const msg = {
            type: 'slideChange',
            docName: figma.root.name,
            slide: state.currentSlide.name,
            isRoot: isRoot,
            slideCount: allSlides().length,
        };
        sendToUI(msg);
        sendEventList();
        (0, code_thumbnails_1.updateThumbnails)();
    }
    else {
        sendToUI({
            type: 'noSlide'
        });
    }
}
//go to a slide and show it on the screen
function gotoSlide(slide) {
    figma.viewport.scrollAndZoomIntoView([slide]);
    setCurrentSlide(slide);
}
//returns the slide with the currently selected object
function slideWithSelection() {
    const sel = figma.currentPage.selection;
    if (sel.length > 0) {
        let node = sel[0];
        while (!isSlideNode(node) && node != null)
            node = node.parent;
        return node;
    }
    else
        return null;
}
//finds the root from previous sessions
function getRoot() {
    const rootSlide = (0, code_name_management_1.findSlide)(figma.root.getPluginData('rootSlide'));
    if (rootSlide == null) {
        setRoot();
    }
    return rootSlide;
}
exports.getRoot = getRoot;
//change the root to the current slide
function setRoot() {
    figma.root.setPluginData('rootSlide', (0, code_name_management_1.slideId)(state.currentSlide));
}
//event handler for when the document has changed. We use this to re-proportion the red rectangles for the child link
function docChange(changes) {
    for (const x of changes.documentChanges) {
        if ((x.type == 'PROPERTY_CHANGE')) {
            const change = x.node;
            if ((!change.removed) && (change.getPluginData('childLink') != '')) {
                const rect = change;
                rect.resize(rect.width, rect.width * state.currentSlide.height / state.currentSlide.width);
            }
        }
    }
}
//event handler for when the selection has changed
function selChange() {
    //if there is a saved selection, this means that the change was triggered by the user hovering over the event list in the plugin, and hence it should not count
    const slide = slideWithSelection();
    //we change the current slide if it satisfies certain conditions: or the selection has moved to some other non-null slide (the selection is in a null slide if it is outside all slides) 
    if 
    //it has been removed; or
    ((state.currentSlide != null && state.currentSlide.removed) ||
        //the selection has moved to some other non-null slide; or 
        (slide != state.currentSlide && slide != null) ||
        //the name of the slide has changed
        (state.currentSlide != null && state.currentSlide == slide && state.currentSlide.name != slide.name))
        setCurrentSlide(slide);
    else if (state.currentSlide != undefined && state.database.name != state.currentSlide.name) {
        //if the name of the current slide was changed, then we also send this to the ui
        setCurrentSlide(state.currentSlide);
    }
    else if (state.currentSlide != null)
        sendEventList();
    const sel = figma.currentPage.selection;
    const msg = {
        type: 'selChange',
        selected: false,
        latexState: plugin_types_1.LatexState.None,
        canInsert: false,
        currentFont: null
    };
    for (const item of figma.currentPage.selection) {
        if ((0, code_overlay_events_1.canBeOverlayTarget)(item))
            msg.selected = true;
    }
    // this part of the code is for the math features of latexit and inserting characters
    if (sel.length == 1) {
        if (sel[0].type == "TEXT") //the selected object can be latexed
            msg.latexState = plugin_types_1.LatexState.Latex;
        if ((0, matematyk_1.matematykData)(sel[0]) != null) //the selected object can be de-latexed
            msg.latexState = plugin_types_1.LatexState.Delatex;
    }
    if (figma.currentPage.selectedTextRange != null) {
        const r = figma.currentPage.selectedTextRange.end;
        if (r > 0) {
            msg.currentFont = sel[0].getRangeFontName(r - 1, r);
        }
        msg.canInsert = true;
    }
    //send the information about the updated selection
    sendToUI(msg);
}
exports.selChange = selChange;
//handle messages that come from the ui
function onMessage(msg) {
    switch (msg.type) {
        case 'notify':
            //write a user notification
            figma.notify(msg.text);
            break;
        case 'clickAnimateBar':
            clickAnimateBar(msg.index);
            break;
        case 'createEvent':
            //create a new event for the current slide
            //this covers show/hide/child events
            createEvent(msg);
            break;
        case 'settings':
            //get settings from the interface
            (0, code_settings_1.getLatexSettings)(msg.pluginSettings);
            break;
        case 'removeEvent':
            //remove an event
            removeEvent(msg.index);
            break;
        case 'mergeEvent':
            //merge an event with the previous one
            mergeEvent(msg.index);
            break;
        case 'moveEvent':
            //swap the order of two events
            reorderEvents(msg.index, msg.target);
            deleteHoverFrames();
            break;
        case 'makeFirst':
            //make a first slide
            setCurrentSlide((0, code_child_events_1.createNewSlide)(msg.width, msg.height, 'new slide'));
            figma.viewport.scrollAndZoomIntoView([state.currentSlide]);
            break;
        case 'saveFile':
            //export the files to svg files
            (0, export_1.exportSlides)();
            break;
        case 'changeRoot':
            setRoot();
            break;
        case 'mouseEnterPlugin':
            // //I'm not sure if this is necessary, but just in case I refresh the event list when the mouse enters the plugin.
            // if (state.currentSlide != null)
            //     sendEventList();
            break;
        case 'hoverEvent':
            //highlight an event when the mouse hovers over it. For show/hide event we change the selection to the concerned object, for child events we do this for the link.
            hoverEvent(msg.index);
            break;
        case 'requestDropDown':
            //request a list of all slides for the current slide
            sendDropDownList();
            break;
        case 'mouseLeave':
            break;
        case 'clickEvent':
            //if an event is clicked, then the selection stays permanent
            clickEvent(msg.index);
            break;
        case 'gotoParent':
            //the parent button is clicked
            gotoSlide(parentSlide(state.currentSlide));
            break;
        case 'addWord':
            //functions for the matematyk plugin ******
            (0, matematyk_1.matematykWord)(msg.text);
            break;
        case 'latexit':
            //the user requests turning text into latex
            (0, matematyk_1.latexitOne)();
            break;
        case 'latexitTwo':
            //the second stage of latexit, is necessary because only the ui can communicate with the web
            (0, matematyk_1.latexitTwo)(msg.text);
            break;
        default:
            throw "uncovered message type sent to code: ";
    }
}
figma.on('documentchange', docChange);
figma.on("selectionchange", selChange);
figma.on('close', closePlugin);
figma.showUI(__html__, {
    width: 230,
    height: 500
});
figma.ui.onmessage = onMessage;
setCurrentSlide(slideWithSelection());
(0, code_settings_1.initSettings)();


/***/ }),

/***/ "./src/plugin/export.ts":
/*!******************************!*\
  !*** ./src/plugin/export.ts ***!
  \******************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.exportSlides = void 0;
const code_1 = __webpack_require__(/*! ./code */ "./src/plugin/code.ts");
const code_name_management_1 = __webpack_require__(/*! ./code-name-management */ "./src/plugin/code-name-management.ts");
//deduplicate a list of strings
function deDuplicate(list) {
    const retval = [];
    for (const string of list)
        if (!retval.includes(string))
            retval.push(string);
    return retval;
}
//complies a list of search keywords for the current slide
function compileKeywords(event, frame) {
    const done = [];
    for (const child of event.children) {
        //we only create keywords for show children, which are first
        if (child.type == 'show') {
            const node = (0, code_1.findEventObject)(child, frame);
            if (!done.includes(node)) {
                done.push(node);
                child.keywords = (0, code_name_management_1.allTexts)(node);
                child.keywords.push(child.name);
                child.keywords = deDuplicate(child.keywords);
            }
        }
    }
    //the keywords for the slide itself is all other keywords that were not included above
    event.keywords = (0, code_name_management_1.allTexts)(frame, done);
    event.keywords.push(event.name);
    event.keywords = deDuplicate(event.keywords);
}
//send the svg file to the ui, which then sends it to the server
function exportSlides() {
    //in case there are some straggler blue frames, delete them
    (0, code_1.deleteHoverFrames)();
    //the list of slides and their svg files
    const slideList = [];
    //stack of the recursion, to find cycles in slides
    const stack = [];
    //Saves a single slide, and then calls itself for the children of that slide. The result of saving is a new item on slideList.
    function saveRec(slide, eventId) {
        return __awaiter(this, void 0, void 0, function* () {
            if (stack.includes(slide)) {
                let cycle = "The slides contain a cycle: \n";
                for (const n of stack)
                    cycle += (n.name + "\n");
                figma.notify(cycle + slide.name);
                return null;
            }
            else {
                stack.push(slide);
                (0, code_1.loadCurrentData)(slide);
                //We temporarily change the names of the children to their id's, so that the svg will have them as id's. (This is because Figma's svg export uses the object's name as the id for the svg. )
                //the function returns a list of pairs (node, old name) that can be used to revert these changes
                const changes = [];
                for (const event of code_1.state.database.events) {
                    const node = (0, code_1.findEventObject)(event, slide);
                    if (node != null) {
                        //we store the changes in reverse order,  so that the original names are at the end of the change list 
                        changes.unshift({
                            node: node,
                            savedName: node.name
                        });
                        node.name = event.id;
                    }
                }
                const svg = yield slide.exportAsync({
                    format: 'SVG',
                    svgOutlineText: true,
                    svgIdAttribute: true
                });
                //we now undo the name changes. This needs to be done in reverse order to recover the original names
                for (const change of changes) {
                    change.node.name = change.savedName;
                }
                // the svg might be exported at a different position than the original, so we need to offset the animation parameters
                function offsetParams(params, id) {
                    const retval = Object.assign({}, params);
                    if (retval.x == undefined)
                        return retval;
                    const node = (0, code_1.findOverlayNodeById)(id, slide);
                    if (node == undefined)
                        return undefined;
                    retval.x -= node.x;
                    retval.y -= node.y;
                    return retval;
                }
                //for export, we generate a copy of the originalParams dictionary, in which all parameters are offset
                const offsetOriginalParams = {};
                for (const id in code_1.state.database.originalParams) {
                    const afterOffset = offsetParams(code_1.state.database.originalParams[id], id);
                    offsetOriginalParams[id] = afterOffset;
                }
                const retval = {
                    type: 'child',
                    name: code_1.state.database.name,
                    id: code_1.state.database.id,
                    enabled: 'enabled',
                    merged: false,
                    children: [],
                    keywords: [],
                    eventId: eventId,
                    originalParams: offsetOriginalParams
                };
                (0, code_1.saveCurrentData)();
                slideList.push({
                    database: code_1.state.database,
                    svg: svg
                });
                for (const event of code_1.state.database.events) {
                    if (event.enabled == 'enabled') {
                        if (event.type == "child") {
                            const child = yield saveRec((0, code_1.findSlide)(event.id), event.eventId);
                            child.merged = event.merged;
                            retval.children.push(child);
                        }
                        else {
                            const copied = Object.assign({}, event);
                            copied.keywords = [copied.name];
                            // animate events need to have their parameters offset
                            if (copied.type == 'animate')
                                copied.params = offsetParams(copied.params, copied.id);
                            retval.children.push(copied);
                        }
                    }
                }
                (0, code_1.loadCurrentData)(stack.pop());
                compileKeywords(retval, code_1.state.currentSlide);
                return retval;
            }
        });
    }
    const savedSlide = code_1.state.currentSlide;
    const rootSlide = (0, code_1.getRoot)();
    if (rootSlide != null) {
        saveRec((0, code_1.getRoot)(), 'root').then(x => {
            (0, code_1.sendToUI)({
                type: 'savePresentation',
                name: figma.root.name,
                slideList: slideList,
                tree: x
            });
            (0, code_1.loadCurrentData)(savedSlide);
        });
    }
}
exports.exportSlides = exportSlides;


/***/ }),

/***/ "./src/plugin/matematyk.ts":
/*!*********************************!*\
  !*** ./src/plugin/matematyk.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.matematykWord = exports.latexitTwo = exports.latexitOne = exports.matematykData = void 0;
const code_settings_1 = __webpack_require__(/*! ./code-settings */ "./src/plugin/code-settings.ts");
// functions for matematyk **************
//inserts the word in the font STIXGeneral
let latexitSelection;
//the first stage of latexit, when we find the object to be latexed
function latexitOne() {
    if (figma.currentPage.selection.length > 0) {
        latexitSelection = figma.currentPage.selection[0];
        const data = matematykData(latexitSelection);
        if (latexitSelection.type == 'TEXT') {
            const url = code_settings_1.pluginSettings.latexitURL + encodeURIComponent(latexitSelection.characters);
            figma.ui.postMessage({
                type: 'fetchlatex',
                url: url
            });
        }
        else if (data != null) {
            const text = figma.createText();
            latexitSelection.parent.appendChild(text);
            figma.loadFontAsync(text.fontName).then(() => {
                try {
                    text.name = latexitSelection.name;
                    text.characters = data.code;
                    text.fontSize = data.fontsize;
                    text.x = latexitSelection.x;
                    text.y = latexitSelection.y;
                    latexitSelection.remove();
                    figma.currentPage.selection = [text];
                }
                catch (error) {
                    figma.notify("Could not delatex.");
                }
            });
        }
    }
}
exports.latexitOne = latexitOne;
//function returns the matematyk data for a node
function matematykData(node) {
    try {
        const str = node.getPluginData('matematyk');
        return JSON.parse(str);
    }
    catch (e) {
        return null;
    }
}
exports.matematykData = matematykData;
//the second state of latexit, when we got the svg
function latexitTwo(svg) {
    const node = figma.createNodeFromSvg(svg);
    //if we got here, then we know that the selection was text, and will be turned to svg
    const original = latexitSelection;
    const parent = figma.currentPage.selection[0].parent;
    parent.appendChild(node);
    const latexData = {
        fontsize: original.getRangeFontSize(0, 1),
        code: original.characters
    };
    node.setPluginData("matematyk", JSON.stringify(latexData));
    node.name = latexData.code;
    node.rescale(latexData.fontsize * 0.065);
    node.x = latexitSelection.x;
    node.y = latexitSelection.y;
    latexitSelection.remove();
    figma.currentPage.selection = [node];
}
exports.latexitTwo = latexitTwo;
//inserts the word w after the caret, 
function matematykWord(addedString) {
    //figma requires me to load lots of fonts before changing anything in the text field
    function loadFonts(node) {
        const len = node.characters.length;
        const fontArray = [figma.loadFontAsync(code_settings_1.pluginSettings.mathFont)];
        if (typeof node.fontName != 'symbol') //there is more than one font
         {
            fontArray.push(figma.loadFontAsync(node.fontName));
        }
        else {
            for (let i = 0; i < len; i++) {
                fontArray.push(figma.loadFontAsync(node.getRangeFontName(i, i + 1)));
            }
        }
        return Promise.all(fontArray);
    }
    //the added string should be at the front of the cache, so if it is present in the cache, then we delete it
    const index = code_settings_1.pluginSettings.words.indexOf(addedString);
    if (index != -1) // if it is in the cache
        code_settings_1.pluginSettings.words.splice(index, 1);
    code_settings_1.pluginSettings.words.push(addedString);
    (0, code_settings_1.sendSettings)();
    figma.clientStorage.setAsync('slajdomat', JSON.stringify(code_settings_1.pluginSettings));
    //add the word after the selected range 
    const range = figma.currentPage.selectedTextRange;
    if (range != null) {
        loadFonts(range.node).then(() => {
            range.node.insertCharacters(range.start, addedString + " ");
            const size = range.node.getRangeFontSize(range.start, range.start + 1);
            range.node.setRangeFontName(range.start, range.start + addedString.length, code_settings_1.pluginSettings.mathFont);
            range.node.setRangeFontSize(range.start, range.start + addedString.length, size * code_settings_1.pluginSettings.mathFontSize);
            //range.end = range.start +1;          
            figma.currentPage.selectedTextRange = {
                node: range.node,
                start: range.start + addedString.length + 1,
                end: range.start + addedString.length + 1
            };
        });
        // 
    }
}
exports.matematykWord = matematykWord;


/***/ }),

/***/ "./src/plugin/plugin-types.ts":
/*!************************************!*\
  !*** ./src/plugin/plugin-types.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.LatexState = exports.WindowMode = void 0;
//the possible modes for the plugin
var WindowMode;
(function (WindowMode) {
    WindowMode[WindowMode["Settings"] = 0] = "Settings";
    WindowMode[WindowMode["Slide"] = 1] = "Slide";
    WindowMode[WindowMode["NoSlide"] = 2] = "NoSlide";
})(WindowMode || (WindowMode = {}));
exports.WindowMode = WindowMode;
//the possible mode of the latex plugin
var LatexState;
(function (LatexState) {
    LatexState[LatexState["None"] = 0] = "None";
    LatexState[LatexState["Latex"] = 1] = "Latex";
    LatexState[LatexState["Delatex"] = 2] = "Delatex";
})(LatexState || (LatexState = {}));
exports.LatexState = LatexState;


/***/ }),

/***/ "./src/plugin/plugin-version.ts":
/*!**************************************!*\
  !*** ./src/plugin/plugin-version.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.upgradeVersion = void 0;
const code_1 = __webpack_require__(/*! ./code */ "./src/plugin/code.ts");
// import { version as versionNumber } from '../..//package.json';
//this function upgrades the data to the current version of the plugin. I expect the function to grow into a total mess.
// currently the version progression is 
// empty: original version
// 0.81: the id's are not from figma, and there is a merged property for events
function upgradeVersion() {
    const storedVersion = parseFloat(figma.root.getPluginData('version'));
    /*
    //we upgrade incrementally, version after version
    if (storedVersion == '') {
        for (const slide of allSlides()) {
            //in old versions, the merged attribute did not exist
            const database :Database = getDatabase(slide);
            for (const event of database.events) {
                if (event.merged == undefined) {
                    event.merged = false;
                }
            }

            for (const event of database.events) {
                for (const child of slide.children)
                {
                    if (event.id == child.id)
                        child.setPluginData('id',event.id)

                }
            }

        }
        console.log('Upgraded to slajdomat data version 0.81');
        figma.root.setPluginData('version', '0.81');
    }
    */
    if (storedVersion < 0.88) {
        //before this version, there was no eventId attribute
        const savedSlide = code_1.state.currentSlide;
        for (const slide of (0, code_1.allSlides)()) {
            //in old versions, the eventId attribute did not exist
            (0, code_1.loadCurrentData)(slide);
            let i = -1;
            for (const event of code_1.state.database.events) {
                i++;
                event.eventId = i.toString();
            }
            code_1.state.currentSlide.setPluginData('eventId', i.toString());
            (0, code_1.saveCurrentData)();
        }
        if (savedSlide == null)
            console.log('it was null');
        else
            (0, code_1.loadCurrentData)(savedSlide);
        console.log('Upgraded to slajdomat data version 0.88');
        figma.root.setPluginData('version', '0.88');
    }
}
exports.upgradeVersion = upgradeVersion;


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__("./src/plugin/code.ts");
/******/ 	
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29kZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7O0FBWUEsMkVBQTJFO0FBQzNFLHlNQUF5TTtBQUN6TSxTQUFTLGVBQWUsQ0FBQyxFQUFVLEVBQUUsS0FBYSxFQUFFLE1BQTBCO0lBQzFFLE1BQU0sTUFBTSxHQUFHO1FBQ1gsRUFBRSxFQUFFLGNBQWM7UUFDbEIsT0FBTyxFQUFFLGNBQWM7S0FDUCxDQUFDO0lBRXJCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO1FBQ3BDLE1BQU0sS0FBSyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN4QixJQUFJLEtBQUssQ0FBQyxJQUFJLElBQUksU0FBUyxJQUFJLEtBQUssQ0FBQyxFQUFFLElBQUksRUFBRSxFQUFFO1lBQzNDLElBQUksQ0FBQyxHQUFHLEtBQUs7Z0JBQ1QsTUFBTSxDQUFDLEVBQUUsR0FBRyxLQUFLLENBQUM7aUJBQ2pCLElBQUksTUFBTSxDQUFDLEVBQUUsSUFBSSxjQUFjO2dCQUNoQyxNQUFNLENBQUMsRUFBRSxHQUFHLFVBQVUsQ0FBQztTQUM5QjtRQUNELElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxJQUFJLE1BQU0sSUFBSSxLQUFLLENBQUMsSUFBSSxJQUFJLE1BQU0sQ0FBQyxJQUFJLEtBQUssQ0FBQyxFQUFFLElBQUksRUFBRSxFQUFFO1lBQ2xFLElBQUksQ0FBQyxHQUFHLEtBQUs7Z0JBQ1QsTUFBTSxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7aUJBQ3RCLElBQUksTUFBTSxDQUFDLE9BQU8sSUFBSSxjQUFjO2dCQUNyQyxJQUFJLEtBQUssQ0FBQyxJQUFJLElBQUksTUFBTTtvQkFDcEIsTUFBTSxDQUFDLE9BQU8sR0FBRyxtQkFBbUIsQ0FBQzs7b0JBRXJDLE1BQU0sQ0FBQyxPQUFPLEdBQUcsbUJBQW1CLENBQUM7U0FDaEQ7S0FDSjtJQUNELE9BQU8sTUFBTSxDQUFDO0FBQ2xCLENBQUM7QUF2Q3dCLDBDQUFlO0FBMEN4QyxvSUFBb0k7QUFDcEkseURBQXlEO0FBQ3pELHlEQUF5RDtBQUN6RCxTQUFTLGFBQWEsQ0FBQyxFQUFVLEVBQUUsS0FBYSxFQUFFLE1BQTBCLEVBQ3hFLGNBQWlELEVBQ2pELGFBQXFCO0lBQ3JCLE1BQU0sTUFBTSxHQUFHLEVBQXFCLENBQUM7SUFFckMsTUFBTSxTQUFTLEdBQUcsZUFBZSxDQUFDLEVBQUUsRUFBRSxLQUFLLEVBQUUsTUFBTSxDQUFDLENBQUM7SUFHckQsUUFBUSxTQUFTLENBQUMsRUFBRSxFQUFFO1FBQ2xCLEtBQUssY0FBYztZQUNmLE1BQU07UUFDVixLQUFLLFVBQVU7WUFDWCxNQUFNLENBQUMsQ0FBQyxHQUFHLGNBQWMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDaEMsTUFBTSxDQUFDLENBQUMsR0FBRyxjQUFjLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ2hDLE1BQU07UUFDVjtZQUNJLE1BQU0sQ0FBQyxDQUFDLEdBQUcsU0FBUyxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1lBQ2pDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsU0FBUyxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0tBQ3hDO0lBR0QsSUFBSSxJQUEwQixDQUFDO0lBRS9CLFFBQVEsU0FBUyxDQUFDLE9BQU8sRUFBRTtRQUN2QixLQUFLLGNBQWM7WUFDZixNQUFNO1FBQ1YsS0FBSyxtQkFBbUI7WUFDcEIsSUFBSSxHQUFHLFFBQVEsQ0FBQztZQUNoQixNQUFNO1FBQ1YsS0FBSyxtQkFBbUI7WUFDcEIsSUFBSSxHQUFHLFNBQVMsQ0FBQztZQUNqQixNQUFNO1FBQ1Y7WUFDSSxJQUFJLFNBQVMsQ0FBQyxPQUFPLENBQUMsSUFBSSxJQUFJLE1BQU07Z0JBQ2hDLElBQUksR0FBRyxTQUFTLENBQUM7O2dCQUVqQixJQUFJLEdBQUcsUUFBUSxDQUFDO0tBQzNCO0lBR0QsSUFBSSxJQUFJLElBQUksUUFBUSxFQUFFO1FBQ2xCLE1BQU0sQ0FBQyxPQUFPLEdBQUcsYUFBYSxDQUFDO0tBQ2xDO0lBQ0QsSUFBSSxJQUFJLElBQUksU0FBUyxFQUFFO1FBQ25CLElBQUksY0FBYyxDQUFDLEVBQUUsQ0FBQyxJQUFJLFNBQVMsSUFBSSxjQUFjLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxJQUFJLFNBQVM7WUFDMUUsTUFBTSxDQUFDLE9BQU8sR0FBRyxjQUFjLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDOztZQUU1QyxNQUFNLENBQUMsT0FBTyxHQUFHLENBQUMsQ0FBQztLQUMxQjtJQUNELE9BQU8sTUFBTSxDQUFDO0FBQ2xCLENBQUM7QUEvRnlDLHNDQUFhOzs7Ozs7Ozs7Ozs7OztBQ0V2RCxrRUFBa0U7QUFDbEUsU0FBUyxTQUFTLENBQUMsSUFBWSxFQUFFLEtBQWU7SUFDNUMsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDO0lBQ3JCLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRTtRQUMvQiwrQkFBK0I7UUFDL0IsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO1FBRWQsR0FBRztZQUNDLFNBQVMsR0FBRyxJQUFJLEdBQUcsS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQ3BDLEtBQUssRUFBRSxDQUFDO1NBQ1gsUUFBUSxLQUFLLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFDO0tBRTFDO0lBRUQsT0FBTyxTQUFTLENBQUM7QUFDckIsQ0FBQztBQWpCUSw4QkFBUztBQW9CbEIsa0lBQWtJO0FBQ2xJLFNBQVMsU0FBUyxDQUFDLENBQVMsRUFBRSxDQUFVLEVBQUUsS0FBYSxFQUFFLE1BQWMsRUFBRSxTQUFzQixFQUFFLFVBQTZDO0lBRTFJLElBQUksV0FBaUIsQ0FBQztJQUN0Qiw4Q0FBOEM7SUFDOUMsSUFBSSxVQUFVLElBQUksU0FBUztRQUN2QixXQUFXLEdBQUcsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsS0FBSyxFQUFFLFVBQVUsQ0FBQyxLQUFLLEVBQUUsTUFBTSxFQUFFLFVBQVUsQ0FBQyxNQUFNLEVBQUUsQ0FBQztJQUVyRixJQUFJLE9BQU8sR0FBRyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFHLENBQUMsRUFBRSxLQUFLLEVBQUcsS0FBSyxFQUFFLE1BQU0sRUFBRyxNQUFNLEVBQUMsQ0FBQztJQUU3RCxTQUFTLFVBQVUsQ0FBQyxDQUFPLEVBQUUsQ0FBbUI7UUFDNUMsSUFBSSxDQUFDLElBQUksU0FBUztZQUNkLE9BQU8sSUFBSSxDQUFDO1FBQ2hCLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDO1lBQzFDLE9BQU8sS0FBSyxDQUFDO1FBQ2pCLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDO1lBQzVDLE9BQU8sS0FBSyxDQUFDO1FBQ2pCLE9BQU8sSUFBSSxDQUFDO0lBQ2hCLENBQUM7SUFFRCxnREFBZ0Q7SUFDaEQsMEVBQTBFO0lBRTFFLE1BQU0sT0FBTyxHQUFHLEtBQUssR0FBRyxHQUFHLENBQUM7SUFDNUIsTUFBTSxPQUFPLEdBQUcsTUFBTSxHQUFHLEdBQUcsQ0FBQztJQUc3QixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxFQUFFO1FBQ3JCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFHekIsSUFBSSxVQUFVLEdBQVcsRUFBRSxDQUFDO1lBRTVCLFVBQVUsQ0FBQyxJQUFJLENBQUMsRUFBRSxLQUFLLEVBQUUsT0FBTyxDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsT0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsT0FBTyxFQUFFLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1lBQzFILFVBQVUsQ0FBQyxJQUFJLENBQUMsRUFBRSxLQUFLLEVBQUUsT0FBTyxDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsT0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsT0FBTyxFQUFFLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1lBQzFILFVBQVUsQ0FBQyxJQUFJLENBQUMsRUFBRSxLQUFLLEVBQUUsT0FBTyxDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsT0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsT0FBTyxFQUFFLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1lBQzFILFVBQVUsQ0FBQyxJQUFJLENBQUMsRUFBRSxLQUFLLEVBQUUsT0FBTyxDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsT0FBTyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsT0FBTyxFQUFFLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1lBRTFILElBQUksUUFBUSxHQUFHLEtBQUssQ0FBQztZQUNyQixLQUFLLE1BQU0sU0FBUyxJQUFJLFVBQVUsRUFBRTtnQkFFaEMsSUFBSSxVQUFVLENBQUMsU0FBUyxFQUFFLFdBQVcsQ0FBQyxFQUFFO29CQUNwQyxRQUFRLEdBQUcsSUFBSSxDQUFDO29CQUVoQixJQUFJLG1CQUFtQixHQUFHLEtBQUssQ0FBQztvQkFDaEMsS0FBSyxNQUFNLEtBQUssSUFBSSxTQUFTLEVBQUU7d0JBQzNCLElBQUksVUFBVSxDQUFDLFNBQVMsRUFBRSxLQUFLLENBQUM7NEJBQzVCLG1CQUFtQixHQUFHLElBQUksQ0FBQztxQkFDbEM7b0JBQ0QsSUFBSSxDQUFDLG1CQUFtQjt3QkFDcEIsT0FBTyxTQUFTLENBQUM7aUJBQ3hCO2FBQ0o7WUFFRCxJQUFJLENBQUMsUUFBUTtnQkFDVCxPQUFPLE9BQU8sQ0FBQztTQUd0QjtBQUVULENBQUM7QUFoRjZCLDhCQUFTO0FBbUZ2QyxTQUFTLGNBQWMsQ0FBQyxDQUFTO0lBQzdCLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxlQUFlLEVBQUUsR0FBRyxDQUFDLENBQUM7QUFDM0MsQ0FBQztBQXJGd0Msd0NBQWM7QUF1RnZELGtEQUFrRDtBQUNsRCxTQUFTLFFBQVEsQ0FBQyxDQUFTO0lBQ3ZCLE1BQU0sUUFBUSxHQUFHO1FBQ2IsQ0FBQyxHQUFHLEVBQUUsUUFBUSxDQUFDO1FBQ2YsQ0FBQyxLQUFLLEVBQUUsR0FBRyxDQUFDO1FBQ1osQ0FBQyxHQUFHLEVBQUUsVUFBVSxDQUFDO1FBQ2pCLENBQUMsR0FBRyxFQUFFLE9BQU8sQ0FBQztRQUNkLENBQUMsR0FBRyxFQUFFLFdBQVcsQ0FBQztLQUNyQixDQUFDO0lBQ0YsSUFBSSxNQUFNLEdBQUcsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQzFCLEtBQUssTUFBTSxPQUFPLElBQUksUUFBUTtRQUMxQixNQUFNLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFFcEQsT0FBTyxNQUFNLENBQUM7QUFDbEIsQ0FBQztBQXJHbUIsNEJBQVE7Ozs7Ozs7Ozs7OztBQ0E1Qix1RUFBdUU7OztBQUluRSx1RkFBd0U7QUFFeEUseUVBQXFEO0FBQ3JELHlIQUErRDtBQUMvRCwwR0FBb0Q7QUFOYixpR0FNOUIsaUNBQWUsUUFOOEI7QUFTMUQsd0hBQXdIO0FBQ3hILFNBQVMsY0FBYyxDQUFDLEtBQWEsRUFBRSxNQUFjLEVBQUUsSUFBWTtJQUUvRCxJQUFJLEtBQUssRUFBRSxLQUFLLEdBQUcsQ0FBQyxDQUFDO0lBRXJCLElBQUk7UUFDQSxLQUFLLEdBQUcsWUFBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7UUFDN0IsS0FBSyxHQUFHLFlBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDO0tBQ2hDO0lBQUMsT0FBTyxDQUFDLEVBQUU7UUFDUix3REFBd0Q7UUFDeEQsS0FBSyxHQUFHLENBQUMsQ0FBQztRQUNWLEtBQUssR0FBRyxDQUFDLENBQUM7S0FDYjtJQUVELE1BQU0sS0FBSyxHQUFHLHNCQUFTLEVBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLG9CQUFTLEdBQUUsRUFBRSxTQUFTLENBQUMsQ0FBQztJQUM3RSxNQUFNLFFBQVEsR0FBRyxLQUFLLENBQUMsV0FBVyxFQUFFLENBQUM7SUFDckMsUUFBUSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7SUFDckIsUUFBUSxDQUFDLENBQUMsR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDO0lBQ3JCLFFBQVEsQ0FBQyxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUM7SUFDcEIsUUFBUSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsTUFBTSxDQUFDLENBQUM7SUFDL0IsTUFBTSxFQUFFLEdBQUcsc0JBQVMsRUFBQywyQkFBYyxFQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFBRSxvQ0FBUyxFQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7SUFDMUUsTUFBTSxRQUFRLEdBQWE7UUFDdkIsSUFBSSxFQUFFLFFBQVEsQ0FBQyxJQUFJO1FBQ25CLEVBQUUsRUFBRSxFQUFFO1FBQ04sUUFBUSxFQUFFLFNBQVM7UUFDbkIsTUFBTSxFQUFFLEVBQUU7UUFDVixjQUFjLEVBQUUsRUFBRTtLQUNyQjtJQUNELFFBQVEsQ0FBQyxhQUFhLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztJQUc3RCxPQUFPLFFBQVEsQ0FBQztBQUNwQixDQUFDO0FBekMwQix3Q0FBYztBQTRDekMsNElBQTRJO0FBQzVJLFNBQVMsZ0JBQWdCLENBQUMsRUFBVTtJQUVoQyxNQUFNLEtBQUssR0FBYyxvQkFBUyxFQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQ3ZDLE1BQU0sUUFBUSxHQUNkO1FBQ0ksSUFBSSxFQUFFLE9BQU87UUFDYixFQUFFLEVBQUUsRUFBRTtRQUNOLElBQUksRUFBRSxLQUFLLENBQUMsSUFBSTtRQUNoQixPQUFPLEVBQUUsU0FBUztRQUNsQixNQUFNLEVBQUUsS0FBSztRQUNiLFFBQVEsRUFBRSxFQUFFO1FBQ1osUUFBUSxFQUFFLEVBQUU7UUFDWixPQUFPLEVBQUUscUNBQVUsR0FBRTtRQUNyQixjQUFjLEVBQUUsU0FBUztLQUM1QjtJQUVELE1BQU0sUUFBUSxHQUFHLHNCQUFTLEVBQUMsS0FBSyxDQUFDLEtBQUssR0FBRyxDQUFDLEVBQUUsS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsR0FBRyxFQUFFLEdBQUcsR0FBRyxLQUFLLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQyxLQUFLLEVBQUUsWUFBSyxDQUFDLFlBQVksQ0FBQyxRQUF1QixFQUFFLFlBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUNySyxNQUFNLFNBQVMsR0FBRyxxQ0FBZSxFQUFDLFlBQUssQ0FBQyxZQUFZLEVBQUUsRUFBRSxFQUFFLFFBQVEsQ0FBQyxDQUFDO0lBQ3BFLEtBQUssQ0FBQyxXQUFXLENBQUMsU0FBUyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDMUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ3RCLENBQUM7QUFqRVEsNENBQWdCOzs7Ozs7Ozs7Ozs7OztBQ0Z6Qix1RkFBNkQ7QUFDN0QseUVBQXVEO0FBQ3ZELHNIQUEyRDtBQU0zRCxnREFBZ0Q7QUFDaEQsU0FBUyxTQUFTLENBQUMsRUFBVTtJQUN6QixLQUFLLE1BQU0sSUFBSSxJQUFJLG9CQUFTLEdBQUU7UUFDMUIsSUFBSSxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRTtZQUNuQixPQUFPLElBQUksQ0FBQztJQUNwQixPQUFPLElBQUksQ0FBQztBQUNoQixDQUFDO0FBVDZCLDhCQUFTO0FBV3ZDLDREQUE0RDtBQUM1RCxTQUFTLFVBQVU7SUFFZiw0SUFBNEk7SUFDNUksSUFBSSxNQUFjLENBQUM7SUFDbkIsTUFBTSxLQUFLLEdBQUcsWUFBSyxDQUFDLFlBQVksQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDMUQsSUFBSSxLQUFLLElBQUksRUFBRTtRQUNYLE1BQU0sR0FBRyxDQUFDLENBQUM7O1FBRVgsTUFBTSxHQUFHLFFBQVEsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDakMsWUFBSyxDQUFDLFlBQVksQ0FBQyxhQUFhLENBQUMsU0FBUyxFQUFFLE1BQU0sQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDO0lBQy9ELE9BQU8sTUFBTSxDQUFDLFFBQVEsRUFBRSxDQUFDO0FBQzdCLENBQUM7QUF2QmtELGdDQUFVO0FBMEI3RCxnREFBZ0Q7QUFDaEQsc0VBQXNFO0FBQ3RFLFNBQVMsUUFBUSxDQUFDLENBQVksRUFBRSxRQUFxQixFQUFFO0lBRW5ELElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7UUFDakIsT0FBTyxFQUFFLENBQUM7SUFFZCxJQUFJLENBQUMsQ0FBQyxJQUFJLElBQUksTUFBTSxFQUFFO1FBQ2xCLE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7S0FDbkI7SUFDRCxJQUFJLENBQUMsQ0FBQyxJQUFJLElBQUksT0FBTyxJQUFJLENBQUMsQ0FBQyxJQUFJLElBQUksT0FBTyxFQUFFO1FBQ3hDLElBQUksTUFBTSxHQUFhLEVBQUUsQ0FBQztRQUMxQixLQUFLLE1BQU0sS0FBSyxJQUFJLENBQUMsQ0FBQyxRQUFRLEVBQUU7WUFDNUIsTUFBTSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLEtBQWtCLEVBQUUsS0FBSyxDQUFDLENBQUM7U0FDOUQ7UUFDRCxPQUFPLE1BQU0sQ0FBQztLQUNqQjtJQUNELGdDQUFnQztJQUNoQyxPQUFPLEVBQUUsQ0FBQztBQUNkLENBQUM7QUE3Q1EsNEJBQVE7QUFnRGpCLG9OQUFvTjtBQUNwTixTQUFTLFFBQVEsQ0FBQyxJQUFlO0lBQzdCLE1BQU0sS0FBSyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUU3Qiw2Q0FBNkM7SUFDN0MsSUFBSSxLQUFLLENBQUMsTUFBTSxJQUFJLENBQUM7UUFDakIsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDO0lBRXJCLHdDQUF3QztJQUN4QyxJQUFJLE1BQU0sR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDdEIsS0FBSyxNQUFNLElBQUksSUFBSSxLQUFLLEVBQUU7UUFDdEIsSUFBSSxJQUFJLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxNQUFNO1lBQzNCLE1BQU0sR0FBRyxJQUFJLENBQUM7S0FDckI7SUFDRCxPQUFPLE1BQU07QUFDakIsQ0FBQztBQS9Ed0MsNEJBQVE7QUFtRWpELG1HQUFtRztBQUNuRyw4Q0FBOEM7QUFDOUMsU0FBUyxPQUFPLENBQUMsS0FBZ0I7SUFDN0IsTUFBTSxRQUFRLEdBQUcsc0JBQVcsRUFBQyxLQUFLLENBQUMsQ0FBQztJQUNwQyxJQUFJLFFBQVEsSUFBSSxTQUFTO1FBQ3JCLE9BQU8sUUFBUSxDQUFDLEVBQUUsQ0FBQzs7UUFFbkIsT0FBTyxTQUFTLENBQUM7QUFDekIsQ0FBQztBQTNFeUUsMEJBQU87QUFnRmpGLHlEQUF5RDtBQUN6RCx3UkFBd1I7QUFDeFIsU0FBUyxTQUFTLENBQUMsY0FBeUI7SUFFeEMsTUFBTSxLQUFLLEdBQWEsRUFBRSxDQUFDO0lBRTNCLDJEQUEyRDtJQUMzRCxLQUFLLE1BQU0sS0FBSyxJQUFJLG9CQUFTLEdBQUU7UUFDM0IsS0FBSyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztJQUUvQix1TUFBdU07SUFDdk0sSUFBSSxNQUFNLEdBQWdCLEVBQUUsQ0FBQztJQUM3QixJQUFJLGNBQWMsSUFBSSxTQUFTO1FBQzNCLE1BQU0sQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7O1FBRTVCLE1BQU0sR0FBRyxvQkFBUyxHQUFFLENBQUM7SUFFekIsS0FBSyxNQUFNLEtBQUssSUFBSSxNQUFNO1FBQ3RCLEtBQUssTUFBTSxLQUFLLElBQUksS0FBSyxDQUFDLFFBQVE7WUFDOUIsS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7SUFHOUMsT0FBTyxLQUFLLENBQUM7QUFDakIsQ0FBQztBQXZHa0IsOEJBQVM7QUEyRzVCLG9HQUFvRztBQUNwRyx1RUFBdUU7QUFDdkUsU0FBUyxTQUFTLENBQUMsSUFBZTtJQUk5QixJQUFJLENBQUMsNENBQWtCLEVBQUMsSUFBSSxDQUFDO1FBQ3pCLE9BQU8sU0FBUyxDQUFDO0lBRXJCLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDdEMsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLE1BQW1CLENBQUM7SUFFdkMsSUFBSSxNQUFNLElBQUksRUFBRSxFQUFFO1FBQ2QsZ05BQWdOO1FBRWhOLHlDQUF5QztRQUN6QyxTQUFTLFNBQVMsQ0FBQyxDQUFZLEVBQUUsQ0FBWTtZQUN6QyxxTkFBcU47WUFFck4sSUFBSSxDQUFDLENBQUMsRUFBRSxDQUFDLE1BQU0sSUFBSSxDQUFDLENBQUMsRUFBRSxDQUFDLE1BQU07Z0JBQzFCLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQzs7Z0JBRXJCLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQztRQUMxQyxDQUFDO1FBR0QsS0FBSyxNQUFNLEtBQUssSUFBSSxLQUFLLENBQUMsUUFBUSxFQUFFO1lBQ2hDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxJQUFJLE1BQU0sQ0FBQyxFQUFFO2dCQUNuRSxNQUFNLEdBQUcsRUFBRSxDQUFDO2FBQ2Y7U0FDSjtLQUVKO0lBRUQsSUFBSSxNQUFNLElBQUksRUFBRSxFQUFFO1FBQ2Qsd0dBQXdHO1FBRXhHLE1BQU0sR0FBRyxzQkFBUyxFQUFDLDJCQUFjLEVBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO1FBQ2hFLDJCQUEyQjtRQUMzQixJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBQztLQUNwQztJQUNELE9BQU8sTUFBTSxDQUFDO0FBQ2xCLENBQUM7QUFySjhELDhCQUFTOzs7Ozs7Ozs7Ozs7OztBQ0R4RSx5RUFBK0I7QUFDL0IseUhBQXlFO0FBR3pFLDZEQUE2RDtBQUM3RCxTQUFTLGtCQUFrQixDQUFDLElBQWU7SUFDdkMsSUFBSSxJQUFJLENBQUMsTUFBTSxJQUFJLFlBQUssQ0FBQyxZQUFZLElBQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQUMsSUFBSSxFQUFFO1FBQzFFLE9BQU8sS0FBSyxDQUFDO0lBQ2pCLE9BQU8sSUFBSSxDQUFDO0FBQ2hCLENBQUM7QUFaUSxnREFBa0I7QUFjM0IsK0NBQStDO0FBQy9DLFNBQVMsa0JBQWtCLENBQUMsSUFBaUM7SUFFekQsTUFBTSxNQUFNLEdBQUcsRUFBb0IsQ0FBQztJQUNwQyxtQ0FBbUM7SUFFbkMsa0ZBQWtGO0lBQ2xGLElBQUksTUFBTSxHQUFnQixFQUFFLENBQUM7SUFFN0IsK0tBQStLO0lBQy9LLE1BQU0sTUFBTSxHQUFHLEVBQWMsQ0FBQztJQUM5QixNQUFNLE1BQU0sR0FBRyxFQUFjLENBQUM7SUFFOUIsS0FBSyxNQUFNLElBQUksSUFBSSxLQUFLLENBQUMsV0FBVyxDQUFDLFNBQVMsRUFBRTtRQUM1QyxJQUFJLGtCQUFrQixDQUFDLElBQUksQ0FBQyxFQUFFO1lBQzFCLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3BCLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3BCLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7U0FDckI7S0FDSjtJQUNELHFFQUFxRTtJQUNyRSxNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxDQUFDO0lBQ3JELE1BQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsTUFBTSxDQUFDLENBQUM7SUFFckQsd0VBQXdFO0lBQ3hFLE1BQU0sU0FBUyxHQUFHLENBQUMsQ0FBWSxFQUFFLEVBQUU7UUFDL0IsSUFBSSxFQUFFLEdBQUcsRUFBRTtZQUNQLE9BQU8sQ0FBQyxDQUFDLENBQUM7O1lBRVYsT0FBTyxDQUFDLENBQUMsQ0FBQztJQUNsQixDQUFDLENBQUM7SUFDRiwwRUFBMEU7SUFFMUUsTUFBTSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFHNUQsNEVBQTRFO0lBQzVFLEtBQUssTUFBTSxJQUFJLElBQUksTUFBTSxFQUFFO1FBQ3ZCLElBQUksUUFBc0IsQ0FBQztRQUMzQixJQUFJLElBQUksQ0FBQyxJQUFJLEtBQUssT0FBTyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQ3hELGtCQUFrQjtZQUNsQixJQUFJLENBQUMsSUFBSSxHQUFHLG1DQUFRLEVBQUMsSUFBSSxDQUFDLENBQUM7U0FDOUI7UUFFRCxNQUFNLEVBQUUsR0FBRyxvQ0FBUyxFQUFDLElBQUksQ0FBQyxDQUFDO1FBRzNCLFFBQVEsSUFBSSxFQUFFO1lBQ1YsS0FBSyxNQUFNLENBQUM7WUFDWixLQUFLLE1BQU07Z0JBQ1AsSUFBSSxTQUFTLElBQUksSUFBSSxFQUFFO29CQUNuQixJQUFJLFlBQUssQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLEVBQUUsQ0FBQyxJQUFJLFNBQVM7d0JBQzlDLFlBQUssQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPLEVBQXFCLENBQUM7b0JBQ3JGLElBQUksWUFBSyxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxJQUFJLFNBQVMsRUFBRTt3QkFDeEQseUhBQXlIO3dCQUN6SCxZQUFLLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQztxQkFDNUQ7b0JBQ0QsUUFBUTt3QkFDUjs0QkFDSSxJQUFJLEVBQUUsSUFBSTs0QkFDVixFQUFFLEVBQUUsRUFBRTs0QkFDTixPQUFPLEVBQUUsU0FBUzs0QkFDbEIsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJOzRCQUNmLE1BQU0sRUFBRSxLQUFLOzRCQUNiLFFBQVEsRUFBRSxFQUFFOzRCQUNaLE9BQU8sRUFBRSxxQ0FBVSxHQUFFO3lCQUN4QjtpQkFDSjtnQkFDRCxNQUFNO1lBRVYsS0FBSyxTQUFTO2dCQUNWLE1BQU0sTUFBTSxHQUFHLEVBQUUsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLEVBQXFCLENBQUM7Z0JBQzNELElBQUksWUFBSyxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsRUFBRSxDQUFDLElBQUksU0FBUztvQkFDOUMsWUFBSyxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsRUFBRSxDQUFDLHFCQUFPLE1BQU0sQ0FBQyxDQUFDO2dCQUNwRCxJQUFJLFlBQUssQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxTQUFTLEVBQ2hEO29CQUNJLDhIQUE4SDtvQkFDOUgsWUFBSyxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUM7b0JBQzdDLFlBQUssQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDO2lCQUNoRDtnQkFDTCxRQUFRO29CQUNSO3dCQUNJLElBQUksRUFBRSxTQUFTO3dCQUNmLEVBQUUsRUFBRSxFQUFFO3dCQUNOLE9BQU8sRUFBRSxTQUFTO3dCQUNsQixJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUk7d0JBQ2YsTUFBTSxFQUFFLEtBQUs7d0JBQ2IsUUFBUSxFQUFFLEVBQUU7d0JBQ1osT0FBTyxFQUFFLHFDQUFVLEdBQUU7d0JBQ3JCLE1BQU0sRUFBRSxNQUFNO3FCQUNqQjtnQkFDRCxNQUFNO1NBQ2I7UUFFRCxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0tBRXpCO0lBQ0QsT0FBTyxNQUFNLENBQUM7QUFDbEIsQ0FBQztBQWhINEIsZ0RBQWtCOzs7Ozs7Ozs7Ozs7OztBQ0UvQyx5RUFBNkM7QUFFN0MsdUdBQWtEO0FBS2xELHFCQUFxQjtBQUNyQixJQUFJLGNBQW1DLENBQUM7QUFWQyx3Q0FBYztBQWV2RCw4QkFBOEI7QUFDOUIsU0FBUyxnQkFBZ0IsQ0FBQyxRQUE2QjtJQUNuRCx1Q0FBYyxHQUFHLFFBQVEsQ0FBQztJQUMxQixLQUFLLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0lBQ3BFLFlBQVksRUFBRSxDQUFDO0FBQ25CLENBQUM7QUFwQlEsNENBQWdCO0FBc0J6Qiw2QkFBNkI7QUFDN0IsU0FBUyxZQUFZO0lBQ2pCLG1CQUFRLEVBQUM7UUFDTCxJQUFJLEVBQUUsVUFBVTtRQUNoQixRQUFRLEVBQUUsY0FBYztLQUMzQixDQUFDLENBQUM7QUFDUCxDQUFDO0FBNUJ3RCxvQ0FBWTtBQWdDckUsd0NBQXdDO0FBQ3hDLFNBQVMsWUFBWTtJQUNqQixtQ0FBYyxHQUFFLENBQUM7SUFDakIsS0FBSyxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUMxQyxDQUFDLENBQUMsRUFBRTtRQUNBLDZCQUE2QjtRQUM3QixNQUFNLGVBQWUsR0FBRztZQUNwQixLQUFLLEVBQUUsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxDQUFDO1lBQ2hDLE1BQU0sRUFBRSxLQUFLO1lBQ2IsUUFBUSxFQUFFO2dCQUNOLE1BQU0sRUFBRSxhQUFhO2dCQUNyQixLQUFLLEVBQUUsU0FBUzthQUNuQjtZQUNELFlBQVksRUFBRSxDQUFDO1lBQ2YsU0FBUyxFQUFFLHVCQUF1QjtZQUNsQyxVQUFVLEVBQUUsdUNBQXVDO1NBQ3REO1FBRUQsSUFBSTtZQUNBLHVDQUFjLG1DQUNQLGVBQWUsR0FDZixJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUNuQixDQUFDO1NBQ0w7UUFBQyxPQUFPLENBQUMsRUFBRTtZQUNSLHVDQUFjLEdBQUcsZUFBZSxDQUFDO1NBQ3BDO1FBQ0QsWUFBWSxFQUFFLENBQUM7UUFDZixvQkFBUyxHQUFFLENBQUM7SUFDaEIsQ0FBQyxDQUNKO0FBQ0wsQ0FBQztBQTlEMEIsb0NBQVk7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQ3ZDLHlFQUFtRDtBQUVuRCwwSEFBMEg7QUFDMUgsTUFBTSxRQUFRLEdBQUc7SUFDYixJQUFJLEVBQUUsT0FBTztJQUNiLEtBQUssRUFBRTtRQUNILENBQUMsRUFBRSxDQUFDO1FBQ0osQ0FBQyxFQUFFLENBQUM7UUFDSixDQUFDLEVBQUUsQ0FBQztLQUNQO0NBQ0ssQ0FBQztBQUdYLHNHQUFzRztBQUN0RyxTQUFTLGVBQWUsQ0FBQyxXQUFzQixFQUFFLGFBQXFCLEVBQUUsS0FBVztJQUMvRSxNQUFNLFdBQVcsR0FBYyxvQkFBUyxFQUFDLGFBQWEsQ0FBQyxDQUFDO0lBRXhELGdGQUFnRjtJQUNoRixNQUFNLFFBQVEsR0FBRyxLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7SUFDekMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsS0FBSyxFQUFFLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUMxQyxRQUFRLENBQUMsQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUM7SUFDckIsUUFBUSxDQUFDLENBQUMsR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDO0lBQ3JCLFFBQVEsQ0FBQyxPQUFPLEdBQUcsR0FBRyxDQUFDO0lBQ3ZCLFFBQVEsQ0FBQyxhQUFhLENBQUMsV0FBVyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQzNDLFlBQUssQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBRXpDLCtEQUErRDtJQUMvRCxNQUFNLFNBQVMsR0FBRyxLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7SUFDMUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsS0FBSyxFQUFFLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUMzQyxTQUFTLENBQUMsQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUM7SUFDdEIsU0FBUyxDQUFDLENBQUMsR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDO0lBQ3RCLFNBQVMsQ0FBQyxLQUFLLEdBQUcsRUFBRSxDQUFDO0lBQ3JCLFNBQVMsQ0FBQyxPQUFPLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUMvQixZQUFLLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsQ0FBQztJQUUxQywwQkFBMEI7SUFDMUIsTUFBTSxTQUFTLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsRUFBRSxTQUFTLENBQUMsRUFBRSxZQUFLLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDekUsU0FBUyxDQUFDLGFBQWEsQ0FBQyxXQUFXLEVBQUUsYUFBYSxDQUFDLENBQUM7SUFDcEQsU0FBUyxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7SUFFM0IsaUtBQWlLO0lBQ2pLLGVBQWUsQ0FBQyxRQUFRLEVBQUUsV0FBVyxDQUFDLENBQUM7SUFFdkMsT0FBTyxTQUFTLENBQUM7QUFDckIsQ0FBQztBQTdDUSwwQ0FBZTtBQStDeEIsU0FBZSxlQUFlLENBQUMsSUFBbUIsRUFBRSxLQUFnQjs7UUFDaEUsSUFBSSxLQUFLLElBQUksU0FBUyxJQUFJLEtBQUssQ0FBQyxPQUFPLEVBQUU7WUFDckMsb0NBQW9DO1lBQ3BDLElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBRSxRQUFRLENBQUUsQ0FBQztTQUM3QjthQUNJO1lBQ0QsMERBQTBEO1lBQzFELE1BQU0sS0FBSyxHQUFHLEtBQUssQ0FBQyxXQUFXLENBQUMsTUFBTSxLQUFLLENBQUMsV0FBVyxDQUFDO2dCQUNwRCxNQUFNLEVBQUUsS0FBSzthQUNoQixDQUFDLENBQUMsQ0FBQztZQUNKLElBQUksQ0FBQyxLQUFLLEdBQUc7Z0JBQ1Q7b0JBQ0ksSUFBSSxFQUFFLE9BQU87b0JBQ2IsU0FBUyxFQUFFLEtBQUssQ0FBQyxJQUFJO29CQUNyQixTQUFTLEVBQUUsTUFBTTtpQkFDcEI7YUFDSjtTQUNKO0lBQ0wsQ0FBQztDQUFBO0FBR0QsMENBQTBDO0FBQzFDLFNBQWUsZ0JBQWdCOztRQUMzQixNQUFNLEtBQUssR0FBRyxZQUFLLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQWUsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQztRQUVyRyxLQUFLLE1BQU0sS0FBSyxJQUFJLEtBQUssRUFBRTtZQUN2QixNQUFNLEtBQUssR0FBRyxvQkFBUyxFQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztZQUUxRCxvTUFBb007WUFDcE0sSUFBSSxLQUFLLENBQUMsSUFBSSxJQUFJLFdBQVcsRUFBRTtnQkFDM0IsTUFBTSxLQUFLLEdBQUcsRUFBRSxLQUFLLEVBQUUsS0FBSyxDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDO2dCQUNuRixLQUFLLENBQUMsTUFBTSxFQUFFLENBQUM7Z0JBQ2YsZUFBZSxDQUFDLFlBQUssQ0FBQyxZQUFZLEVBQUUsa0JBQU8sRUFBQyxLQUFLLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQzthQUM5RDtZQUlELElBQUksSUFBbUIsQ0FBQztZQUN4QixxRkFBcUY7WUFDckYsSUFBSSxLQUFLLENBQUMsSUFBSSxJQUFJLE9BQU8sRUFBRTtnQkFDdkIsS0FBSyxNQUFNLFVBQVUsSUFBSSxLQUFLLENBQUMsUUFBUTtvQkFDbkMsSUFBSSxVQUFVLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQyxFQUFFO3dCQUN2QyxJQUFJLEdBQUcsVUFBMkIsQ0FBQztxQkFDdEM7YUFDUjtZQUVELHlGQUF5RjtZQUN6RixJQUFJLElBQUksSUFBSSxJQUFJLEVBQUU7Z0JBQ2QsZUFBZSxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsQ0FBQzthQUNoQztTQUNKO0lBQ0wsQ0FBQztDQUFBO0FBbEd5Qiw0Q0FBZ0I7Ozs7Ozs7Ozs7OztBQ0QxQztFQUNFOzs7QUFJRiwrR0FBMEU7QUFFMUUseUVBQWdEO0FBQ2hELHlIQUFtRDtBQUtuRCwyRkFBMkY7QUFDM0YsU0FBUyxtQkFBbUI7SUFFeEIsTUFBTSxVQUFVLEdBQUcsaUJBQWlCLEVBQUUsQ0FBQztJQUV2Qyw0REFBNEQ7SUFDNUQsS0FBSyxNQUFNLEdBQUcsSUFBSSxNQUFNLENBQUMsSUFBSSxDQUFDLFlBQUssQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLEVBQUU7UUFDMUQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDO1lBQ3BCLE9BQU8sWUFBSyxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLENBQUM7S0FDakQ7SUFFRCxLQUFLLE1BQU0sSUFBSSxJQUFJLFlBQUssQ0FBQyxZQUFZLENBQUMsUUFBUSxFQUFFO1FBQzVDLE1BQU0sRUFBRSxHQUFHLG9DQUFTLEVBQUMsSUFBSSxDQUFDLENBQUM7UUFDM0IsSUFBSSxVQUFVLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxFQUFHO1lBQ3JCLG9CQUFvQjtZQUNwQiw2SUFBNkk7WUFDN0ksTUFBTSxTQUFTLEdBQUcsb0NBQWUsRUFBQyxFQUFFLEVBQUUsWUFBSyxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUUsWUFBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUV0RixJQUFJLFNBQVMsQ0FBQyxFQUFFLElBQUksY0FBYyxJQUFJLFNBQVMsQ0FBQyxPQUFPLElBQUksY0FBYyxFQUFFO2dCQUN2RSxJQUFJLFlBQUssQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLEVBQUUsQ0FBQyxJQUFJLFNBQVM7b0JBQzlDLFlBQUssQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQXFCLENBQUM7YUFDakU7WUFFRCxRQUFRLFNBQVMsQ0FBQyxFQUFFLEVBQUU7Z0JBQ2xCLEtBQUssVUFBVTtvQkFDWCxZQUFLLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQztvQkFDN0MsWUFBSyxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUM7b0JBQzdDLE1BQU07Z0JBQ1YsS0FBSyxjQUFjO29CQUNmLE1BQU07Z0JBQ1Y7b0JBQ0ksU0FBUyxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUM7b0JBQy9CLFNBQVMsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDO2FBQ3RDO1lBRUQsOEdBQThHO1lBQzlHLElBQUksU0FBUyxJQUFJLElBQUksRUFBRTtnQkFDbkIsUUFBUSxTQUFTLENBQUMsT0FBTyxFQUFFO29CQUN2QixLQUFLLGNBQWMsQ0FBQztvQkFDcEIsS0FBSyxtQkFBbUI7d0JBQ3BCLE1BQU07b0JBQ1Y7d0JBQ0ksSUFBSSxTQUFTLENBQUMsT0FBTyxJQUFJLG1CQUFtQixJQUFJLFNBQVMsQ0FBQyxPQUFPLENBQUMsSUFBSSxJQUFJLE1BQU0sRUFBRTs0QkFDOUUsWUFBSyxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUM7eUJBQzVEO2lCQUNSO2FBQ0o7U0FDSjtLQUNKO0FBQ0wsQ0FBQztBQTNEUSxrREFBbUI7QUErRDVCLFNBQVMsaUJBQWlCO0lBQ3RCLE1BQU0saUJBQWlCLEdBQUcsSUFBSSxHQUFHLEVBQVUsQ0FBQztJQUM1QyxLQUFLLE1BQU0sS0FBSyxJQUFJLFlBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFO1FBQ3ZDLElBQUksS0FBSyxDQUFDLElBQUksSUFBSSxPQUFPO1lBQ3JCLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUM7S0FDdkM7SUFDRCxPQUFPLGlCQUFpQixDQUFDO0FBQzdCLENBQUM7QUFFRCx3Q0FBd0M7QUFDeEMsU0FBUyxtQkFBbUI7SUFFeEIsOEhBQThIO0lBQzlILE1BQU0sVUFBVSxHQUFHLGlCQUFpQixFQUFFLENBQUM7SUFFdkMsS0FBSyxNQUFNLEVBQUUsSUFBSSxVQUFVLEVBQUU7UUFDekIsS0FBSyxNQUFNLElBQUksSUFBSSxZQUFLLENBQUMsWUFBWSxDQUFDLFFBQVEsRUFBRTtZQUM1QyxJQUFJLG9DQUFTLEVBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxFQUFFO2dCQUN2Qiw0RUFBNEU7Z0JBQzVFLE1BQU0sTUFBTSxHQUFHLGtDQUFhLEVBQUMsRUFBRSxFQUFFLFlBQUssQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFLFlBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFLFlBQUssQ0FBQyxRQUFRLENBQUMsY0FBYyxFQUFFLEdBQUcsQ0FBQyxDQUFDO2dCQUNySCxJQUFJLEdBQUcsSUFBSSxNQUFNLEVBQUU7b0JBQ2YsSUFBSSxDQUFDLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDO29CQUNsQixJQUFJLENBQUMsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUM7aUJBQ3JCO2dCQUNELElBQUksTUFBTSxDQUFDLE9BQU8sSUFBSSxTQUFTLElBQUksU0FBUyxJQUFJLElBQUksRUFBRTtvQkFDbEQsSUFBSSxDQUFDLE9BQU8sR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDO2lCQUNqQzthQUNKO1NBQ0o7S0FDSjtBQUNMLENBQUM7QUE3RjZCLGtEQUFtQjs7Ozs7Ozs7Ozs7O0FDSGpEOztFQUVFOzs7QUFVRixnSEFBc0U7QUFDdEUseUhBQXNFO0FBTkUsMkZBTS9ELGdDQUFTLFFBTitEO0FBQStFLHlGQU1qSSw4QkFBTyxRQU5pSTtBQU92SyxzSEFBOEU7QUFDOUUsb0dBQWdFO0FBQ2hFLDBHQUFvRDtBQUNwRCxvR0FBMEU7QUFDMUUsK0VBQXVDO0FBQ3ZDLHdGQUFrRjtBQUVsRixpR0FBMkM7QUFLM0MseUJBQXlCO0FBRXpCLE1BQU0sS0FBSyxHQUFHO0lBQ1YsdURBQXVEO0lBQ3ZELFFBQVEsRUFBRSxJQUFnQjtJQUMxQix3Q0FBd0M7SUFDeEMsWUFBWSxFQUFFLElBQWlCO0NBQ2xDO0FBMUJ3SyxzQkFBSztBQTZCOUssU0FBUyxRQUFRLENBQUMsR0FBbUI7SUFDakMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDO0FBQzdCLENBQUM7QUEvQnFKLDRCQUFRO0FBb0M5SiwrRUFBK0U7QUFDL0UsU0FBUyxnQkFBZ0I7SUFDckIsTUFBTSxHQUFHLEdBQW1CO1FBQ3hCLElBQUksRUFBRSxrQkFBa0I7UUFDeEIsTUFBTSxFQUFFLEVBR0w7S0FDTjtJQUdELEtBQUssTUFBTSxJQUFJLElBQUksU0FBUyxFQUFFO1FBQzFCLElBQUksSUFBSSxJQUFJLEtBQUssQ0FBQyxZQUFZLEVBQUU7WUFDNUIsSUFBSSxZQUFZLEdBQUcsS0FBSyxDQUFDO1lBQ3pCLEtBQUssTUFBTSxDQUFDLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUU7Z0JBQ25DLElBQUksQ0FBQyxDQUFDLElBQUksSUFBSSxPQUFPLElBQUksQ0FBQyxDQUFDLEVBQUUsSUFBSSxrQ0FBTyxFQUFDLElBQUksQ0FBQyxFQUFFO29CQUM1QyxZQUFZLEdBQUcsSUFBSSxDQUFDO2lCQUN2QjthQUNKO1lBQ0QsSUFBSSxDQUFDLFlBQVk7Z0JBQ2IsR0FBRyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUM7b0JBQ1osSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJO29CQUNmLEVBQUUsRUFBRSxrQ0FBTyxFQUFDLElBQUksQ0FBQztpQkFDcEIsQ0FBQyxDQUFDO1NBQ1Y7SUFHTCxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDbEIsQ0FBQztBQUlELDBDQUEwQztBQUMxQyxTQUFTLGFBQWE7SUFDbEIsNEJBQTRCO0lBQzVCLElBQUksS0FBSyxDQUFDLFlBQVksSUFBSSxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLE9BQU8sRUFBRTtRQUMzRCxhQUFhLEVBQUUsQ0FBQztRQUNoQixRQUFRLENBQUM7WUFDTCxJQUFJLEVBQUUsV0FBVztZQUNqQixNQUFNLEVBQUUsS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNO1lBQzdCLFFBQVEsRUFBRSxLQUFLLENBQUMsUUFBUSxDQUFDLFFBQVE7U0FDcEMsQ0FBQyxDQUFDO0tBQ047QUFDTCxDQUFDO0FBR0Qsb0JBQW9CO0FBQ3BCLHNDQUFzQztBQUN0QyxTQUFTLFdBQVcsQ0FBQyxTQUtwQjtJQUdHLHVDQUFtQixHQUFFLENBQUM7SUFHdEIsSUFBSSxhQUFpQyxDQUFDO0lBRXRDLElBQUksU0FBUyxDQUFDLE9BQU8sSUFBSSxPQUFPLEVBQUU7UUFDOUIsZ0NBQWdDO1FBQ2hDLElBQUksU0FBUyxDQUFDLEVBQUUsSUFBSSxJQUFJLEVBQUU7WUFDdEIsTUFBTSxRQUFRLEdBQUcsc0NBQWMsRUFBQyxLQUFLLENBQUMsWUFBWSxDQUFDLEtBQUssRUFBRSxLQUFLLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDckcsU0FBUyxDQUFDLEVBQUUsR0FBRyxrQ0FBTyxFQUFDLFFBQVEsQ0FBQztTQUNuQztRQUNELGFBQWEsR0FBRyx3Q0FBZ0IsRUFBQyxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUM7S0FDbEQ7U0FDSTtRQUVELGtDQUFrQztRQUNsQyxhQUFhLEdBQUcsNENBQWtCLEVBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0tBQ3pEO0lBSUQsK0RBQStEO0lBQy9ELEtBQUssTUFBTSxRQUFRLElBQUksYUFBYSxFQUFFO1FBQ2xDLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRSxDQUFDLEVBQUUsUUFBUSxDQUFDLENBQUM7UUFDbkUsS0FBSyxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUUsQ0FBQztLQUM3QjtJQUlELGVBQWUsRUFBRSxDQUFDO0lBQ2xCLE9BQU8sQ0FBQyxHQUFHLENBQUMsOEJBQThCLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztJQUM1RSx1Q0FBbUIsR0FBRSxDQUFDO0lBQ3RCLE9BQU8sQ0FBQyxHQUFHLENBQUMsNkJBQTZCLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztJQUMzRSxhQUFhLEVBQUUsQ0FBQztBQUNwQixDQUFDO0FBR0QsNkNBQTZDO0FBQzdDLFNBQVMsV0FBVyxDQUFDLEtBQWE7SUFDOUIsdUNBQW1CLEdBQUUsQ0FBQztJQUN0QixNQUFNLEtBQUssR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUMzQyxJQUFJLEtBQUssQ0FBQyxJQUFJLElBQUksT0FBTyxFQUFFO1FBQ3ZCLE1BQU0sSUFBSSxHQUFHLGVBQWUsQ0FBQyxLQUFLLEVBQUUsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQ3hELElBQUksSUFBSSxJQUFJLElBQUk7WUFDWixJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7S0FDckI7SUFFRCxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsUUFBUSxHQUFHLEtBQUs7UUFDL0IsS0FBSyxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUU5QixLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBQ3ZDLGVBQWUsRUFBRSxDQUFDO0lBQ2xCLHVDQUFtQixHQUFFLENBQUM7SUFDdEIsYUFBYSxFQUFFLENBQUM7QUFDcEIsQ0FBQztBQUVELG1EQUFtRDtBQUNuRCxTQUFTLFVBQVUsQ0FBQyxLQUFhO0lBQzdCLE1BQU0sS0FBSyxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQzNDLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDO0lBQzdCLGVBQWUsRUFBRSxDQUFDO0lBQ2xCLGFBQWEsRUFBRSxDQUFDO0FBQ3BCLENBQUM7QUFHRCwySEFBMkg7QUFDM0gsU0FBUyxhQUFhLENBQUMsV0FBbUIsRUFBRSxXQUFtQjtJQUUzRCx1Q0FBbUIsR0FBRSxDQUFDO0lBQ3RCLDZDQUE2QztJQUM3QyxNQUFNLFdBQVcsR0FBYSxFQUFFLENBQUM7SUFDakMsSUFBSSxDQUFTLENBQUM7SUFDZCxLQUFLLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtRQUMvQyxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sSUFBSSxLQUFLO1lBQ3hDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7S0FDM0I7SUFDRCxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ3BCLE1BQU0sTUFBTSxHQUFHLFdBQVcsQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUN4QyxNQUFNLE1BQU0sR0FBRyxXQUFXLENBQUMsV0FBVyxDQUFDLENBQUM7SUFDeEMsTUFBTSxXQUFXLEdBQUcsV0FBVyxDQUFDLFdBQVcsR0FBRyxDQUFDLENBQUMsR0FBRyxNQUFNLENBQUM7SUFDMUQsTUFBTSxXQUFXLEdBQUcsV0FBVyxDQUFDLFdBQVcsR0FBRyxDQUFDLENBQUMsR0FBRyxNQUFNLENBQUM7SUFFMUQsSUFBSSxVQUFVLENBQUM7SUFDZixJQUFJLE1BQU0sR0FBRyxNQUFNLEVBQUU7UUFDakIsVUFBVSxHQUFHLE1BQU0sQ0FBQztLQUN2QjtTQUFNO1FBQ0gsVUFBVSxHQUFHLE1BQU0sR0FBRyxXQUFXLEdBQUcsV0FBVyxDQUFDO0tBQ25EO0lBRUQsTUFBTSxLQUFLLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxXQUFXLENBQUMsQ0FBQztJQUNoRSxPQUFPLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO1FBQ3JCLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQUUsQ0FBQyxFQUFFLEtBQUssQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO0tBQzVEO0lBRUQsZUFBZSxFQUFFLENBQUM7SUFDbEIsdUNBQW1CLEdBQUUsQ0FBQztJQUN0QixhQUFhLEVBQUUsQ0FBQztBQUVwQixDQUFDO0FBR0QsbUVBQW1FO0FBQ25FLFNBQVMsZUFBZSxDQUFDLFFBQWdCO0lBQ3JDLElBQUksUUFBUSxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsUUFBUTtRQUNuQyxPQUFPO0lBQ1gsaUJBQWlCLEVBQUUsQ0FBQztJQUNwQix1Q0FBbUIsR0FBRSxDQUFDO0lBQ3RCLEtBQUssQ0FBQyxRQUFRLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQztJQUNuQyxlQUFlLEVBQUUsQ0FBQztJQUNsQix1Q0FBbUIsR0FBRSxDQUFDO0lBQ3RCLGFBQWEsRUFBRSxDQUFDO0FBQ3BCLENBQUM7QUFJRCw2UEFBNlA7QUFDN1AsTUFBTSxXQUFXLEdBQW9CLEVBQUU7QUFFdkMsMEJBQTBCO0FBQzFCLFNBQVMsaUJBQWlCO0lBQ3RCLE9BQU8sV0FBVyxDQUFDLE1BQU0sR0FBRyxDQUFDO1FBQ3pCLFdBQVcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxNQUFNLEVBQUUsQ0FBQztBQUNuQyxDQUFDO0FBdE5jLDhDQUFpQjtBQXdOaEMsbUZBQW1GO0FBQ25GLFNBQVMsVUFBVSxDQUFDLEtBQWE7SUFFN0IsSUFBSSxLQUFLLElBQUksQ0FBQyxDQUFDLEVBQUU7UUFDYiwrRUFBK0U7UUFDL0UsaUJBQWlCLEVBQUUsQ0FBQztLQUN2QjtTQUNJO1FBR0QseUZBQXlGO1FBQ3pGLE1BQU0sS0FBSyxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzNDLE1BQU0sSUFBSSxHQUFHLGVBQWUsQ0FBQyxLQUFLLEVBQUUsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQ3hELElBQUksSUFBSSxJQUFJLElBQUksRUFBRTtZQUVkLE1BQU0sTUFBTSxHQUFHLEVBQUUsQ0FBQztZQUNsQix1QkFBdUI7WUFDdkIsTUFBTSxVQUFVLEdBQUcsS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO1lBQzNDLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBRyxDQUFDLEdBQUcsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxDQUFDO1lBQ3JFLFVBQVUsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsR0FBRyxNQUFNO1lBQzlCLFVBQVUsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsR0FBRyxNQUFNLENBQUM7WUFDL0IsVUFBVSxDQUFDLEtBQUssR0FBRyxDQUFDO29CQUNoQixJQUFJLEVBQUUsT0FBTztvQkFDYixLQUFLLEVBQUU7d0JBQ0gsQ0FBQyxFQUFFLEdBQUcsR0FBRyxHQUFHO3dCQUNaLENBQUMsRUFBRSxHQUFHLEdBQUcsR0FBRzt3QkFDWixDQUFDLEVBQUUsR0FBRyxHQUFHLEdBQUc7cUJBQ2Y7aUJBQ0osQ0FBQyxDQUFDO1lBQ0gsVUFBVSxDQUFDLElBQUksR0FBRyxxQkFBcUIsQ0FBQztZQUN4QyxVQUFVLENBQUMsT0FBTyxHQUFHLEdBQUcsQ0FBQztZQUN6QiwyQ0FBMkM7WUFDM0MsS0FBSyxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxDQUFDO1lBQzlDLFdBQVcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7U0FFaEM7S0FDSjtBQUNMLENBQUM7QUFFRCw0Q0FBNEM7QUFDNUMsU0FBUyxXQUFXO0lBQ2hCLGlCQUFpQixFQUFFLENBQUM7QUFDeEIsQ0FBQztBQUdELGdHQUFnRztBQUNoRyxTQUFTLFVBQVUsQ0FBQyxLQUFhO0lBQzdCLE1BQU0sS0FBSyxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQzNDLElBQUksS0FBSyxDQUFDLElBQUksSUFBSSxPQUFPLEVBQUU7UUFDdkIsU0FBUyxDQUFDLG9DQUFTLEVBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7S0FDbEM7QUFDTCxDQUFDO0FBRUQsMkRBQTJEO0FBQzNELFNBQVMsZUFBZTtJQUNwQixLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksR0FBRyxLQUFLLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQztJQUM5QyxLQUFLLENBQUMsWUFBWSxDQUFDLGFBQWEsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztBQUNqRixDQUFDO0FBalJ5SCwwQ0FBZTtBQW9Sekksd0NBQXdDO0FBQ3hDLFNBQVMsZUFBZSxDQUFDLEtBQWdCO0lBQ3JDLEtBQUssQ0FBQyxZQUFZLEdBQUcsS0FBSyxDQUFDO0lBQzNCLEtBQUssQ0FBQyxRQUFRLEdBQUcsV0FBVyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUNqRCxhQUFhLEVBQUUsQ0FBQztBQUNwQixDQUFDO0FBelJ3RywwQ0FBZTtBQTRSeEgsU0FBUyxVQUFVLENBQUMsUUFBa0I7SUFDbEMsSUFBSSxRQUFRLENBQUMsY0FBYyxJQUFJLFNBQVM7UUFDcEMsUUFBUSxDQUFDLGNBQWMsR0FBRyxFQUFFLENBQUM7QUFDckMsQ0FBQztBQUdELDhCQUE4QjtBQUM5QixTQUFTLFdBQVcsQ0FBQyxLQUFnQjtJQUNqQyxNQUFNLENBQUMsR0FBRyxLQUFLLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQzFDLElBQUksQ0FBQyxJQUFJLEVBQUU7UUFDUCxPQUFPLFNBQVM7U0FDZjtRQUNELE1BQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDN0IsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ25CLE9BQU8sTUFBTSxDQUFDO0tBQ2pCO0FBQ0wsQ0FBQztBQTVTa0Ysa0NBQVc7QUFnVDlGLDZDQUE2QztBQUM3QyxTQUFTLFdBQVcsQ0FBQyxJQUFlO0lBQ2hDLElBQUksSUFBSSxJQUFJLElBQUk7UUFDWixPQUFPLEtBQUssQ0FBQztJQUNqQixPQUFPLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQztBQUN0QyxDQUFDO0FBRUQsK0JBQStCO0FBQy9CLFNBQVMsU0FBUztJQUNkLE1BQU0sTUFBTSxHQUFHLEVBQWlCLENBQUM7SUFDakMsS0FBSyxNQUFNLElBQUksSUFBSyxLQUFLLENBQUMsV0FBVyxDQUFDLFFBQXdCLEVBQUU7UUFDNUQsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDO1lBQ2pCLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO0tBQ3hCO0lBQ0QsT0FBTyxNQUFNO0FBQ2pCLENBQUM7QUEvVEcsOEJBQVM7QUFrVWIsc0RBQXNEO0FBQ3RELFNBQVMsbUJBQW1CLENBQUMsRUFBVSxFQUFFLEtBQWdCO0lBQ3JELEtBQUssTUFBTSxLQUFLLElBQUksS0FBSyxDQUFDLFFBQVE7UUFDOUIsSUFBSSxFQUFFLElBQUksb0NBQVMsRUFBQyxLQUFLLENBQUM7WUFDdEIsT0FBTyxLQUFrQixDQUFDO0FBQ3RDLENBQUM7QUF2VWtELGtEQUFtQjtBQXlVdEUsNktBQTZLO0FBQzdLLFNBQVMsZUFBZSxDQUFDLEtBQXVCLEVBQUUsS0FBZ0I7SUFDOUQsSUFBSSxLQUFLLENBQUMsSUFBSSxJQUFJLE9BQU8sRUFBRTtRQUN2Qiw2S0FBNks7UUFDN0ssTUFBTSxLQUFLLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQWUsRUFBRSxFQUFFLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQUMsSUFBSSxLQUFLLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDOUYsSUFBSSxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUM7WUFDaEIsT0FBTyxLQUFLLENBQUMsQ0FBQyxDQUFjO0tBQ25DO1NBQ0k7UUFDRCx3RkFBd0Y7UUFDeEYsT0FBTyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsRUFBRSxFQUFFLEtBQUssQ0FBQyxDQUFDO0tBQy9DO0lBQ0QsT0FBTyxJQUFJLENBQUM7QUFDaEIsQ0FBQztBQXRWaUMsMENBQWU7QUF5VmpELDJFQUEyRTtBQUMzRSxTQUFTLGFBQWE7SUFFbEIsS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLEdBQUcsS0FBSyxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUM7SUFFOUMscUVBQXFFO0lBQ3JFLCtDQUErQztJQUMvQyxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsUUFBUSxJQUFJLFNBQVM7UUFDcEMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO0lBRTNELHVDQUF1QztJQUN2QyxxREFBcUQ7SUFDckQsMERBQTBEO0lBQzFELDZFQUE2RTtJQUM3RSxLQUFLLE1BQU0sS0FBSyxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFO1FBQ3ZDLEtBQUssQ0FBQyxPQUFPLEdBQUcsVUFBVSxDQUFDO1FBQzNCLE1BQU0sSUFBSSxHQUFHLGVBQWUsQ0FBQyxLQUFLLEVBQUUsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQ3hELElBQUksSUFBSSxJQUFJLElBQUksRUFBRTtZQUNkLElBQUksS0FBSyxDQUFDLElBQUksSUFBSSxPQUFPLEVBQUU7Z0JBQ3ZCLE1BQU0sQ0FBQyxHQUFHLG9DQUFTLEVBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUM5QixJQUFJLENBQUMsSUFBSSxJQUFJLEVBQUU7b0JBQ1gsS0FBSyxDQUFDLElBQUksR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO29CQUNwQixJQUFJLENBQUMsSUFBSSxHQUFHLFVBQVUsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDO29CQUNoQyxLQUFLLENBQUMsT0FBTyxHQUFHLFNBQVMsQ0FBQztpQkFDN0I7YUFDSjtZQUNELElBQUksS0FBSyxDQUFDLElBQUksSUFBSSxNQUFNLElBQUksS0FBSyxDQUFDLElBQUksSUFBSSxNQUFNLElBQUksS0FBSyxDQUFDLElBQUksSUFBSSxTQUFTLEVBQUU7Z0JBQ3pFLEtBQUssQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQztnQkFDdkIsS0FBSyxDQUFDLE9BQU8sR0FBRyxTQUFTLENBQUM7YUFDN0I7U0FDSjtLQUNKO0FBQ0wsQ0FBQztBQUdELGtEQUFrRDtBQUNsRCxTQUFTLFdBQVcsQ0FBQyxLQUFnQjtJQUNqQyxLQUFLLE1BQU0sS0FBSyxJQUFJLFNBQVMsRUFBRSxFQUFFO1FBQzdCLE1BQU0sRUFBRSxHQUFHLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUM5QixJQUFJLEVBQUUsSUFBSSxTQUFTO1lBQ2YsS0FBSyxNQUFNLEtBQUssSUFBSSxFQUFFLENBQUMsTUFBTTtnQkFDekIsSUFBSSxLQUFLLENBQUMsSUFBSSxJQUFJLE9BQU8sSUFBSSxLQUFLLENBQUMsRUFBRSxJQUFJLGtDQUFPLEVBQUMsS0FBSyxDQUFDO29CQUNuRCxPQUFPLEtBQUssQ0FBQztLQUM1QjtJQUNELE9BQU8sSUFBSSxDQUFDO0FBQ2hCLENBQUM7QUFHRCxxQ0FBcUM7QUFDckMsU0FBUyxlQUFlLENBQUMsS0FBZ0I7SUFFckMsSUFBSSxLQUFLLElBQUksSUFBSSxFQUFFO1FBQ2YsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3ZCLE1BQU0sTUFBTSxHQUFHLE9BQU8sRUFBRSxJQUFJLEtBQUssQ0FBQyxZQUFZLENBQUM7UUFDL0MsTUFBTSxHQUFHLEdBQW1CO1lBQ3hCLElBQUksRUFBRSxhQUFhO1lBQ25CLE9BQU8sRUFBRSxLQUFLLENBQUMsSUFBSSxDQUFDLElBQUk7WUFDeEIsS0FBSyxFQUFFLEtBQUssQ0FBQyxZQUFZLENBQUMsSUFBSTtZQUM5QixNQUFNLEVBQUUsTUFBTTtZQUNkLFVBQVUsRUFBRSxTQUFTLEVBQUUsQ0FBQyxNQUFNO1NBQ2pDO1FBRUQsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ2QsYUFBYSxFQUFFLENBQUM7UUFDaEIsc0NBQWdCLEdBQUUsQ0FBQztLQUV0QjtTQUFNO1FBQ0gsUUFBUSxDQUFDO1lBQ0wsSUFBSSxFQUFFLFNBQVM7U0FDbEIsQ0FBQztLQUNMO0FBQ0wsQ0FBQztBQUVELHlDQUF5QztBQUN6QyxTQUFTLFNBQVMsQ0FBQyxLQUFnQjtJQUMvQixLQUFLLENBQUMsUUFBUSxDQUFDLHFCQUFxQixDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztJQUM5QyxlQUFlLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDM0IsQ0FBQztBQUdELHNEQUFzRDtBQUN0RCxTQUFTLGtCQUFrQjtJQUN2QixNQUFNLEdBQUcsR0FBRyxLQUFLLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQztJQUN4QyxJQUFJLEdBQUcsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO1FBQ2hCLElBQUksSUFBSSxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUNsQixPQUFPLENBQUMsV0FBVyxDQUFDLElBQWlCLENBQUMsSUFBSSxJQUFJLElBQUksSUFBSTtZQUNsRCxJQUFJLEdBQUcsSUFBSSxDQUFDLE1BQW1CLENBQUM7UUFDcEMsT0FBTyxJQUFpQixDQUFDO0tBQzVCOztRQUNHLE9BQU8sSUFBSSxDQUFDO0FBQ3BCLENBQUM7QUFFRCx1Q0FBdUM7QUFDdkMsU0FBUyxPQUFPO0lBQ1osTUFBTSxTQUFTLEdBQUcsb0NBQVMsRUFBQyxLQUFLLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO0lBQ25FLElBQUksU0FBUyxJQUFJLElBQUksRUFBRTtRQUNuQixPQUFPLEVBQUUsQ0FBQztLQUNiO0lBQ0QsT0FBTyxTQUFTLENBQUM7QUFFckIsQ0FBQztBQTdiK0YsMEJBQU87QUErYnZHLHNDQUFzQztBQUN0QyxTQUFTLE9BQU87SUFDWixLQUFLLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxXQUFXLEVBQUUsa0NBQU8sRUFBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztBQUN2RSxDQUFDO0FBSUQscUhBQXFIO0FBQ3JILFNBQVMsU0FBUyxDQUFDLE9BQTRCO0lBQzNDLEtBQUssTUFBTSxDQUFDLElBQUksT0FBTyxDQUFDLGVBQWUsRUFBRTtRQUNyQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSSxpQkFBaUIsQ0FBQyxFQUFFO1lBQy9CLE1BQU0sTUFBTSxHQUFHLENBQUMsQ0FBQyxJQUFpQixDQUFDO1lBQ25DLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLElBQUksRUFBRSxDQUFDLEVBQUU7Z0JBQ2hFLE1BQU0sSUFBSSxHQUFHLE1BQXVCLENBQUM7Z0JBQ3JDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUM7YUFDOUY7U0FHSjtLQUNKO0FBRUwsQ0FBQztBQUVELGtEQUFrRDtBQUNsRCxTQUFTLFNBQVM7SUFDZCwrSkFBK0o7SUFFL0osTUFBTSxLQUFLLEdBQUcsa0JBQWtCLEVBQUUsQ0FBQztJQUduQyx5TEFBeUw7SUFDekw7SUFDSSx5QkFBeUI7S0FDeEIsQ0FBQyxLQUFLLENBQUMsWUFBWSxJQUFJLElBQUksSUFBSSxLQUFLLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQztRQUMzRCwyREFBMkQ7UUFDM0QsQ0FBQyxLQUFLLElBQUksS0FBSyxDQUFDLFlBQVksSUFBSSxLQUFLLElBQUksSUFBSSxDQUFDO1FBQzlDLG1DQUFtQztRQUNuQyxDQUFDLEtBQUssQ0FBQyxZQUFZLElBQUksSUFBSSxJQUFJLEtBQUssQ0FBQyxZQUFZLElBQUksS0FBSyxJQUFJLEtBQUssQ0FBQyxZQUFZLENBQUMsSUFBSSxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUM7UUFDcEcsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQ3RCLElBQUksS0FBSyxDQUFDLFlBQVksSUFBSSxTQUFTLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLElBQUksS0FBSyxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUU7UUFDeEYsZ0ZBQWdGO1FBQ2hGLGVBQWUsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUM7S0FDdkM7U0FDSSxJQUFJLEtBQUssQ0FBQyxZQUFZLElBQUksSUFBSTtRQUMvQixhQUFhLEVBQUUsQ0FBQztJQUVwQixNQUFNLEdBQUcsR0FBRyxLQUFLLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQztJQUV4QyxNQUFNLEdBQUcsR0FBbUI7UUFDeEIsSUFBSSxFQUFFLFdBQVc7UUFDakIsUUFBUSxFQUFFLEtBQUs7UUFDZixVQUFVLEVBQUUseUJBQVUsQ0FBQyxJQUFJO1FBQzNCLFNBQVMsRUFBRSxLQUFLO1FBQ2hCLFdBQVcsRUFBRSxJQUFnQjtLQUNoQyxDQUFDO0lBRUYsS0FBSyxNQUFNLElBQUksSUFBSSxLQUFLLENBQUMsV0FBVyxDQUFDLFNBQVMsRUFBRTtRQUM1QyxJQUFJLDRDQUFrQixFQUFDLElBQUksQ0FBQztZQUN4QixHQUFHLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQztLQUMzQjtJQUVELHFGQUFxRjtJQUVyRixJQUFJLEdBQUcsQ0FBQyxNQUFNLElBQUksQ0FBQyxFQUFFO1FBQ2pCLElBQUksR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksSUFBSSxNQUFNLEVBQUUsb0NBQW9DO1lBQzNELEdBQUcsQ0FBQyxVQUFVLEdBQUcseUJBQVUsQ0FBQyxLQUFLLENBQUM7UUFDdEMsSUFBSSw2QkFBYSxFQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLElBQUksRUFBRSx1Q0FBdUM7WUFDdEUsR0FBRyxDQUFDLFVBQVUsR0FBRyx5QkFBVSxDQUFDLE9BQU87S0FDMUM7SUFDRCxJQUFJLEtBQUssQ0FBQyxXQUFXLENBQUMsaUJBQWlCLElBQUksSUFBSSxFQUFFO1FBQzdDLE1BQU0sQ0FBQyxHQUFHLEtBQUssQ0FBQyxXQUFXLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDO1FBQ2xELElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUNQLEdBQUcsQ0FBQyxXQUFXLEdBQUksR0FBRyxDQUFDLENBQUMsQ0FBYyxDQUFDLGdCQUFnQixDQUFDLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFhO1NBQ2hGO1FBQ0QsR0FBRyxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7S0FDeEI7SUFDRCxrREFBa0Q7SUFDbEQsUUFBUSxDQUFDLEdBQUcsQ0FBQztBQUNqQixDQUFDO0FBN2dCMEksOEJBQVM7QUFnaEJwSix1Q0FBdUM7QUFDdkMsU0FBUyxTQUFTLENBQUMsR0FBbUI7SUFFbEMsUUFBUSxHQUFHLENBQUMsSUFBSSxFQUFFO1FBRWQsS0FBSyxRQUFRO1lBQ1QsMkJBQTJCO1lBQzNCLEtBQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ3ZCLE1BQUs7UUFFVCxLQUFLLGlCQUFpQjtZQUNsQixlQUFlLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQzNCLE1BQU07UUFFVixLQUFLLGFBQWE7WUFDZCwwQ0FBMEM7WUFDMUMsb0NBQW9DO1lBQ3BDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUNqQixNQUFNO1FBRVYsS0FBSyxVQUFVO1lBQ1gsaUNBQWlDO1lBQ2pDLG9DQUFnQixFQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUMsQ0FBQztZQUNyQyxNQUFNO1FBRVYsS0FBSyxhQUFhO1lBQ2QsaUJBQWlCO1lBQ2pCLFdBQVcsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDdkIsTUFBTTtRQUVWLEtBQUssWUFBWTtZQUNiLHNDQUFzQztZQUN0QyxVQUFVLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3RCLE1BQU07UUFFVixLQUFLLFdBQVc7WUFDWiw4QkFBOEI7WUFDOUIsYUFBYSxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ3JDLGlCQUFpQixFQUFFLENBQUM7WUFDcEIsTUFBTTtRQUVWLEtBQUssV0FBVztZQUNaLG9CQUFvQjtZQUNwQixlQUFlLENBQUMsc0NBQWMsRUFBQyxHQUFHLENBQUMsS0FBSyxFQUFFLEdBQUcsQ0FBQyxNQUFNLEVBQUUsV0FBVyxDQUFDLENBQUMsQ0FBQztZQUNwRSxLQUFLLENBQUMsUUFBUSxDQUFDLHFCQUFxQixDQUFDLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7WUFDM0QsTUFBTTtRQUVWLEtBQUssVUFBVTtZQUNYLCtCQUErQjtZQUMvQix5QkFBWSxHQUFFLENBQUM7WUFDZixNQUFNO1FBRVYsS0FBSyxZQUFZO1lBQ2IsT0FBTyxFQUFFLENBQUM7WUFDVixNQUFNO1FBRVYsS0FBSyxrQkFBa0I7WUFDbkIsbUhBQW1IO1lBQ25ILGtDQUFrQztZQUNsQyx1QkFBdUI7WUFDdkIsTUFBTTtRQUVWLEtBQUssWUFBWTtZQUNiLGtLQUFrSztZQUNsSyxVQUFVLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3RCLE1BQU07UUFFVixLQUFLLGlCQUFpQjtZQUNsQixvREFBb0Q7WUFDcEQsZ0JBQWdCLEVBQUUsQ0FBQztZQUNuQixNQUFNO1FBRVYsS0FBSyxZQUFZO1lBQ2IsTUFBTTtRQUVWLEtBQUssWUFBWTtZQUNiLDREQUE0RDtZQUM1RCxVQUFVLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQztZQUNyQixNQUFNO1FBRVYsS0FBSyxZQUFZO1lBQ2IsOEJBQThCO1lBQzlCLFNBQVMsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7WUFDM0MsTUFBTTtRQUVWLEtBQUssU0FBUztZQUNWLDJDQUEyQztZQUMzQyw2QkFBYSxFQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUN4QixNQUFNO1FBRVYsS0FBSyxTQUFTO1lBQ1YsMkNBQTJDO1lBQzNDLDBCQUFVLEdBQUUsQ0FBQztZQUNiLE1BQU07UUFFVixLQUFLLFlBQVk7WUFDYiw0RkFBNEY7WUFDNUYsMEJBQVUsRUFBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDckIsTUFBTTtRQUdWO1lBQ0ksTUFBTSx1Q0FBdUM7S0FFcEQ7QUFDTCxDQUFDO0FBRUQsS0FBSyxDQUFDLEVBQUUsQ0FBQyxnQkFBZ0IsRUFBRSxTQUFTLENBQUMsQ0FBQztBQUN0QyxLQUFLLENBQUMsRUFBRSxDQUFDLGlCQUFpQixFQUFFLFNBQVMsQ0FBQyxDQUFDO0FBQ3ZDLEtBQUssQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLFdBQVcsQ0FBQyxDQUFDO0FBQy9CLEtBQUssQ0FBQyxNQUFNLENBQUMsUUFBUSxFQUFFO0lBQ25CLEtBQUssRUFBRSxHQUFHO0lBQ1YsTUFBTSxFQUFFLEdBQUc7Q0FDZCxDQUFDLENBQUM7QUFDSCxLQUFLLENBQUMsRUFBRSxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUM7QUFJL0IsZUFBZSxDQUFDLGtCQUFrQixFQUFFLENBQUMsQ0FBQztBQUN0QyxnQ0FBWSxHQUFFLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDcG9CZix5RUFVZ0I7QUFDaEIseUhBQWtEO0FBR2xELCtCQUErQjtBQUMvQixTQUFTLFdBQVcsQ0FBQyxJQUFjO0lBQy9CLE1BQU0sTUFBTSxHQUFHLEVBQWMsQ0FBQztJQUM5QixLQUFLLE1BQU0sTUFBTSxJQUFJLElBQUk7UUFDckIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDO1lBQ3hCLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDNUIsT0FBTyxNQUFNLENBQUM7QUFDbEIsQ0FBQztBQUVELDBEQUEwRDtBQUMxRCxTQUFTLGVBQWUsQ0FBQyxLQUFZLEVBQUUsS0FBZ0I7SUFHbkQsTUFBTSxJQUFJLEdBQUcsRUFBaUIsQ0FBQztJQUUvQixLQUFLLE1BQU0sS0FBSyxJQUFJLEtBQUssQ0FBQyxRQUFRLEVBQUU7UUFDaEMsNERBQTREO1FBQzVELElBQUksS0FBSyxDQUFDLElBQUksSUFBSSxNQUFNLEVBQUU7WUFDdEIsTUFBTSxJQUFJLEdBQUcsMEJBQWUsRUFBQyxLQUFLLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDM0MsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUU7Z0JBQ3RCLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ2hCLEtBQUssQ0FBQyxRQUFRLEdBQUcsbUNBQVEsRUFBQyxJQUFJLENBQUMsQ0FBQztnQkFDaEMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUNoQyxLQUFLLENBQUMsUUFBUSxHQUFHLFdBQVcsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUM7YUFDaEQ7U0FDSjtLQUNKO0lBQ0Qsc0ZBQXNGO0lBQ3RGLEtBQUssQ0FBQyxRQUFRLEdBQUcsbUNBQVEsRUFBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDdkMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ2hDLEtBQUssQ0FBQyxRQUFRLEdBQUcsV0FBVyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUNqRCxDQUFDO0FBR0QsZ0VBQWdFO0FBQ2hFLFNBQVMsWUFBWTtJQUVqQiwyREFBMkQ7SUFDM0QsNEJBQWlCLEdBQUUsQ0FBQztJQUVwQix3Q0FBd0M7SUFDeEMsTUFBTSxTQUFTLEdBR1QsRUFBRSxDQUFDO0lBRVQsa0RBQWtEO0lBQ2xELE1BQU0sS0FBSyxHQUFnQixFQUFFLENBQUM7SUFFOUIsOEhBQThIO0lBQzlILFNBQWUsT0FBTyxDQUFDLEtBQWdCLEVBQUUsT0FBZTs7WUFDcEQsSUFBSSxLQUFLLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxFQUFFO2dCQUN2QixJQUFJLEtBQUssR0FBRyxnQ0FBZ0MsQ0FBQztnQkFDN0MsS0FBSyxNQUFNLENBQUMsSUFBSSxLQUFLO29CQUNqQixLQUFLLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxDQUFDO2dCQUM3QixLQUFLLENBQUMsTUFBTSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ2pDLE9BQU8sSUFBSSxDQUFDO2FBQ2Y7aUJBQU07Z0JBQ0gsS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDbEIsMEJBQWUsRUFBQyxLQUFLLENBQUMsQ0FBQztnQkFJdkIsNExBQTRMO2dCQUM1TCxnR0FBZ0c7Z0JBQ2hHLE1BQU0sT0FBTyxHQUdQLEVBQUUsQ0FBQztnQkFDVCxLQUFLLE1BQU0sS0FBSyxJQUFJLFlBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFO29CQUN2QyxNQUFNLElBQUksR0FBRywwQkFBZSxFQUFDLEtBQUssRUFBRSxLQUFLLENBQUMsQ0FBQztvQkFDM0MsSUFBSSxJQUFJLElBQUksSUFBSSxFQUFFO3dCQUNkLHVHQUF1Rzt3QkFDdkcsT0FBTyxDQUFDLE9BQU8sQ0FBQzs0QkFDWixJQUFJLEVBQUUsSUFBSTs0QkFDVixTQUFTLEVBQUUsSUFBSSxDQUFDLElBQUk7eUJBQ3ZCLENBQUMsQ0FBQzt3QkFDSCxJQUFJLENBQUMsSUFBSSxHQUFHLEtBQUssQ0FBQyxFQUFFLENBQUM7cUJBQ3hCO2lCQUNKO2dCQUVELE1BQU0sR0FBRyxHQUFHLE1BQU0sS0FBSyxDQUFDLFdBQVcsQ0FBQztvQkFDaEMsTUFBTSxFQUFFLEtBQUs7b0JBQ2IsY0FBYyxFQUFFLElBQUk7b0JBQ3BCLGNBQWMsRUFBRSxJQUFJO2lCQUN2QixDQUFDLENBQUM7Z0JBSUgsb0dBQW9HO2dCQUNwRyxLQUFLLE1BQU0sTUFBTSxJQUFJLE9BQU8sRUFBRTtvQkFDMUIsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQztpQkFDdkM7Z0JBR0QscUhBQXFIO2dCQUNySCxTQUFTLFlBQVksQ0FBQyxNQUF1QixFQUFFLEVBQVU7b0JBQ3JELE1BQU0sTUFBTSxxQkFBUSxNQUFNLENBQUUsQ0FBQztvQkFDN0IsSUFBSSxNQUFNLENBQUMsQ0FBQyxJQUFJLFNBQVM7d0JBQ3JCLE9BQU8sTUFBTSxDQUFDO29CQUNsQixNQUFNLElBQUksR0FBRyw4QkFBbUIsRUFBQyxFQUFFLEVBQUUsS0FBSyxDQUFDLENBQUM7b0JBQzVDLElBQUksSUFBSSxJQUFJLFNBQVM7d0JBQ2pCLE9BQU8sU0FBUyxDQUFDO29CQUNyQixNQUFNLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUM7b0JBQ25CLE1BQU0sQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQztvQkFDbkIsT0FBTyxNQUFNLENBQUM7Z0JBQ2xCLENBQUM7Z0JBRUQscUdBQXFHO2dCQUNyRyxNQUFNLG9CQUFvQixHQUF1QyxFQUFFLENBQUM7Z0JBQ3BFLEtBQUssTUFBTSxFQUFFLElBQUksWUFBSyxDQUFDLFFBQVEsQ0FBQyxjQUFjLEVBQzlDO29CQUNJLE1BQU0sV0FBVyxHQUFHLFlBQVksQ0FBQyxZQUFLLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztvQkFDeEUsb0JBQW9CLENBQUMsRUFBRSxDQUFDLEdBQUcsV0FBVyxDQUFDO2lCQUMxQztnQkFHRCxNQUFNLE1BQU0sR0FBVTtvQkFDbEIsSUFBSSxFQUFFLE9BQU87b0JBQ2IsSUFBSSxFQUFFLFlBQUssQ0FBQyxRQUFRLENBQUMsSUFBSTtvQkFDekIsRUFBRSxFQUFFLFlBQUssQ0FBQyxRQUFRLENBQUMsRUFBRTtvQkFDckIsT0FBTyxFQUFFLFNBQVM7b0JBQ2xCLE1BQU0sRUFBRSxLQUFLO29CQUNiLFFBQVEsRUFBRSxFQUFFO29CQUNaLFFBQVEsRUFBRSxFQUFFO29CQUNaLE9BQU8sRUFBRSxPQUFPO29CQUNoQixjQUFjLEVBQUUsb0JBQW9CO2lCQUN2QyxDQUFDO2dCQUVGLDBCQUFlLEdBQUUsQ0FBQztnQkFDbEIsU0FBUyxDQUFDLElBQUksQ0FBQztvQkFDWCxRQUFRLEVBQUUsWUFBSyxDQUFDLFFBQVE7b0JBQ3hCLEdBQUcsRUFBRSxHQUFHO2lCQUNYLENBQUMsQ0FBQztnQkFDSCxLQUFLLE1BQU0sS0FBSyxJQUFJLFlBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFO29CQUN2QyxJQUFJLEtBQUssQ0FBQyxPQUFPLElBQUksU0FBUyxFQUFFO3dCQUM1QixJQUFJLEtBQUssQ0FBQyxJQUFJLElBQUksT0FBTyxFQUFFOzRCQUN2QixNQUFNLEtBQUssR0FBRyxNQUFNLE9BQU8sQ0FBQyxvQkFBUyxFQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsRUFBRSxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7NEJBQ2hFLEtBQUssQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQzs0QkFDNUIsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7eUJBQy9COzZCQUFNOzRCQUNILE1BQU0sTUFBTSxxQkFBUSxLQUFLLENBQUUsQ0FBQzs0QkFDNUIsTUFBTSxDQUFDLFFBQVEsR0FBRyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQzs0QkFDaEMsc0RBQXNEOzRCQUN0RCxJQUFJLE1BQU0sQ0FBQyxJQUFJLElBQUksU0FBUztnQ0FDeEIsTUFBTSxDQUFDLE1BQU0sR0FBRyxZQUFZLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUM7NEJBQzNELE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO3lCQUNoQztxQkFDSjtpQkFFSjtnQkFDRCwwQkFBZSxFQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO2dCQUM3QixlQUFlLENBQUMsTUFBTSxFQUFFLFlBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQztnQkFFNUMsT0FBTyxNQUFNLENBQUM7YUFDakI7UUFDTCxDQUFDO0tBQUE7SUFJRCxNQUFNLFVBQVUsR0FBRyxZQUFLLENBQUMsWUFBWSxDQUFDO0lBQ3RDLE1BQU0sU0FBUyxHQUFHLGtCQUFPLEdBQUUsQ0FBQztJQUM1QixJQUFJLFNBQVMsSUFBSSxJQUFJLEVBQUU7UUFDbkIsT0FBTyxDQUFDLGtCQUFPLEdBQUUsRUFBRSxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUU7WUFDaEMsbUJBQVEsRUFBQztnQkFDTCxJQUFJLEVBQUUsa0JBQWtCO2dCQUN4QixJQUFJLEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQyxJQUFJO2dCQUNyQixTQUFTLEVBQUUsU0FBUztnQkFDcEIsSUFBSSxFQUFFLENBQUM7YUFDVixDQUFDLENBQUM7WUFDSCwwQkFBZSxFQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ2hDLENBQUMsQ0FBQyxDQUFDO0tBQ047QUFFTCxDQUFDO0FBdE1RLG9DQUFZOzs7Ozs7Ozs7Ozs7OztBQ1lyQixvR0FHd0I7QUFHeEIseUNBQXlDO0FBQ3pDLDBDQUEwQztBQUMxQyxJQUFJLGdCQUE0QixDQUFDO0FBTWpDLG1FQUFtRTtBQUNuRSxTQUFTLFVBQVU7SUFDZixJQUFJLEtBQUssQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUU7UUFDeEMsZ0JBQWdCLEdBQUcsS0FBSyxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDbEQsTUFBTSxJQUFJLEdBQUcsYUFBYSxDQUFDLGdCQUFnQixDQUFDLENBQUM7UUFFN0MsSUFBSSxnQkFBZ0IsQ0FBQyxJQUFJLElBQUksTUFBTSxFQUFFO1lBQ2pDLE1BQU0sR0FBRyxHQUFHLDhCQUFjLENBQUMsVUFBVSxHQUFHLGtCQUFrQixDQUFFLGdCQUE2QixDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQ3RHLEtBQUssQ0FBQyxFQUFFLENBQUMsV0FBVyxDQUFDO2dCQUNqQixJQUFJLEVBQUUsWUFBWTtnQkFDbEIsR0FBRyxFQUFFLEdBQUc7YUFDWCxDQUFDLENBQUM7U0FHTjthQUNELElBQUksSUFBSSxJQUFJLElBQUksRUFBRTtZQUNkLE1BQU0sSUFBSSxHQUFHLEtBQUssQ0FBQyxVQUFVLEVBQUUsQ0FBQztZQUNoQyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzFDLEtBQUssQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFFBQW9CLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFO2dCQUNyRCxJQUFJO29CQUNBLElBQUksQ0FBQyxJQUFJLEdBQUcsZ0JBQWdCLENBQUMsSUFBSSxDQUFDO29CQUNsQyxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7b0JBQzVCLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQztvQkFDOUIsSUFBSSxDQUFDLENBQUMsR0FBRyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUM7b0JBQzVCLElBQUksQ0FBQyxDQUFDLEdBQUcsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDO29CQUM1QixnQkFBZ0IsQ0FBQyxNQUFNLEVBQUUsQ0FBQztvQkFDMUIsS0FBSyxDQUFDLFdBQVcsQ0FBQyxTQUFTLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztpQkFDeEM7Z0JBQUMsT0FBTyxLQUFLLEVBQUU7b0JBQ1osS0FBSyxDQUFDLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO2lCQUN0QztZQUNMLENBQUMsQ0FBQztTQUNMO0tBQ0o7QUFDTCxDQUFDO0FBeERHLGdDQUFVO0FBMERkLGdEQUFnRDtBQUNoRCxTQUFTLGFBQWEsQ0FBQyxJQUFnQjtJQUNuQyxJQUFJO1FBQ0EsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUM1QyxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO0tBQ3pCO0lBQUMsT0FBTyxDQUFDLEVBQUU7UUFDUixPQUFPLElBQUksQ0FBQztLQUNmO0FBQ0wsQ0FBQztBQW5FRyxzQ0FBYTtBQXFFakIsa0RBQWtEO0FBQ2xELFNBQVMsVUFBVSxDQUFDLEdBQVk7SUFDNUIsTUFBTSxJQUFJLEdBQUcsS0FBSyxDQUFDLGlCQUFpQixDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBRTFDLHFGQUFxRjtJQUNyRixNQUFNLFFBQVEsR0FBRyxnQkFBNEIsQ0FBQztJQUU5QyxNQUFNLE1BQU0sR0FBRyxLQUFLLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUM7SUFDckQsTUFBTSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUd6QixNQUFNLFNBQVMsR0FBaUI7UUFDNUIsUUFBUSxFQUFFLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFXO1FBQ25ELElBQUksRUFBRSxRQUFRLENBQUMsVUFBVTtLQUM1QjtJQUNELElBQUksQ0FBQyxhQUFhLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztJQUUzRCxJQUFJLENBQUMsSUFBSSxHQUFHLFNBQVMsQ0FBQyxJQUFJLENBQUM7SUFDM0IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQyxDQUFDO0lBQ3pDLElBQUksQ0FBQyxDQUFDLEdBQUcsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDO0lBQzVCLElBQUksQ0FBQyxDQUFDLEdBQUcsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDO0lBRTVCLGdCQUFnQixDQUFDLE1BQU0sRUFBRSxDQUFDO0lBQzFCLEtBQUssQ0FBQyxXQUFXLENBQUMsU0FBUyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7QUFFekMsQ0FBQztBQTVGRyxnQ0FBVTtBQThGZCxzQ0FBc0M7QUFDdEMsU0FBUyxhQUFhLENBQUMsV0FBb0I7SUFFdkMsb0ZBQW9GO0lBQ3BGLFNBQVMsU0FBUyxDQUFDLElBQWU7UUFDOUIsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUM7UUFDbkMsTUFBTSxTQUFTLEdBQUcsQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLDhCQUFjLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztRQUVqRSxJQUFJLE9BQU8sSUFBSSxDQUFDLFFBQVEsSUFBSSxRQUFRLEVBQUUsNkJBQTZCO1NBQ25FO1lBQ0ksU0FBUyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztTQUNyRDthQUFNO1lBQ0gsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEdBQUcsRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDMUIsU0FBUyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBYSxDQUFDLENBQUM7YUFDbkY7U0FDSjtRQUNELE9BQU8sT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQztJQUNsQyxDQUFDO0lBRUQsMkdBQTJHO0lBQzNHLE1BQU0sS0FBSyxHQUFHLDhCQUFjLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUM7SUFDdkQsSUFBSSxLQUFLLElBQUksQ0FBQyxDQUFDLEVBQUUsd0JBQXdCO1FBQ3JDLDhCQUFjLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFDMUMsOEJBQWMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO0lBQ3ZDLGdDQUFZLEdBQUUsQ0FBQztJQUNmLEtBQUssQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLDhCQUFjLENBQUMsQ0FBQyxDQUFDO0lBRzFFLHdDQUF3QztJQUN4QyxNQUFNLEtBQUssR0FBRyxLQUFLLENBQUMsV0FBVyxDQUFDLGlCQUFpQixDQUFDO0lBQ2xELElBQUksS0FBSyxJQUFJLElBQUksRUFBRTtRQUNmLFNBQVMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUM1QixLQUFLLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxLQUFLLEVBQUUsV0FBVyxHQUFHLEdBQUcsQ0FBQyxDQUFDO1lBQzVELE1BQU0sSUFBSSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLEtBQUssRUFBRSxLQUFLLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBVyxDQUFDO1lBQ2pGLEtBQUssQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLEtBQUssRUFBRSxLQUFLLENBQUMsS0FBSyxHQUFHLFdBQVcsQ0FBQyxNQUFNLEVBQUUsOEJBQWMsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUNwRyxLQUFLLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxLQUFLLEVBQUUsS0FBSyxDQUFDLEtBQUssR0FBRyxXQUFXLENBQUMsTUFBTSxFQUFFLElBQUksR0FBRyw4QkFBYyxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBQy9HLHVDQUF1QztZQUN2QyxLQUFLLENBQUMsV0FBVyxDQUFDLGlCQUFpQixHQUFHO2dCQUNsQyxJQUFJLEVBQUUsS0FBSyxDQUFDLElBQUk7Z0JBQ2hCLEtBQUssRUFBRSxLQUFLLENBQUMsS0FBSyxHQUFHLFdBQVcsQ0FBQyxNQUFNLEdBQUcsQ0FBQztnQkFDM0MsR0FBRyxFQUFFLEtBQUssQ0FBQyxLQUFLLEdBQUcsV0FBVyxDQUFDLE1BQU0sR0FBRyxDQUFDO2FBQzVDLENBQUM7UUFDTixDQUFDLENBQUMsQ0FBQztRQUNILEdBQUc7S0FFTjtBQUNMLENBQUM7QUEzSUcsc0NBQWE7Ozs7Ozs7Ozs7Ozs7O0FDcUJqQixtQ0FBbUM7QUFDbkMsSUFBSyxVQUlKO0FBSkQsV0FBSyxVQUFVO0lBQ2IsbURBQVE7SUFDUiw2Q0FBSztJQUNMLGlEQUFPO0FBQ1QsQ0FBQyxFQUpJLFVBQVUsS0FBVixVQUFVLFFBSWQ7QUF2QkMsZ0NBQVU7QUF5QlosdUNBQXVDO0FBQ3ZDLElBQUssVUFJSjtBQUpELFdBQUssVUFBVTtJQUNiLDJDQUFJO0lBQ0osNkNBQUs7SUFDTCxpREFBTztBQUNULENBQUMsRUFKSSxVQUFVLEtBQVYsVUFBVSxRQUlkO0FBN0JDLGdDQUFVOzs7Ozs7Ozs7Ozs7OztBQ0haLHlFQUtlO0FBR2Ysa0VBQWtFO0FBS2xFLHdIQUF3SDtBQUN4SCx3Q0FBd0M7QUFDeEMsMEJBQTBCO0FBQzFCLCtFQUErRTtBQUUvRSxTQUFTLGNBQWM7SUFHbkIsTUFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUM7SUFFdEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7TUF5QkU7SUFFRixJQUFJLGFBQWEsR0FBRyxJQUFJLEVBQUU7UUFDdEIscURBQXFEO1FBQ3JELE1BQU0sVUFBVSxHQUFHLFlBQUssQ0FBQyxZQUFZLENBQUM7UUFDdEMsS0FBSyxNQUFNLEtBQUssSUFBSSxvQkFBUyxHQUFFLEVBQUU7WUFDN0Isc0RBQXNEO1lBQ3RELDBCQUFlLEVBQUMsS0FBSyxDQUFDLENBQUM7WUFDdkIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7WUFDWCxLQUFLLE1BQU0sS0FBSyxJQUFJLFlBQUssQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFO2dCQUN2QyxDQUFDLEVBQUUsQ0FBQztnQkFDSixLQUFLLENBQUMsT0FBTyxHQUFHLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQzthQUVoQztZQUNELFlBQUssQ0FBQyxZQUFZLENBQUMsYUFBYSxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQztZQUMxRCwwQkFBZSxHQUFFLENBQUM7U0FDckI7UUFDRCxJQUFJLFVBQVUsSUFBSSxJQUFJO1lBQ2xCLE9BQU8sQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDOztZQUUxQiwwQkFBZSxFQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ2hDLE9BQU8sQ0FBQyxHQUFHLENBQUMseUNBQXlDLENBQUMsQ0FBQztRQUN2RCxLQUFLLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLEVBQUUsTUFBTSxDQUFDLENBQUM7S0FDL0M7QUFFTCxDQUFDO0FBN0VHLHdDQUFjOzs7Ozs7O1VDRmxCO1VBQ0E7O1VBRUE7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7O1VBRUE7VUFDQTs7VUFFQTtVQUNBO1VBQ0E7Ozs7VUV0QkE7VUFDQTtVQUNBO1VBQ0EiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9zbGFqZG9tYXQvLi9zcmMvY29tbW9uL2FuaW1hdGUtcGFyYW1zLnRzIiwid2VicGFjazovL3NsYWpkb21hdC8uL3NyYy9jb21tb24vaGVscGVyLnRzIiwid2VicGFjazovL3NsYWpkb21hdC8uL3NyYy9wbHVnaW4vY29kZS1jaGlsZC1ldmVudHMudHMiLCJ3ZWJwYWNrOi8vc2xhamRvbWF0Ly4vc3JjL3BsdWdpbi9jb2RlLW5hbWUtbWFuYWdlbWVudC50cyIsIndlYnBhY2s6Ly9zbGFqZG9tYXQvLi9zcmMvcGx1Z2luL2NvZGUtb3ZlcmxheS1ldmVudHMudHMiLCJ3ZWJwYWNrOi8vc2xhamRvbWF0Ly4vc3JjL3BsdWdpbi9jb2RlLXNldHRpbmdzLnRzIiwid2VicGFjazovL3NsYWpkb21hdC8uL3NyYy9wbHVnaW4vY29kZS10aHVtYm5haWxzLnRzIiwid2VicGFjazovL3NsYWpkb21hdC8uL3NyYy9wbHVnaW4vY29kZS10aW1lbGluZS50cyIsIndlYnBhY2s6Ly9zbGFqZG9tYXQvLi9zcmMvcGx1Z2luL2NvZGUudHMiLCJ3ZWJwYWNrOi8vc2xhamRvbWF0Ly4vc3JjL3BsdWdpbi9leHBvcnQudHMiLCJ3ZWJwYWNrOi8vc2xhamRvbWF0Ly4vc3JjL3BsdWdpbi9tYXRlbWF0eWsudHMiLCJ3ZWJwYWNrOi8vc2xhamRvbWF0Ly4vc3JjL3BsdWdpbi9wbHVnaW4tdHlwZXMudHMiLCJ3ZWJwYWNrOi8vc2xhamRvbWF0Ly4vc3JjL3BsdWdpbi9wbHVnaW4tdmVyc2lvbi50cyIsIndlYnBhY2s6Ly9zbGFqZG9tYXQvd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vc2xhamRvbWF0L3dlYnBhY2svYmVmb3JlLXN0YXJ0dXAiLCJ3ZWJwYWNrOi8vc2xhamRvbWF0L3dlYnBhY2svc3RhcnR1cCIsIndlYnBhY2s6Ly9zbGFqZG9tYXQvd2VicGFjay9hZnRlci1zdGFydHVwIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCB7TW9kaWZ5aW5nRXZlbnRzLCBtb2RpZnlpbmdFdmVudHMsIGN1cnJlbnRQYXJhbXN9IFxuXG5pbXBvcnQgeyBBbmltYXRlRXZlbnQsIEFuaW1hdGlvblBhcmFtcywgUHJlc2VudGF0aW9uTm9kZSwgU2hvd0hpZGVFdmVudCB9IGZyb20gXCIuL3R5cGVzXCI7XG5cbnR5cGUgTW9kaWZ5aW5nRXZlbnRzID1cbiAgICB7XG4gICAgICAgIHh5OiBBbmltYXRlRXZlbnQgfCAnb3JpZ2luYWwnIHwgJ25vdCBtb2RpZmllZCcsXG4gICAgICAgIG9wYWNpdHk6IFNob3dIaWRlRXZlbnQgfCAnYmVmb3JlIGZpcnN0IHNob3cnIHwgJ2JlZm9yZSBmaXJzdCBoaWRlJyB8ICdub3QgbW9kaWZpZWQnXG4gICAgfVxuXG5cblxuLy8gcmV0dXJucyB0aGUgZXZlbnRzIHRoYXQgbW9kaWZ5IHRoZSBnaXZlbiBpZCwgYW5kIG9jY3VyIDwgdGhlIGdpdmVuIGluZGV4XG4vLyB0aGUgeHkgcHJvcGVydHkgaXMgbW9kaWZpZWQgYnkgYW5pbWF0ZSBldmVudHMsIHdoaWxlIHRoZSBvcGFjaXR5IHByb3BlcnR5IGlzIG1vZGlmaWVkIGJ5IHNob3cvaGlkZSBldmVudHMuIEV2ZW5lbnR1YWxseSwgYW5pbWF0ZSBldmVudHMgd2lsbCBhbHNvIG1vZGlmeSB0aGUgb3BhY2l0eSwgYnV0IHRoaXMgaXMgbm90IGltcGxlbWVudGVkIHlldC5cbmZ1bmN0aW9uIG1vZGlmeWluZ0V2ZW50cyhpZDogc3RyaW5nLCBpbmRleDogbnVtYmVyLCBldmVudHM6IFByZXNlbnRhdGlvbk5vZGVbXSk6IE1vZGlmeWluZ0V2ZW50cyB7XG4gICAgY29uc3QgcmV0dmFsID0ge1xuICAgICAgICB4eTogJ25vdCBtb2RpZmllZCcsXG4gICAgICAgIG9wYWNpdHk6ICdub3QgbW9kaWZpZWQnXG4gICAgfSBhcyBNb2RpZnlpbmdFdmVudHM7XG5cbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGV2ZW50cy5sZW5ndGg7IGkrKykge1xuICAgICAgICBjb25zdCBldmVudCA9IGV2ZW50c1tpXTtcbiAgICAgICAgaWYgKGV2ZW50LnR5cGUgPT0gJ2FuaW1hdGUnICYmIGV2ZW50LmlkID09IGlkKSB7XG4gICAgICAgICAgICBpZiAoaSA8IGluZGV4KVxuICAgICAgICAgICAgICAgIHJldHZhbC54eSA9IGV2ZW50O1xuICAgICAgICAgICAgZWxzZSBpZiAocmV0dmFsLnh5ID09ICdub3QgbW9kaWZpZWQnKVxuICAgICAgICAgICAgICAgIHJldHZhbC54eSA9ICdvcmlnaW5hbCc7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKChldmVudC50eXBlID09ICdzaG93JyB8fCBldmVudC50eXBlID09ICdoaWRlJykgJiYgZXZlbnQuaWQgPT0gaWQpIHtcbiAgICAgICAgICAgIGlmIChpIDwgaW5kZXgpXG4gICAgICAgICAgICAgICAgcmV0dmFsLm9wYWNpdHkgPSBldmVudDtcbiAgICAgICAgICAgIGVsc2UgaWYgKHJldHZhbC5vcGFjaXR5ID09ICdub3QgbW9kaWZpZWQnKVxuICAgICAgICAgICAgICAgIGlmIChldmVudC50eXBlID09ICdzaG93JylcbiAgICAgICAgICAgICAgICAgICAgcmV0dmFsLm9wYWNpdHkgPSAnYmVmb3JlIGZpcnN0IHNob3cnO1xuICAgICAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgICAgICAgcmV0dmFsLm9wYWNpdHkgPSAnYmVmb3JlIGZpcnN0IGhpZGUnO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiByZXR2YWw7XG59XG5cblxuLy8gcmV0dXJucyB0aGUgYW5pbWF0aW9uIHBhcmFtZXRlcnMsIGkuZS4gb3BhY2l0eSBhbmQgeHksIGZvciB0aGUgc3ZnIHdpdGggaWQgaWQsIGFmdGVyIGV4ZWN1dGluZyBhbGwgb3ZlcmxheXMgd2l0aCBwb3NpdGlvbiA8IGluZGV4XG4vLyBpZiB0aGUgZXZlbnQgaXMgaGlkZGVuLCB0aGVuIHRoZSBoaWRkZW5PcGFjaXR5IGlzIHVzZWRcbi8vIHdlIHBhc3MgdGhlIGxpc3Qgb2YgZXZlbnRzIGFuZCB0aGUgb3JpZ2luYWwgcGFyYW1ldGVyc1xuZnVuY3Rpb24gY3VycmVudFBhcmFtcyhpZDogc3RyaW5nLCBpbmRleDogbnVtYmVyLCBldmVudHM6IFByZXNlbnRhdGlvbk5vZGVbXSxcbiAgICBvcmlnaW5hbFBhcmFtczogeyBbaWQ6IHN0cmluZ106IEFuaW1hdGlvblBhcmFtcyB9LFxuICAgIGhpZGRlbk9wYWNpdHk6IG51bWJlcik6IEFuaW1hdGlvblBhcmFtcyB7XG4gICAgY29uc3QgcmV0dmFsID0ge30gYXMgQW5pbWF0aW9uUGFyYW1zO1xuXG4gICAgY29uc3QgbW9kaWZ5aW5nID0gbW9kaWZ5aW5nRXZlbnRzKGlkLCBpbmRleCwgZXZlbnRzKTtcblxuXG4gICAgc3dpdGNoIChtb2RpZnlpbmcueHkpIHtcbiAgICAgICAgY2FzZSAnbm90IG1vZGlmaWVkJzpcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICdvcmlnaW5hbCc6XG4gICAgICAgICAgICByZXR2YWwueCA9IG9yaWdpbmFsUGFyYW1zW2lkXS54O1xuICAgICAgICAgICAgcmV0dmFsLnkgPSBvcmlnaW5hbFBhcmFtc1tpZF0ueTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgcmV0dmFsLnggPSBtb2RpZnlpbmcueHkucGFyYW1zLng7XG4gICAgICAgICAgICByZXR2YWwueSA9IG1vZGlmeWluZy54eS5wYXJhbXMueTtcbiAgICB9XG5cblxuICAgIGxldCBtb2RlOiAndmlzaWJsZScgfCAnaGlkZGVuJztcblxuICAgIHN3aXRjaCAobW9kaWZ5aW5nLm9wYWNpdHkpIHtcbiAgICAgICAgY2FzZSAnbm90IG1vZGlmaWVkJzpcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICdiZWZvcmUgZmlyc3Qgc2hvdyc6XG4gICAgICAgICAgICBtb2RlID0gJ2hpZGRlbic7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSAnYmVmb3JlIGZpcnN0IGhpZGUnOlxuICAgICAgICAgICAgbW9kZSA9ICd2aXNpYmxlJztcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgaWYgKG1vZGlmeWluZy5vcGFjaXR5LnR5cGUgPT0gJ3Nob3cnKVxuICAgICAgICAgICAgICAgIG1vZGUgPSAndmlzaWJsZSc7XG4gICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgbW9kZSA9ICdoaWRkZW4nO1xuICAgIH1cblxuXG4gICAgaWYgKG1vZGUgPT0gJ2hpZGRlbicpIHtcbiAgICAgICAgcmV0dmFsLm9wYWNpdHkgPSBoaWRkZW5PcGFjaXR5O1xuICAgIH1cbiAgICBpZiAobW9kZSA9PSAndmlzaWJsZScpIHtcbiAgICAgICAgaWYgKG9yaWdpbmFsUGFyYW1zW2lkXSAhPSB1bmRlZmluZWQgJiYgb3JpZ2luYWxQYXJhbXNbaWRdLm9wYWNpdHkgIT0gdW5kZWZpbmVkKVxuICAgICAgICAgICAgcmV0dmFsLm9wYWNpdHkgPSBvcmlnaW5hbFBhcmFtc1tpZF0ub3BhY2l0eTtcbiAgICAgICAgZWxzZVxuICAgICAgICAgICAgcmV0dmFsLm9wYWNpdHkgPSAxO1xuICAgIH1cbiAgICByZXR1cm4gcmV0dmFsO1xufSIsImV4cG9ydCB7IGZyZXNoTmFtZSwgc2FuaXRpemUsIGZyZXNoUmVjdCwgdG9BbHBoYU51bWVyaWMgfVxuXG4vL2dpdmVzIGEgbmFtZSwgc3RhcnRpbmcgd2l0aCBiYXNlLCB3aGljaCBpcyBub3Qgb24gdGhlIGF2b2lkIGxpc3RcbmZ1bmN0aW9uIGZyZXNoTmFtZShiYXNlOiBzdHJpbmcsIGF2b2lkOiBzdHJpbmdbXSk6IHN0cmluZyB7XG4gICAgbGV0IGNhbmRpZGF0ZSA9IGJhc2U7XG4gICAgaWYgKGF2b2lkLmluZGV4T2YoY2FuZGlkYXRlKSA+IC0xKSB7XG4gICAgICAgIC8vd2UgbmVlZCB0byBkZWNvcmF0ZSB0aGUgbmFtZTtcbiAgICAgICAgbGV0IGluZGV4ID0gMjtcblxuICAgICAgICBkbyB7XG4gICAgICAgICAgICBjYW5kaWRhdGUgPSBiYXNlICsgaW5kZXgudG9TdHJpbmcoKTtcbiAgICAgICAgICAgIGluZGV4Kys7XG4gICAgICAgIH0gd2hpbGUgKGF2b2lkLmluZGV4T2YoY2FuZGlkYXRlKSA+IC0xKVxuXG4gICAgfVxuXG4gICAgcmV0dXJuIGNhbmRpZGF0ZTtcbn1cblxuXG4vL2ZpbmRzIGEgcGxhY2UgZm9yIHRoZSBuZXcgc2xpZGUsIGJ5IHNlYXJjaGluZyBpbiBhIHNwaXJhbCBhcm91bmQgdGhlIGN1cnJlbnQgc2xpZGUgKG9yIHRoZSBvcmlnaW4sIGlmIHRoZXJlIGlzIG5vIGN1cnJlbnQgc2xpZGUpXG5mdW5jdGlvbiBmcmVzaFJlY3QoeDogbnVtYmVyLCB5IDogbnVtYmVyLCB3aWR0aDogbnVtYmVyLCBoZWlnaHQ6IG51bWJlciwgYXZvaWRMaXN0OiBGcmFtZU5vZGVbXSwgZGltZW5zaW9uczogeyB3aWR0aDogbnVtYmVyLCBoZWlnaHQ6IG51bWJlciB9KTogUmVjdCB7XG5cbiAgICBsZXQgaW5zaWRlRnJhbWU6IFJlY3Q7XG4gICAgLy90aGlzIGlzIHRoZSBmcmFtZSB0aGF0IHdlIHNob3VsZCBzdGF5IGluc2lkZVxuICAgIGlmIChkaW1lbnNpb25zICE9IHVuZGVmaW5lZClcbiAgICAgICAgaW5zaWRlRnJhbWUgPSB7IHg6IDAsIHk6IDAsIHdpZHRoOiBkaW1lbnNpb25zLndpZHRoLCBoZWlnaHQ6IGRpbWVuc2lvbnMuaGVpZ2h0IH07XG5cbiAgICBsZXQgaW5pdGlhbCA9IHsgeDogeCwgeSA6IHksIHdpZHRoIDogd2lkdGgsIGhlaWdodCA6IGhlaWdodH07XG5cbiAgICBmdW5jdGlvbiBpbnRlcnNlY3RzKGE6IFJlY3QsIGI6IEZyYW1lTm9kZSB8IFJlY3QpIHtcbiAgICAgICAgaWYgKGIgPT0gdW5kZWZpbmVkKVxuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIGlmIChhLnggPiBiLnggKyBiLndpZHRoIHx8IGEueCArIGEud2lkdGggPCBiLngpXG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIGlmIChhLnkgPiBiLnkgKyBiLmhlaWdodCB8fCBhLnkgKyBhLmhlaWdodCA8IGIueSlcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuXG4gICAgLy9zZWFyY2ggZm9yIGZyZWUgc3BhY2UgYmVsb3cgdGhlIGN1cnJlbnQgc2xpZGUsXG4gICAgLy91c2luZyB0aGUgY2l0eSBtZXRyaWMgKGkuZS4gdGhlIHNlYXJjaCBmb2xsb3dzIGEgc3F1YXJlIHNwaXJhbCBwYXR0ZXJuKSBcblxuICAgIGNvbnN0IHhvZmZzZXQgPSB3aWR0aCAqIDEuMTtcbiAgICBjb25zdCB5b2Zmc2V0ID0gaGVpZ2h0ICogMS4xO1xuXG5cbiAgICBmb3IgKGxldCBpID0gMDsgdHJ1ZTsgaSsrKVxuICAgICAgICBmb3IgKGxldCBqID0gMDsgaiA8PSBpOyBqKyspIHtcblxuXG4gICAgICAgICAgICBsZXQgY2FuZGlkYXRlczogUmVjdFtdID0gW107XG5cbiAgICAgICAgICAgIGNhbmRpZGF0ZXMucHVzaCh7IHdpZHRoOiBpbml0aWFsLndpZHRoLCBoZWlnaHQ6IGluaXRpYWwuaGVpZ2h0LCB4OiBpbml0aWFsLnggKyBqICogeG9mZnNldCwgeTogaW5pdGlhbC55ICsgaSAqIHlvZmZzZXQgfSk7XG4gICAgICAgICAgICBjYW5kaWRhdGVzLnB1c2goeyB3aWR0aDogaW5pdGlhbC53aWR0aCwgaGVpZ2h0OiBpbml0aWFsLmhlaWdodCwgeDogaW5pdGlhbC54ICsgaSAqIHhvZmZzZXQsIHk6IGluaXRpYWwueSArIGogKiB5b2Zmc2V0IH0pO1xuICAgICAgICAgICAgY2FuZGlkYXRlcy5wdXNoKHsgd2lkdGg6IGluaXRpYWwud2lkdGgsIGhlaWdodDogaW5pdGlhbC5oZWlnaHQsIHg6IGluaXRpYWwueCAtIGogKiB4b2Zmc2V0LCB5OiBpbml0aWFsLnkgKyBpICogeW9mZnNldCB9KTtcbiAgICAgICAgICAgIGNhbmRpZGF0ZXMucHVzaCh7IHdpZHRoOiBpbml0aWFsLndpZHRoLCBoZWlnaHQ6IGluaXRpYWwuaGVpZ2h0LCB4OiBpbml0aWFsLnggLSBpICogeG9mZnNldCwgeTogaW5pdGlhbC55ICsgaiAqIHlvZmZzZXQgfSk7XG5cbiAgICAgICAgICAgIGxldCBzb21lRml0cyA9IGZhbHNlO1xuICAgICAgICAgICAgZm9yIChjb25zdCBjYW5kaWRhdGUgb2YgY2FuZGlkYXRlcykge1xuXG4gICAgICAgICAgICAgICAgaWYgKGludGVyc2VjdHMoY2FuZGlkYXRlLCBpbnNpZGVGcmFtZSkpIHtcbiAgICAgICAgICAgICAgICAgICAgc29tZUZpdHMgPSB0cnVlO1xuXG4gICAgICAgICAgICAgICAgICAgIGxldCBpbnRlcnNlY3RzQXZvaWRMaXN0ID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgIGZvciAoY29uc3QgYXZvaWQgb2YgYXZvaWRMaXN0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoaW50ZXJzZWN0cyhjYW5kaWRhdGUsIGF2b2lkKSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbnRlcnNlY3RzQXZvaWRMaXN0ID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBpZiAoIWludGVyc2VjdHNBdm9pZExpc3QpXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gY2FuZGlkYXRlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKCFzb21lRml0cylcbiAgICAgICAgICAgICAgICByZXR1cm4gaW5pdGlhbDtcblxuXG4gICAgICAgIH1cblxufVxuXG5cbmZ1bmN0aW9uIHRvQWxwaGFOdW1lcmljKHM6IHN0cmluZyk6IHN0cmluZyB7XG4gICAgcmV0dXJuIHMucmVwbGFjZSgvW15hLXpBLVowLTldL2csICdfJyk7XG59XG5cbi8vc2FuaXRpemUgYSBzdHJpbmcgc28gdGhhdCBpdCBpcyBhIGdvb2QgZmlsZW5hbWUgXG5mdW5jdGlvbiBzYW5pdGl6ZShzOiBzdHJpbmcpOiBzdHJpbmcge1xuICAgIGNvbnN0IHJlcGxhY2VzID0gW1xuICAgICAgICBbJzonLCAnX2NvbG9uJ10sXG4gICAgICAgIFsnJTIwJywgJ18nXSxcbiAgICAgICAgWyclJywgJ19wZXJjZW50J10sXG4gICAgICAgIFsnKicsICdfc3RhciddLFxuICAgICAgICBbJz8nLCAnX3F1ZXN0aW9uJ11cbiAgICBdO1xuICAgIGxldCByZXR2YWwgPSBlbmNvZGVVUkkocyk7XG4gICAgZm9yIChjb25zdCByZXBsYWNlIG9mIHJlcGxhY2VzKVxuICAgICAgICByZXR2YWwgPSByZXR2YWwucmVwbGFjZShyZXBsYWNlWzBdLCByZXBsYWNlWzFdKTtcblxuICAgIHJldHVybiByZXR2YWw7XG59XG4iLCIvKiBUaGlzIGZpbGUgY29udGFpbnMgdGhlIGNvZGUgZm9yIGNyZWF0aW5nIGNoaWxkIGV2ZW50cyBpbiBhIHNsaWRlLiAqL1xuXG5leHBvcnQgeyBjcmVhdGVDaGlsZEV2ZW50LCBjcmVhdGVOZXdTbGlkZSwgY3JlYXRlVGh1bWJuYWlsIH07XG5cbiAgICBpbXBvcnQgeyBmcmVzaE5hbWUsIGZyZXNoUmVjdCwgdG9BbHBoYU51bWVyaWMgfSBmcm9tIFwiLi4vY29tbW9uL2hlbHBlclwiO1xuICAgIGltcG9ydCB7IERhdGFiYXNlLCBTbGlkZSB9IGZyb20gXCIuLi9jb21tb24vdHlwZXNcIjtcbiAgICBpbXBvcnQgeyBhbGxTbGlkZXMsIGZpbmRTbGlkZSwgc3RhdGUgfSBmcm9tIFwiLi9jb2RlXCI7XG4gICAgaW1wb3J0IHsgYXZvaWRMaXN0LCBuZXdFdmVudElkIH0gZnJvbSBcIi4vY29kZS1uYW1lLW1hbmFnZW1lbnRcIjtcbiAgICBpbXBvcnQgeyBjcmVhdGVUaHVtYm5haWwgfSBmcm9tIFwiLi9jb2RlLXRodW1ibmFpbHNcIjtcblxuXG4vL0NyZWF0ZXMgYSBuZXcgc2xpZGUgb2YgZ2l2ZW4gd2lkdGggYW5kIGhlaWdodC4gVGhlIHBsYWNlIGZvciB0aGUgbmV3IHNsaWRlIGlzIGNob3NlbiB0byBiZSBjbG9zZSB0byB0aGUgY3VycmVudCBzbGlkZS5cbmZ1bmN0aW9uIGNyZWF0ZU5ld1NsaWRlKHdpZHRoOiBudW1iZXIsIGhlaWdodDogbnVtYmVyLCBuYW1lOiBzdHJpbmcpOiBGcmFtZU5vZGUge1xuXG4gICAgbGV0IGJhc2V4LCBiYXNleSA9IDA7XG5cbiAgICB0cnkge1xuICAgICAgICBiYXNleCA9IHN0YXRlLmN1cnJlbnRTbGlkZS54O1xuICAgICAgICBiYXNleSA9IHN0YXRlLmN1cnJlbnRTbGlkZS55O1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgLy90aGUgc2xpZGUgbWlnaHQgbm90IGJlIGRlZmluZWQsIG9yIGRlZmluZWQgYW5kIHJlbW92ZWRcbiAgICAgICAgYmFzZXggPSAwO1xuICAgICAgICBiYXNleSA9IDA7XG4gICAgfVxuXG4gICAgY29uc3QgcGxhY2UgPSBmcmVzaFJlY3QoYmFzZXgsIGJhc2V5LCB3aWR0aCwgaGVpZ2h0LCBhbGxTbGlkZXMoKSwgdW5kZWZpbmVkKTtcbiAgICBjb25zdCBuZXdTbGlkZSA9IGZpZ21hLmNyZWF0ZUZyYW1lKCk7XG4gICAgbmV3U2xpZGUubmFtZSA9IG5hbWU7XG4gICAgbmV3U2xpZGUueCA9IHBsYWNlLng7XG4gICAgbmV3U2xpZGUueSA9IHBsYWNlLnlcbiAgICBuZXdTbGlkZS5yZXNpemUod2lkdGgsIGhlaWdodCk7XG4gICAgY29uc3QgaWQgPSBmcmVzaE5hbWUodG9BbHBoYU51bWVyaWMobmV3U2xpZGUubmFtZSksIGF2b2lkTGlzdCh1bmRlZmluZWQpKTtcbiAgICBjb25zdCBkYXRhYmFzZTogRGF0YWJhc2UgPSB7XG4gICAgICAgIG5hbWU6IG5ld1NsaWRlLm5hbWUsXG4gICAgICAgIGlkOiBpZCxcbiAgICAgICAgc2VsZWN0ZWQ6IHVuZGVmaW5lZCxcbiAgICAgICAgZXZlbnRzOiBbXSxcbiAgICAgICAgb3JpZ2luYWxQYXJhbXM6IHt9XG4gICAgfVxuICAgIG5ld1NsaWRlLnNldFBsdWdpbkRhdGEoXCJkYXRhYmFzZVwiLCBKU09OLnN0cmluZ2lmeShkYXRhYmFzZSkpO1xuXG5cbiAgICByZXR1cm4gbmV3U2xpZGU7XG59XG5cblxuLy9DcmVhdGVzIGEgY2hpbGQgZXZlbnQgaW4gdGhlIGN1cnJlbnQgc2xpZGUsIHRvZ2V0aGVyIHdpdGggYSBjaGlsZCBsaW5rIChhcyBkZXNjcmliZWQgaW4gdGhlIHByZXZpb3VzIGZ1bmN0aW9uKSB0aGF0IHJlcHJlc2VudHMgdGhlIGNoaWxkLiBcbmZ1bmN0aW9uIGNyZWF0ZUNoaWxkRXZlbnQoaWQ6IHN0cmluZyk6IFNsaWRlW10ge1xuXG4gICAgY29uc3Qgc2xpZGU6IEZyYW1lTm9kZSA9IGZpbmRTbGlkZShpZCk7XG4gICAgY29uc3QgbmV3RXZlbnQ6IFNsaWRlID1cbiAgICB7XG4gICAgICAgIHR5cGU6IFwiY2hpbGRcIixcbiAgICAgICAgaWQ6IGlkLFxuICAgICAgICBuYW1lOiBzbGlkZS5uYW1lLFxuICAgICAgICBlbmFibGVkOiAnZW5hYmxlZCcsXG4gICAgICAgIG1lcmdlZDogZmFsc2UsXG4gICAgICAgIGNoaWxkcmVuOiBbXSxcbiAgICAgICAga2V5d29yZHM6IFtdLFxuICAgICAgICBldmVudElkOiBuZXdFdmVudElkKCksXG4gICAgICAgIG9yaWdpbmFsUGFyYW1zOiB1bmRlZmluZWRcbiAgICB9XG5cbiAgICBjb25zdCBuZXdwbGFjZSA9IGZyZXNoUmVjdChzbGlkZS53aWR0aCAvIDIsIHNsaWRlLmhlaWdodCAvIDIsIDEwMCwgMTAwICogc2xpZGUuaGVpZ2h0IC8gc2xpZGUud2lkdGgsIHN0YXRlLmN1cnJlbnRTbGlkZS5jaGlsZHJlbiBhcyBGcmFtZU5vZGVbXSwgc3RhdGUuY3VycmVudFNsaWRlKTtcbiAgICBjb25zdCB0aHVtYm5haWwgPSBjcmVhdGVUaHVtYm5haWwoc3RhdGUuY3VycmVudFNsaWRlLCBpZCwgbmV3cGxhY2UpO1xuICAgIGZpZ21hLmN1cnJlbnRQYWdlLnNlbGVjdGlvbiA9IFt0aHVtYm5haWxdO1xuICAgIHJldHVybiBbbmV3RXZlbnRdO1xufVxuIiwiaW1wb3J0IHsgZnJlc2hOYW1lLCB0b0FscGhhTnVtZXJpYyB9IGZyb20gXCIuLi9jb21tb24vaGVscGVyXCI7XG5pbXBvcnQgeyBhbGxTbGlkZXMsIGdldERhdGFiYXNlLCBzdGF0ZSB9IGZyb20gXCIuL2NvZGVcIjtcbmltcG9ydCB7IGNhbkJlT3ZlcmxheVRhcmdldCB9IGZyb20gXCIuL2NvZGUtb3ZlcmxheS1ldmVudHNcIjtcblxuLyogY29kZSBmb3IgbWFuYWdpbmcgbmFtZXMgYW5kIGlkJ3MgaW4gdGhlIHBsdWdpbiBiYWNrZW5kICovXG5leHBvcnQgeyBhbGxUZXh0cywgYXZvaWRMaXN0LCBmaW5kU2xpZGUsIGdvb2ROYW1lLCBuZXdFdmVudElkLCBvdmVybGF5SWQsIHNsaWRlSWQgfTtcblxuXG4vL2ZpbmQgYSBzbGlkZSBpbiB0aGUgZG9jdW1lbnQgd2l0aCB0aGUgZ2l2ZW4gaWRcbmZ1bmN0aW9uIGZpbmRTbGlkZShpZDogc3RyaW5nKTogRnJhbWVOb2RlIHtcbiAgICBmb3IgKGNvbnN0IG5vZGUgb2YgYWxsU2xpZGVzKCkpXG4gICAgICAgIGlmIChzbGlkZUlkKG5vZGUpID09IGlkKVxuICAgICAgICAgICAgcmV0dXJuIG5vZGU7XG4gICAgcmV0dXJuIG51bGw7XG59XG5cbi8vcmV0dXJucyBhIHVuaXF1ZSBpZCBmb3IgYW4gZXZlbnQsIGluc2lkZSB0aGUgY3VycmVudCBzbGlkZVxuZnVuY3Rpb24gbmV3RXZlbnRJZCgpOiBzdHJpbmcge1xuXG4gICAgLy90aGUgaWQgaXMgYSBudW1iZXIgKHN0b3JlZCBhcyBhIHN0cmluZykuIEluIG9yZGVyIHRvIGFjaGlldmUgdW5pcXVlbmVzcywgd2Ugc3RvcmUgdGhlIG1heGltYWwgaWQgdXNlZCBzbyBmYXIgaW5zaWRlIHRoZSBhdHRyaWJ1dGUgZXZlbnRJZC5cbiAgICBsZXQgcmV0dmFsOiBudW1iZXI7XG4gICAgY29uc3QgbWF4SWQgPSBzdGF0ZS5jdXJyZW50U2xpZGUuZ2V0UGx1Z2luRGF0YSgnZXZlbnRJZCcpO1xuICAgIGlmIChtYXhJZCA9PSAnJylcbiAgICAgICAgcmV0dmFsID0gMTtcbiAgICBlbHNlXG4gICAgICAgIHJldHZhbCA9IHBhcnNlSW50KG1heElkKSArIDE7XG4gICAgc3RhdGUuY3VycmVudFNsaWRlLnNldFBsdWdpbkRhdGEoJ2V2ZW50SWQnLCByZXR2YWwudG9TdHJpbmcoKSk7XG4gICAgcmV0dXJuIHJldHZhbC50b1N0cmluZygpO1xufVxuXG5cbi8vZ2l2ZSB0aGUgbGlzdCBvZiBhbGwgdGV4dHMgdXNlZCBpbiBkZXNjZW5kYW50c1xuLy90aGlzIGZ1bmN0aW9uIGlzIHVzZWQgaW4gZ29vZE5hbWUgYmVsb3csIGFuZCBhbHNvIHRvIGV4cG9ydCBrZXl3b3Jkc1xuZnVuY3Rpb24gYWxsVGV4dHMobjogU2NlbmVOb2RlLCBhdm9pZDogU2NlbmVOb2RlW10gPSBbXSk6IHN0cmluZ1tdIHtcblxuICAgIGlmIChhdm9pZC5pbmNsdWRlcyhuKSlcbiAgICAgICAgcmV0dXJuIFtdO1xuXG4gICAgaWYgKG4udHlwZSA9PSAnVEVYVCcpIHtcbiAgICAgICAgcmV0dXJuIFtuLm5hbWVdO1xuICAgIH1cbiAgICBpZiAobi50eXBlID09ICdHUk9VUCcgfHwgbi50eXBlID09ICdGUkFNRScpIHtcbiAgICAgICAgbGV0IHJldHZhbDogc3RyaW5nW10gPSBbXTtcbiAgICAgICAgZm9yIChjb25zdCBjaGlsZCBvZiBuLmNoaWxkcmVuKSB7XG4gICAgICAgICAgICByZXR2YWwgPSByZXR2YWwuY29uY2F0KGFsbFRleHRzKGNoaWxkIGFzIFNjZW5lTm9kZSwgYXZvaWQpKVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXR2YWw7XG4gICAgfVxuICAgIC8vb3RoZXJ3aXNlIHRoZXJlIGFyZSBubyBzdHJpbmdzXG4gICAgcmV0dXJuIFtdO1xufVxuXG5cbi8vQ3JlYXRlcyBhIGRlc2NyaXB0aXZlIHN0cmluZyBuYW1lIGZvciBhIG5vZGUuIEl0IHdpbGwgYmUgY2FsbGVkIGlmIHRoZSBub2RlIGlzIGEgZ3JvdXAgbm9kZSB3aXRoIGEgbmFtZSBsaWtlIFwiR3JvdXAgMlwiLiBUaGUgY3VycmVudCBpbXBsZW1lbnRhdGlvbiByZXR1cm5zIHRoZSBjb250ZW50cyB0aGUgbG9uZ2VzdCB0ZXh0IG5vZGUgaW4gdGhlIGRlc2NlbmRhbnRzLiBcbmZ1bmN0aW9uIGdvb2ROYW1lKG5vZGU6IFNjZW5lTm9kZSk6IHN0cmluZyB7XG4gICAgY29uc3QgdGV4dHMgPSBhbGxUZXh0cyhub2RlKTtcblxuICAgIC8vaWYgdGhlcmUgaXMgbm8gdGV4dCwgZG8gbm90IGNoYW5nZSB0aGUgbmFtZVxuICAgIGlmICh0ZXh0cy5sZW5ndGggPT0gMClcbiAgICAgICAgcmV0dXJuIG5vZGUubmFtZTtcblxuICAgIC8vb3RoZXJ3aXNlLCByZXR1cm4gdGhlIGxvbmdlc3QgdGV4dCAgICBcbiAgICBsZXQgcmV0dmFsID0gdGV4dHNbMF07XG4gICAgZm9yIChjb25zdCB0ZXh0IG9mIHRleHRzKSB7XG4gICAgICAgIGlmICh0ZXh0Lmxlbmd0aCA+IHJldHZhbC5sZW5ndGgpXG4gICAgICAgICAgICByZXR2YWwgPSB0ZXh0O1xuICAgIH1cbiAgICByZXR1cm4gcmV0dmFsXG59XG5cblxuXG4vLyBJIHVzZSBteSBvd24gaWQncywgaW5zdGVhZCBvZiB0aG9zZSBvZiBmaWdtYSwgc28gdGhhdCBjb3B5IGFuZCBwYXN0ZSBiZXR3ZWVuIHByZXNlbnRhdGlvbnMgd29ya3Ncbi8vdGhlIGlkIGZvciBhIHNsaWRlIGlzIHN0b3JlZCBpbiBpdHMgZGF0YWJhc2VcbmZ1bmN0aW9uIHNsaWRlSWQoc2xpZGU6IEZyYW1lTm9kZSk6IHN0cmluZyB7XG4gICAgY29uc3QgZGF0YWJhc2UgPSBnZXREYXRhYmFzZShzbGlkZSk7XG4gICAgaWYgKGRhdGFiYXNlICE9IHVuZGVmaW5lZClcbiAgICAgICAgcmV0dXJuIGRhdGFiYXNlLmlkO1xuICAgIGVsc2VcbiAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbn1cblxuXG5cblxuLy9saXN0IG9mIGlkJ3MgdG8gYXZvaWQgd2hlbiBjcmVhdGluZyBhIG5ldyBpZCBpbiBhIHNsaWRlXG4vKklmIHRoZSBhcmd1bWVudCBpcyBkZWZpbmVkLCB0aGVuIHdlIGFyZSBnZW5lcmF0aW5nIGFuIGlkIGZvciBhbiBldmVudCBpbnNpZGUgc2xpZGVXaXRoRXZlbnQuIElmIGl0IGlzIHVuZGVmaW5lZCB0aGVuIHdlIGFyZSBnZW5lcmF0aW5nIGFuIGlkIGZvciBzbGlkZS4gVGhlIGNvbmZsaWN0cyB0byBiZSBhdm9pZGVkIGFyZTogMS4gdHdvIGlkJ3MgaW4gdGhlIHNhbWUgc2xpZGU7IDIuIGFuIGV2ZW50IGlkIHdpdGggYSBzbGlkZSBpZCBhbnl3aGVyZTsgMy4gdHdvIHNsaWRlIGlkJ3MuICovXG5mdW5jdGlvbiBhdm9pZExpc3Qoc2xpZGVXaXRoRXZlbnQ6IEZyYW1lTm9kZSk6IHN0cmluZ1tdIHtcblxuICAgIGNvbnN0IGF2b2lkOiBzdHJpbmdbXSA9IFtdO1xuXG4gICAgLy93ZSBkZWZpbml0ZWx5IHdhbnQgdG8gYXZvaWQgY29uZmxpY3RzIHdpdGggYWxsIHNsaWRlIGlkJ3NcbiAgICBmb3IgKGNvbnN0IHNsaWRlIG9mIGFsbFNsaWRlcygpKVxuICAgICAgICBhdm9pZC5wdXNoKHNsaWRlSWQoc2xpZGUpKTtcblxuICAgIC8vd2Ugd2FudCB0byBhdm9pZCBhdm9pZCBjb25mbGljdHMgd2l0aCBldmVudCBpZCdzIGluIHRoZSBsaXN0IHNsaWRlcywgd2hpY2ggaXMgZWl0aGVyIGEgc2luZ2xldG9uIFtzbGlkZVdpdGhFdmVudF0gaWYgd2UgYXJlIGdlbmVyYXRpbmcgYW4gaWQgZm9yIGFuIGV2ZW50IGluc2lkZSBzbGlkZUV2ZW50LCBvciBvdGhlcndpc2UgYWxsIHNsaWRlcy5cbiAgICBsZXQgc2xpZGVzOiBGcmFtZU5vZGVbXSA9IFtdO1xuICAgIGlmIChzbGlkZVdpdGhFdmVudCAhPSB1bmRlZmluZWQpXG4gICAgICAgIHNsaWRlcy5wdXNoKHNsaWRlV2l0aEV2ZW50KTtcbiAgICBlbHNlXG4gICAgICAgIHNsaWRlcyA9IGFsbFNsaWRlcygpO1xuXG4gICAgZm9yIChjb25zdCBzbGlkZSBvZiBzbGlkZXMpXG4gICAgICAgIGZvciAoY29uc3QgY2hpbGQgb2Ygc2xpZGUuY2hpbGRyZW4pXG4gICAgICAgICAgICBhdm9pZC5wdXNoKGNoaWxkLmdldFBsdWdpbkRhdGEoJ2lkJykpO1xuXG5cbiAgICByZXR1cm4gYXZvaWQ7XG59XG5cblxuXG4vL3JldHVybnMgYW4gaWQgZm9yIGFuIG92ZXJsYXksIGNyZWF0aW5nIGEgbmV3IG9uZSBpZiBuZWNlc3NhcnksIGFuZCBmaXhpbmcgdGhlIG9sZCBvbmUgaWYgbmVjZXNzYXJ5XG4vLyB0aGUgb3V0cHV0IGlzIGFsd2F5cyBkZWZpbmVkLCBzaW5jZSBhIG5ldyBpZCBpcyBjcmVhdGVkIGlmIG5lY2Vzc2FyeVxuZnVuY3Rpb24gb3ZlcmxheUlkKG5vZGU6IFNjZW5lTm9kZSk6IHN0cmluZyB7XG5cblxuXG4gICAgaWYgKCFjYW5CZU92ZXJsYXlUYXJnZXQobm9kZSkpXG4gICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG5cbiAgICBsZXQgcmV0dmFsID0gbm9kZS5nZXRQbHVnaW5EYXRhKCdpZCcpO1xuICAgIGNvbnN0IHNsaWRlID0gbm9kZS5wYXJlbnQgYXMgRnJhbWVOb2RlO1xuXG4gICAgaWYgKHJldHZhbCAhPSAnJykge1xuICAgICAgICAvL2NoZWNrIGlmIHRoZSBwcm9wb3NlZCBpZCBpcyBhbHJlYWR5IHByZXNlbnQgaW4gdGhlIGN1cnJlbnQgc2xpZGUuIFRoaXMgY2FuIGhhcHBlbiBpZiBhIG5vZGUgaXMgY29waWVkIGJ5IHRoZSB1c2VyLCB0aGVuIHRoZSBwbHVnaW4gZGF0YSBpcyBhbHNvIGNvcGllZCwgd2hpY2ggaW5jbHVkZXMgdGhlIGlkLCB0aHVzIGxlYWRpbmcgdG8gZHVwbGljYXRlIGlkJ3MgXG5cbiAgICAgICAgLy90ZWxscyB1cyBpZiBub2RlIHggaXMgb2xkZXIgdGhhbiBub2RlIHlcbiAgICAgICAgZnVuY3Rpb24gb2xkZXJOb2RlKHg6IFNjZW5lTm9kZSwgeTogU2NlbmVOb2RlKTogYm9vbGVhbiB7XG4gICAgICAgICAgICAvL2ZpZ21hIGlkJ3Mgc3RvcmUgYSBudW1iZXIsIHN1Y2ggYXMgMTI6MzUsIHdoZXJlIDEyIGlkZW50aWZpZXMgdGhlIGZyYW1lLCBhbmQgMzUgaWRlbnRpZmllcyB0aGUgY2hpbGQuIEluIHRoaXMgY2FzZSwgdGhlIHZhbHVlIG9mIDEyIGlzIGZpeGVkLCBzbyB3ZSBjb21wYXJlIHRoZSB2YWx1ZSBvZiAzNSwgd2hpY2ggZ3Jvd3MgYXMgdGhlIG9iamVjdHMgZ2V0IG5ld2VyLiBcblxuICAgICAgICAgICAgaWYgKHguaWQubGVuZ3RoID09IHkuaWQubGVuZ3RoKVxuICAgICAgICAgICAgICAgIHJldHVybiAoeC5pZCA8IHkuaWQpO1xuICAgICAgICAgICAgZWxzZVxuICAgICAgICAgICAgICAgIHJldHVybiAoeC5pZC5sZW5ndGggPCB5LmlkLmxlbmd0aClcbiAgICAgICAgfVxuXG5cbiAgICAgICAgZm9yIChjb25zdCBvdGhlciBvZiBzbGlkZS5jaGlsZHJlbikge1xuICAgICAgICAgICAgaWYgKChvbGRlck5vZGUob3RoZXIsIG5vZGUpKSAmJiAob3RoZXIuZ2V0UGx1Z2luRGF0YSgnaWQnKSA9PSByZXR2YWwpKSB7XG4gICAgICAgICAgICAgICAgcmV0dmFsID0gJyc7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgIH1cblxuICAgIGlmIChyZXR2YWwgPT0gJycpIHtcbiAgICAgICAgLy9nZW5lcmF0ZSBhIG5ldyBpZCwgYmVjYXVzZSB0aGUgaWQgaXMgZW1wdHkuIEl0IGNvdWxkIGJlIGVtcHR5IGJlY2F1c2Ugb2YgdGhlIGFib3ZlIGRlZHVwbGljYXRpb24gY29kZS5cblxuICAgICAgICByZXR2YWwgPSBmcmVzaE5hbWUodG9BbHBoYU51bWVyaWMobm9kZS5uYW1lKSwgYXZvaWRMaXN0KHNsaWRlKSk7XG4gICAgICAgIC8vc2F2ZSB0aGUgbmFtZSBpbiB0aGUgbm9kZVxuICAgICAgICBub2RlLnNldFBsdWdpbkRhdGEoJ2lkJywgcmV0dmFsKTtcbiAgICB9XG4gICAgcmV0dXJuIHJldHZhbDtcbn1cbiIsIi8qIFRoaXMgZmlsZSBjb250YWlucyB0aGUgY29kZSBmb3IgY3JlYXRpbmcgb3ZlcmxheSBldmVudHMgaW4gYSBzbGlkZS4gKi9cbmV4cG9ydCB7IGNhbkJlT3ZlcmxheVRhcmdldCwgY3JlYXRlT3ZlcmxheUV2ZW50IH07XG5cbmltcG9ydCB7IEFuaW1hdGlvblBhcmFtcywgT3ZlcmxheUV2ZW50IH0gZnJvbSBcIi4uL2NvbW1vbi90eXBlc1wiO1xuaW1wb3J0IHsgc3RhdGUgfSBmcm9tIFwiLi9jb2RlXCI7XG5pbXBvcnQgeyBnb29kTmFtZSwgbmV3RXZlbnRJZCwgb3ZlcmxheUlkIH0gZnJvbSBcIi4vY29kZS1uYW1lLW1hbmFnZW1lbnRcIjtcblxuXG4vL3NheXMgaWYgdGhlIG5vZGUgaXMgYSBwb3NzaWJsZSB0YXJnZXQgZm9yIGEgc2hvdy9oaWRlIGV2ZW50XG5mdW5jdGlvbiBjYW5CZU92ZXJsYXlUYXJnZXQobm9kZTogU2NlbmVOb2RlKTogYm9vbGVhbiB7XG4gICAgaWYgKG5vZGUucGFyZW50ICE9IHN0YXRlLmN1cnJlbnRTbGlkZSB8fCBub2RlLmdldFBsdWdpbkRhdGEoJ2NoaWxkTGluaycpICE9ICcnKVxuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgcmV0dXJuIHRydWU7XG59XG5cbi8vY3JlYXRlcyBhbiBvdmVybGF5IGV2ZW50IGluIHRoZSBjdXJyZW50IHNsaWRlXG5mdW5jdGlvbiBjcmVhdGVPdmVybGF5RXZlbnQodHlwZTogJ3Nob3cnIHwgJ2hpZGUnIHwgJ2FuaW1hdGUnKTogT3ZlcmxheUV2ZW50W10ge1xuXG4gICAgY29uc3QgcmV0dmFsID0gW10gYXMgT3ZlcmxheUV2ZW50W107XG4gICAgLy8gd2UgYXJlIGNyZWF0aW5nIGFuIG92ZXJsYXkgZXZlbnRcblxuICAgIC8vd2UgZmlyc3Qgc29ydCB0aGUgbGlzdGVkIGl0ZW1zLCBpbiBhbiBvcmRlciB0aGF0IGlzIG1vcmUgY29udmVuaWVudCBmb3IgdGhlIHVzZXJcbiAgICBsZXQgc29ydGVkOiBTY2VuZU5vZGVbXSA9IFtdO1xuXG4gICAgLy93ZSBsb29rIGF0IHRoZSBzZXQgb2YgeCB2YWx1ZXMgYW5kIHkgdmFsdWVzIG9mIHRoZSBzZWxlY3RlZCBvYmplY3RzLCB0byBkZXRlcm1pbmUgaWYgdGhpcyBzZXQgaXMgbW9yZSB2ZXJ0aWNhbCBvciBtb3JlIGhvcml6b250YWwsIHNvIHRoYXQgd2UgY2FuIGRldGVybWluZSB0aGUgc29ydGluZyBvcmRlclxuICAgIGNvbnN0IHhhcnJheSA9IFtdIGFzIG51bWJlcltdO1xuICAgIGNvbnN0IHlhcnJheSA9IFtdIGFzIG51bWJlcltdO1xuXG4gICAgZm9yIChjb25zdCBpdGVtIG9mIGZpZ21hLmN1cnJlbnRQYWdlLnNlbGVjdGlvbikge1xuICAgICAgICBpZiAoY2FuQmVPdmVybGF5VGFyZ2V0KGl0ZW0pKSB7XG4gICAgICAgICAgICB4YXJyYXkucHVzaChpdGVtLngpO1xuICAgICAgICAgICAgeWFycmF5LnB1c2goaXRlbS55KTtcbiAgICAgICAgICAgIHNvcnRlZC5wdXNoKGl0ZW0pO1xuICAgICAgICB9XG4gICAgfVxuICAgIC8vZHggaXMgdGhlIG1heGltYWwgZGlmZmVyZW5jZSBiZXR3ZWVuIHggY29vcmRpbmF0ZXMsIGxpa2V3aXNlIGZvciBkeVxuICAgIGNvbnN0IGR4ID0gTWF0aC5tYXgoLi4ueGFycmF5KSAtIE1hdGgubWluKC4uLnhhcnJheSk7XG4gICAgY29uc3QgZHkgPSBNYXRoLm1heCguLi55YXJyYXkpIC0gTWF0aC5taW4oLi4ueWFycmF5KTtcblxuICAgIC8vdGhlIGV2ZW50cyBhcmUgc29ydGVkIGJ5IHggb3IgeSBkZXBlbmRpbmcgb24gd2hpY2ggb2YgZHgsIGR5IGlzIGJpZ2dlclxuICAgIGNvbnN0IHNvcnRJbmRleCA9IChhOiBTY2VuZU5vZGUpID0+IHtcbiAgICAgICAgaWYgKGR4ID4gZHkpXG4gICAgICAgICAgICByZXR1cm4gYS54XG4gICAgICAgIGVsc2VcbiAgICAgICAgICAgIHJldHVybiBhLnlcbiAgICB9O1xuICAgIC8vdGhlIG9yZGVyIG9mIGV2ZW50cyBpcyBzbyB0aGF0IGl0IHByb2dyZXNzZXMgaW4gdGhlIGRvd24tcmlnaHQgZGlyZWN0aW9uXG5cbiAgICBzb3J0ZWQgPSBzb3J0ZWQuc29ydCgoYSwgYikgPT4gc29ydEluZGV4KGEpIC0gc29ydEluZGV4KGIpKTtcblxuXG4gICAgLy8gZm9yIGVhY2ggZWxlbWVudCBpbiB0aGUgc29ydGVkIGxpc3Qgb2YgZXZlbnRzLCB3ZSBjcmVhdGUgYW4gb3ZlcmxheSBldmVudFxuICAgIGZvciAoY29uc3QgaXRlbSBvZiBzb3J0ZWQpIHtcbiAgICAgICAgbGV0IG5ld0V2ZW50OiBPdmVybGF5RXZlbnQ7XG4gICAgICAgIGlmIChpdGVtLnR5cGUgPT09ICdHUk9VUCcgJiYgaXRlbS5uYW1lLnN0YXJ0c1dpdGgoJ0dyb3VwJykpIHtcbiAgICAgICAgICAgIC8vaW1wcm92ZSB0aGUgbmFtZVxuICAgICAgICAgICAgaXRlbS5uYW1lID0gZ29vZE5hbWUoaXRlbSk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBpZCA9IG92ZXJsYXlJZChpdGVtKTtcblxuXG4gICAgICAgIHN3aXRjaCAodHlwZSkge1xuICAgICAgICAgICAgY2FzZSAnc2hvdyc6XG4gICAgICAgICAgICBjYXNlICdoaWRlJzpcbiAgICAgICAgICAgICAgICBpZiAoJ29wYWNpdHknIGluIGl0ZW0pIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHN0YXRlLmRhdGFiYXNlLm9yaWdpbmFsUGFyYW1zW2lkXSA9PSB1bmRlZmluZWQpXG4gICAgICAgICAgICAgICAgICAgICAgICBzdGF0ZS5kYXRhYmFzZS5vcmlnaW5hbFBhcmFtc1tpZF0gPSB7IG9wYWNpdHk6IGl0ZW0ub3BhY2l0eSB9IGFzIEFuaW1hdGlvblBhcmFtcztcbiAgICAgICAgICAgICAgICAgICAgaWYgKHN0YXRlLmRhdGFiYXNlLm9yaWdpbmFsUGFyYW1zW2lkXS5vcGFjaXR5ID09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gdGhpcyB3aWxsIGhhcHBlbiBpZiB0aGUgb2JqZWN0IHdhcyBjcmVhdGVkIHdpdGggYW4gYW5pbWF0ZSBldmVudCwgYW5kIHRoZXJlZm9yZSBpdCBvbmx5IGhhZCBhbiB4L3kgcGFyYW1ldGVyIGluaXRpYWxseVxuICAgICAgICAgICAgICAgICAgICAgICAgc3RhdGUuZGF0YWJhc2Uub3JpZ2luYWxQYXJhbXNbaWRdLm9wYWNpdHkgPSBpdGVtLm9wYWNpdHk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgbmV3RXZlbnQgPVxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiB0eXBlLFxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IGlkLFxuICAgICAgICAgICAgICAgICAgICAgICAgZW5hYmxlZDogJ2VuYWJsZWQnLFxuICAgICAgICAgICAgICAgICAgICAgICAgbmFtZTogaXRlbS5uYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgbWVyZ2VkOiBmYWxzZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleXdvcmRzOiBbXSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGV2ZW50SWQ6IG5ld0V2ZW50SWQoKVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuXG4gICAgICAgICAgICBjYXNlICdhbmltYXRlJzpcbiAgICAgICAgICAgICAgICBjb25zdCBwYXJhbXMgPSB7IHg6IGl0ZW0ueCwgeTogaXRlbS55IH0gYXMgQW5pbWF0aW9uUGFyYW1zO1xuICAgICAgICAgICAgICAgIGlmIChzdGF0ZS5kYXRhYmFzZS5vcmlnaW5hbFBhcmFtc1tpZF0gPT0gdW5kZWZpbmVkKVxuICAgICAgICAgICAgICAgICAgICBzdGF0ZS5kYXRhYmFzZS5vcmlnaW5hbFBhcmFtc1tpZF0gPSB7Li4ucGFyYW1zfTtcbiAgICAgICAgICAgICAgICBpZiAoc3RhdGUuZGF0YWJhc2Uub3JpZ2luYWxQYXJhbXNbaWRdLnggPT0gdW5kZWZpbmVkKVxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyB0aGlzIHdpbGwgaGFwcGVuIGlmIHRoZSBvYmplY3Qgd2FzIGNyZWF0ZWQgd2l0aCBhIHNob3cvaGlkZSBldmVudCwgYW5kIHRoZXJlZm9yZSBpdCBvbmx5IGhhZCBhbiBvcGFjaXR5IHBhcmFtZXRlciBpbml0aWFsbHlcbiAgICAgICAgICAgICAgICAgICAgICAgIHN0YXRlLmRhdGFiYXNlLm9yaWdpbmFsUGFyYW1zW2lkXS54ID0gaXRlbS54O1xuICAgICAgICAgICAgICAgICAgICAgICAgc3RhdGUuZGF0YWJhc2Uub3JpZ2luYWxQYXJhbXNbaWRdLnkgPSBpdGVtLnk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBuZXdFdmVudCA9XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICB0eXBlOiAnYW5pbWF0ZScsXG4gICAgICAgICAgICAgICAgICAgIGlkOiBpZCxcbiAgICAgICAgICAgICAgICAgICAgZW5hYmxlZDogJ2VuYWJsZWQnLFxuICAgICAgICAgICAgICAgICAgICBuYW1lOiBpdGVtLm5hbWUsXG4gICAgICAgICAgICAgICAgICAgIG1lcmdlZDogZmFsc2UsXG4gICAgICAgICAgICAgICAgICAgIGtleXdvcmRzOiBbXSxcbiAgICAgICAgICAgICAgICAgICAgZXZlbnRJZDogbmV3RXZlbnRJZCgpLFxuICAgICAgICAgICAgICAgICAgICBwYXJhbXM6IHBhcmFtc1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuXG4gICAgICAgIHJldHZhbC5wdXNoKG5ld0V2ZW50KTtcblxuICAgIH1cbiAgICByZXR1cm4gcmV0dmFsO1xufVxuIiwiLyogbW9kaWZ5IHRoZSBzZXR0aW5ncyBvZiB0aGUgcGx1Z2luIG9uIHRoZSBiYWNrZW5kICovXG5leHBvcnQgeyBnZXRMYXRleFNldHRpbmdzLCBpbml0U2V0dGluZ3MsIHBsdWdpblNldHRpbmdzLCBzZW5kU2V0dGluZ3MgfTtcblxuaW1wb3J0IHsgc2VsQ2hhbmdlLCBzZW5kVG9VSSB9IGZyb20gXCIuL2NvZGVcIjtcbmltcG9ydCB7IExhdGV4UGx1Z2luU2V0dGluZ3MgfSBmcm9tIFwiLi9wbHVnaW4tdHlwZXNcIjtcbmltcG9ydCB7IHVwZ3JhZGVWZXJzaW9uIH0gZnJvbSBcIi4vcGx1Z2luLXZlcnNpb25cIjtcblxuXG5cblxuLy90aGUgcGx1Z2luIHNldHRpbmdzXG5sZXQgcGx1Z2luU2V0dGluZ3M6IExhdGV4UGx1Z2luU2V0dGluZ3M7XG5cblxuXG5cbi8vZ2V0IHRoZSBzZXR0aW5ncyBmcm9tIHRoZSB1aVxuZnVuY3Rpb24gZ2V0TGF0ZXhTZXR0aW5ncyhzZXR0aW5nczogTGF0ZXhQbHVnaW5TZXR0aW5ncyk6IHZvaWQge1xuICAgIHBsdWdpblNldHRpbmdzID0gc2V0dGluZ3M7XG4gICAgZmlnbWEuY2xpZW50U3RvcmFnZS5zZXRBc3luYygnc2xhamRvbWF0JywgSlNPTi5zdHJpbmdpZnkoc2V0dGluZ3MpKTtcbiAgICBzZW5kU2V0dGluZ3MoKTtcbn1cblxuLy9zZW5kIHRoZSBzZXR0aW5ncyB0byB0aGUgdWlcbmZ1bmN0aW9uIHNlbmRTZXR0aW5ncygpOiB2b2lkIHtcbiAgICBzZW5kVG9VSSh7XG4gICAgICAgIHR5cGU6ICdzZXR0aW5ncycsXG4gICAgICAgIHNldHRpbmdzOiBwbHVnaW5TZXR0aW5nc1xuICAgIH0pO1xufVxuXG5cblxuLy9pbml0aWFsaXplIHRoZSBzZXR0aW5ncyBmb3IgdGhlIHBsdWdpblxuZnVuY3Rpb24gaW5pdFNldHRpbmdzKCkge1xuICAgIHVwZ3JhZGVWZXJzaW9uKCk7XG4gICAgZmlnbWEuY2xpZW50U3RvcmFnZS5nZXRBc3luYygnc2xhamRvbWF0JykudGhlbihcbiAgICAgICAgeCA9PiB7XG4gICAgICAgICAgICAvL3RoZSBkZWZhdWx0IHBsdWdpbiBzZXR0aW5nc1xuICAgICAgICAgICAgY29uc3QgZGVmYXVsdFNldHRpbmdzID0ge1xuICAgICAgICAgICAgICAgIHdvcmRzOiBbJ+KIgCcsICfiiIMnLCAn4oinJywgJ+KIqCcsICfiiIgnXSxcbiAgICAgICAgICAgICAgICBhY3RpdmU6IGZhbHNlLFxuICAgICAgICAgICAgICAgIG1hdGhGb250OiB7XG4gICAgICAgICAgICAgICAgICAgIGZhbWlseTogJ1NUSVhHZW5lcmFsJyxcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU6ICdSZWd1bGFyJ1xuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgbWF0aEZvbnRTaXplOiAxLFxuICAgICAgICAgICAgICAgIHNlcnZlclVSTDogJ2h0dHA6Ly9sb2NhbGhvc3Q6MzAwMScsXG4gICAgICAgICAgICAgICAgbGF0ZXhpdFVSTDogJ2h0dHBzOi8vbGF0ZXguY29kZWNvZ3MuY29tL3N2Zy5sYXRleD8nXG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgcGx1Z2luU2V0dGluZ3MgPSB7XG4gICAgICAgICAgICAgICAgICAgIC4uLmRlZmF1bHRTZXR0aW5ncyxcbiAgICAgICAgICAgICAgICAgICAgLi4uSlNPTi5wYXJzZSh4KVxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgcGx1Z2luU2V0dGluZ3MgPSBkZWZhdWx0U2V0dGluZ3M7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBzZW5kU2V0dGluZ3MoKTtcbiAgICAgICAgICAgIHNlbENoYW5nZSgpO1xuICAgICAgICB9XG4gICAgKVxufVxuXG4iLCIvKiB0YWtlcyBjYXJlIG9mIHRoZSB0aHVtYm5haWxzIG9mIHRoZSBzbGlkZXMgaW4gdGhlIHBsdWdpbiAqL1xuZXhwb3J0IHsgY3JlYXRlVGh1bWJuYWlsLCB1cGRhdGVUaHVtYm5haWxzIH07XG5pbXBvcnQgeyBmaW5kU2xpZGUsIHNsaWRlSWQsIHN0YXRlIH0gZnJvbSBcIi4vY29kZVwiO1xuXG4vLyB0aGlzIGlzIHRoZSBjb2xvdXIgdGhhdCB3aWxsIGJlIHVzZWQgZm9yIHRoZSB0aHVtYm5haWwgZnJhbWUsIGFuZCBhbHNvIGZvciBpdHMgZmlsbCB3aGVuIHRoZSB0aHVtYm5haWwgaXMgbm90IGF2YWlsYWJsZVxuY29uc3QgcmVkQ29sb3IgPSB7XG4gICAgdHlwZTogJ1NPTElEJyxcbiAgICBjb2xvcjoge1xuICAgICAgICByOiAxLFxuICAgICAgICBnOiAwLFxuICAgICAgICBiOiAwXG4gICAgfVxufSBhcyBQYWludDtcblxuXG4vLyBjcmVhdGVzIGEgdGh1bWJuYWlsIG9mIHNsaWRlIHRhcmdldFNsaWRlSWQgYW5kIHBsYWNlcyBpdCBpbiB0aGUgY3VycmVudCBzbGlkZSBpbiB0aGUgcG9zaXRpb24gd2hlcmVcbmZ1bmN0aW9uIGNyZWF0ZVRodW1ibmFpbChzb3VyY2VTbGlkZTogRnJhbWVOb2RlLCB0YXJnZXRTbGlkZUlkOiBzdHJpbmcsIHdoZXJlOiBSZWN0KTogR3JvdXBOb2RlIHtcbiAgICBjb25zdCB0YXJnZXRTbGlkZTogRnJhbWVOb2RlID0gZmluZFNsaWRlKHRhcmdldFNsaWRlSWQpO1xuXG4gICAgLy8gcmVkIHNlbWktdHJhbnNwYXJlbnQgcmVjdGFuZ2xlLCB3aGljaCB3aWxsIGJlIGxhdGVyIGZpbGxlZCB3aXRoIHRoZSB0aHVtYm5haWxcbiAgICBjb25zdCByZWN0Tm9kZSA9IGZpZ21hLmNyZWF0ZVJlY3RhbmdsZSgpO1xuICAgIHJlY3ROb2RlLnJlc2l6ZSh3aGVyZS53aWR0aCwgd2hlcmUud2lkdGgpO1xuICAgIHJlY3ROb2RlLnggPSB3aGVyZS54O1xuICAgIHJlY3ROb2RlLnkgPSB3aGVyZS55O1xuICAgIHJlY3ROb2RlLm9wYWNpdHkgPSAwLjU7XG4gICAgcmVjdE5vZGUuc2V0UGx1Z2luRGF0YSgndGh1bWJuYWlsJywgJ3llcycpO1xuICAgIHN0YXRlLmN1cnJlbnRTbGlkZS5hcHBlbmRDaGlsZChyZWN0Tm9kZSk7XG5cbiAgICAvLyBhIHJlZCBmcmFtZSwgd2hpY2ggd2lsbCBzdGF5IGV2ZW4gd2hlbiB0aGUgdGh1bWJuYWlsIGFwcGVhcnNcbiAgICBjb25zdCBmcmFtZU5vZGUgPSBmaWdtYS5jcmVhdGVSZWN0YW5nbGUoKTtcbiAgICBmcmFtZU5vZGUucmVzaXplKHdoZXJlLndpZHRoLCB3aGVyZS53aWR0aCk7XG4gICAgZnJhbWVOb2RlLnggPSB3aGVyZS54O1xuICAgIGZyYW1lTm9kZS55ID0gd2hlcmUueTtcbiAgICBmcmFtZU5vZGUuZmlsbHMgPSBbXTtcbiAgICBmcmFtZU5vZGUuc3Ryb2tlcyA9IFtyZWRDb2xvcl07XG4gICAgc3RhdGUuY3VycmVudFNsaWRlLmFwcGVuZENoaWxkKGZyYW1lTm9kZSk7XG5cbiAgICAvLyAgYSBncm91cCB3aXRoIHRoZSBub2Rlc1xuICAgIGNvbnN0IGdyb3VwTm9kZSA9IGZpZ21hLmdyb3VwKFtyZWN0Tm9kZSwgZnJhbWVOb2RlXSwgc3RhdGUuY3VycmVudFNsaWRlKTtcbiAgICBncm91cE5vZGUuc2V0UGx1Z2luRGF0YShcImNoaWxkTGlua1wiLCB0YXJnZXRTbGlkZUlkKTtcbiAgICBncm91cE5vZGUuZXhwYW5kZWQgPSBmYWxzZTtcblxuICAgIC8vIHRoaXMgY3JlYXRlcyB0aGUgYWN0dWFsIHBpY3R1cmUuIGl0IGlzIHNlcGFyYXRlIGNvZGUsIHNpbmNlIGl0IHdpbGwgYmUgY2FsbGVkIGxhdGVyIHdoZW4gdGhlIHRodW1ibmFpbCBpcyB1cGRhdGVkIGJ1dCB0aGUgcmVjdGFnbGVzIGNyZWF0ZWQgaGVyZSBzdGF5IHRoZSBzYW1lXG4gICAgdXBkYXRlVGh1bWJuYWlsKHJlY3ROb2RlLCB0YXJnZXRTbGlkZSk7XG5cbiAgICByZXR1cm4gZ3JvdXBOb2RlO1xufVxuXG5hc3luYyBmdW5jdGlvbiB1cGRhdGVUaHVtYm5haWwocmVjdDogUmVjdGFuZ2xlTm9kZSwgc2xpZGU6IEZyYW1lTm9kZSkge1xuICAgIGlmIChzbGlkZSA9PSB1bmRlZmluZWQgfHwgc2xpZGUucmVtb3ZlZCkge1xuICAgICAgICAvLyB0aGUgdGFyZ2V0IHNsaWRlIGhhcyBiZWVuIHJlbW92ZWRcbiAgICAgICAgcmVjdC5maWxscyA9IFsgcmVkQ29sb3IgXTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIC8vIHRoZSB0YXJnZXQgc2xpZGUgZXhpc3RzLCBzbyB3ZSBjYW4gZ2VuZXJhdGUgYSB0aHVtYm5haWxcbiAgICAgICAgY29uc3QgaW1hZ2UgPSBmaWdtYS5jcmVhdGVJbWFnZShhd2FpdCBzbGlkZS5leHBvcnRBc3luYyh7XG4gICAgICAgICAgICBmb3JtYXQ6ICdQTkcnXG4gICAgICAgIH0pKTtcbiAgICAgICAgcmVjdC5maWxscyA9IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICB0eXBlOiAnSU1BR0UnLFxuICAgICAgICAgICAgICAgIGltYWdlSGFzaDogaW1hZ2UuaGFzaCxcbiAgICAgICAgICAgICAgICBzY2FsZU1vZGU6ICdGSUxMJ1xuICAgICAgICAgICAgfVxuICAgICAgICBdXG4gICAgfVxufVxuXG5cbi8vdXBkYXRlIHRoZSB0aHVtYm5haWxzIGZvciBzbGlkZSBjaGlsZHJlblxuYXN5bmMgZnVuY3Rpb24gdXBkYXRlVGh1bWJuYWlscygpIHtcbiAgICBjb25zdCBub2RlcyA9IHN0YXRlLmN1cnJlbnRTbGlkZS5maW5kQWxsKChub2RlOiBTY2VuZU5vZGUpID0+IG5vZGUuZ2V0UGx1Z2luRGF0YShcImNoaWxkTGlua1wiKSAhPSAnJyk7XG5cbiAgICBmb3IgKGNvbnN0IGNoaWxkIG9mIG5vZGVzKSB7XG4gICAgICAgIGNvbnN0IHNsaWRlID0gZmluZFNsaWRlKGNoaWxkLmdldFBsdWdpbkRhdGEoJ2NoaWxkTGluaycpKTtcblxuICAgICAgICAvL2lmIHRoZSBjaGlsZCBsaW5rIHdhcyBjcmVhdGVkIGluIGFuIG9sZCB2ZXJzaW9uIG9mIFNsYWpkb21hdCwgdGhlbiBpdCBpcyBzaW1wbHkgYSByZWN0YW5nbGUuIEluIHRoaXMgY2FzZSBpdCBuZWVkcyB0byBiZSB1cGdyYWRlZCB0byBhIG5ldyB2ZXJzaW9uLCB3aGVyZSBpdCBpcyBhIGdyb3VwIGNvbnRhaW5pbmcgdHdvIHJlY3RhbmdsZXMuXG4gICAgICAgIGlmIChjaGlsZC50eXBlID09ICdSRUNUQU5HTEUnKSB7XG4gICAgICAgICAgICBjb25zdCB3aGVyZSA9IHsgd2lkdGg6IGNoaWxkLndpZHRoLCBoZWlnaHQ6IGNoaWxkLmhlaWdodCwgeDogY2hpbGQueCwgeTogY2hpbGQueSB9O1xuICAgICAgICAgICAgY2hpbGQucmVtb3ZlKCk7XG4gICAgICAgICAgICBjcmVhdGVUaHVtYm5haWwoc3RhdGUuY3VycmVudFNsaWRlLCBzbGlkZUlkKHNsaWRlKSwgd2hlcmUpO1xuICAgICAgICB9XG5cblxuXG4gICAgICAgIGxldCByZWN0OiBSZWN0YW5nbGVOb2RlO1xuICAgICAgICAvL2ZpbmRzIHRoZSByZWN0YW5nbGUgd2hlcmUgdGhlIHRodW1ibmFpbCBzaG91bGQgZ287IHRoaXMgaXMgaW5kaWNhdGVkIGJ5IHBsdWdpbiBkYXRhXG4gICAgICAgIGlmIChjaGlsZC50eXBlID09ICdHUk9VUCcpIHtcbiAgICAgICAgICAgIGZvciAoY29uc3QgZ3JhbmRjaGlsZCBvZiBjaGlsZC5jaGlsZHJlbilcbiAgICAgICAgICAgICAgICBpZiAoZ3JhbmRjaGlsZC5nZXRQbHVnaW5EYXRhKCd0aHVtYm5haWwnKSkge1xuICAgICAgICAgICAgICAgICAgICByZWN0ID0gZ3JhbmRjaGlsZCBhcyBSZWN0YW5nbGVOb2RlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIC8vaWYgc3VjaCBhIHJlY3RhbmdsZSBoYXMgYmVlbiBmb3VuZCwgdGhlbiBpdHMgZmlsbCBzaG91bGQgYmUgcmVwbGFjZWQgd2l0aCB0aGUgdGh1bWJuYWlsXG4gICAgICAgIGlmIChyZWN0ICE9IG51bGwpIHtcbiAgICAgICAgICAgIHVwZGF0ZVRodW1ibmFpbChyZWN0LCBzbGlkZSk7XG4gICAgICAgIH1cbiAgICB9XG59XG4iLCIvKiBUaGlzIGlzIGNvZGUgZm9yIHRoZSBwbHVnaW4gYmFja2VuZCB0aGF0IG1hbmFnZXMgdGhlIHRpbWVsaW5lIG9mIHRoZSBwcmVzZW50YXRpb24uIEl0IHRha2VzIGNhcmUgb2YgdXBkYXRpbmcgdGhlIG9wYWNpdHkgYW5kIHh5IHZhbHVlcyBvZiBmaWdtYSBlbGVtZW50cyBhcyB0aGUgdXNlciBjbGlja3Mgb24gdGhlIHRpbWVsaW5lIGluIHRoZSBwbHVnaW4uXG4qL1xuXG5leHBvcnQgeyBzYXZlQW5pbWF0aW9uUGFyYW1zLCBsb2FkQW5pbWF0aW9uUGFyYW1zIH1cbmltcG9ydCB7IHN0YXQgfSBmcm9tIFwib3JpZ2luYWwtZnNcIjtcbmltcG9ydCB7IGN1cnJlbnRQYXJhbXMsIG1vZGlmeWluZ0V2ZW50cyB9IGZyb20gXCIuLi9jb21tb24vYW5pbWF0ZS1wYXJhbXNcIjtcbmltcG9ydCB7IEFuaW1hdGVFdmVudCwgQW5pbWF0aW9uUGFyYW1zLCBPdmVybGF5RXZlbnQsIFByZXNlbnRhdGlvbk5vZGUsIFNob3dIaWRlRXZlbnQgfSBmcm9tIFwiLi4vY29tbW9uL3R5cGVzXCI7XG5pbXBvcnQgeyBzYXZlQ3VycmVudERhdGEsIHN0YXRlIH0gZnJvbSBcIi4vY29kZVwiO1xuaW1wb3J0IHsgb3ZlcmxheUlkIH0gZnJvbSBcIi4vY29kZS1uYW1lLW1hbmFnZW1lbnRcIjtcblxuXG5cblxuLy8gdGhlIHggYW5kIHkgdmFsdWVzIGdvIHRvIHRoZSBhbmltYXRlIGV2ZW50cywgYW5kIHRoZSBvcGFjaXR5IGdvZXMgdG8gb3JpZ2luYWwgcGFyYW1ldGVyc1xuZnVuY3Rpb24gc2F2ZUFuaW1hdGlvblBhcmFtcygpOiB2b2lkIHtcblxuICAgIGNvbnN0IGhhdmVFdmVudHMgPSBpZHNUaGF0SGF2ZUV2ZW50cygpO1xuXG4gICAgLy8gcmVtb3ZlIHRoZSB1bnVzZWQga2V5cyBmcm9tIHRoZSBvcmlnaW5hbFBhcmFtcyBkaWN0aW9uYXJ5XG4gICAgZm9yIChjb25zdCBrZXkgb2YgT2JqZWN0LmtleXMoc3RhdGUuZGF0YWJhc2Uub3JpZ2luYWxQYXJhbXMpKSB7XG4gICAgICAgIGlmICghaGF2ZUV2ZW50cy5oYXMoa2V5KSlcbiAgICAgICAgICAgIGRlbGV0ZSBzdGF0ZS5kYXRhYmFzZS5vcmlnaW5hbFBhcmFtc1trZXldO1xuICAgIH1cblxuICAgIGZvciAoY29uc3Qgbm9kZSBvZiBzdGF0ZS5jdXJyZW50U2xpZGUuY2hpbGRyZW4pIHtcbiAgICAgICAgY29uc3QgaWQgPSBvdmVybGF5SWQobm9kZSk7XG4gICAgICAgIGlmIChoYXZlRXZlbnRzLmhhcyhpZCkpICB7XG4gICAgICAgICAgICAvLyB0aGUgaWQgaGFzIGV2ZW50c1xuICAgICAgICAgICAgLy8gd2UgbmVlZCB0byBmaW5kIHRoZSBhcHByb3ByaWF0ZSBwbGFjZSB0byBzdG9yZSB0aGUgYW5pbWF0aW9uIHBhcmFtZXRlcnMsIHdoaWNoIG1heSBiZSBhbiBldmVudCwgb3Igb3RoZXJ3aXNlIHRoZSBvcmlnaW5hbFBhcmFtcyBkaWN0aW9uYXJ5XG4gICAgICAgICAgICBjb25zdCBtb2RpZnlpbmcgPSBtb2RpZnlpbmdFdmVudHMoaWQsIHN0YXRlLmRhdGFiYXNlLnNlbGVjdGVkLCBzdGF0ZS5kYXRhYmFzZS5ldmVudHMpO1xuXG4gICAgICAgICAgICBpZiAobW9kaWZ5aW5nLnh5ICE9ICdub3QgbW9kaWZpZWQnIHx8IG1vZGlmeWluZy5vcGFjaXR5ICE9ICdub3QgbW9kaWZpZWQnKSB7XG4gICAgICAgICAgICAgICAgaWYgKHN0YXRlLmRhdGFiYXNlLm9yaWdpbmFsUGFyYW1zW2lkXSA9PSB1bmRlZmluZWQpXG4gICAgICAgICAgICAgICAgICAgIHN0YXRlLmRhdGFiYXNlLm9yaWdpbmFsUGFyYW1zW2lkXSA9IHt9IGFzIEFuaW1hdGlvblBhcmFtcztcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgc3dpdGNoIChtb2RpZnlpbmcueHkpIHtcbiAgICAgICAgICAgICAgICBjYXNlICdvcmlnaW5hbCc6XG4gICAgICAgICAgICAgICAgICAgIHN0YXRlLmRhdGFiYXNlLm9yaWdpbmFsUGFyYW1zW2lkXS54ID0gbm9kZS54O1xuICAgICAgICAgICAgICAgICAgICBzdGF0ZS5kYXRhYmFzZS5vcmlnaW5hbFBhcmFtc1tpZF0ueSA9IG5vZGUueTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSAnbm90IG1vZGlmaWVkJzpcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICAgICAgbW9kaWZ5aW5nLnh5LnBhcmFtcy54ID0gbm9kZS54O1xuICAgICAgICAgICAgICAgICAgICBtb2RpZnlpbmcueHkucGFyYW1zLnkgPSBub2RlLnk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIHRoZSBvcGFjaXR5IGlzIHNhdmVkIHRvIHRoZSBvcmlnaW5hbCBwYXJhbWV0ZXJzIGlmIGl0IGlzIG1vZGlmaWVkLCBhbmQgdGhlIGxhc3Qgc2hvdy9oaWRlIGV2ZW50IGlzIG5vdCBoaWRlXG4gICAgICAgICAgICBpZiAoJ29wYWNpdHknIGluIG5vZGUpIHtcbiAgICAgICAgICAgICAgICBzd2l0Y2ggKG1vZGlmeWluZy5vcGFjaXR5KSB7XG4gICAgICAgICAgICAgICAgICAgIGNhc2UgJ25vdCBtb2RpZmllZCc6XG4gICAgICAgICAgICAgICAgICAgIGNhc2UgJ2JlZm9yZSBmaXJzdCBzaG93JzpcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKG1vZGlmeWluZy5vcGFjaXR5ID09ICdiZWZvcmUgZmlyc3QgaGlkZScgfHwgbW9kaWZ5aW5nLm9wYWNpdHkudHlwZSA9PSAnc2hvdycpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdGF0ZS5kYXRhYmFzZS5vcmlnaW5hbFBhcmFtc1tpZF0ub3BhY2l0eSA9IG5vZGUub3BhY2l0eTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG59XG5cblxuXG5mdW5jdGlvbiBpZHNUaGF0SGF2ZUV2ZW50cygpOiBTZXQ8c3RyaW5nPiB7XG4gICAgY29uc3QgaWRzVGhhdEhhdmVFdmVudHMgPSBuZXcgU2V0PHN0cmluZz4oKTtcbiAgICBmb3IgKGNvbnN0IGV2ZW50IG9mIHN0YXRlLmRhdGFiYXNlLmV2ZW50cykge1xuICAgICAgICBpZiAoZXZlbnQudHlwZSAhPSAnY2hpbGQnKVxuICAgICAgICAgICAgaWRzVGhhdEhhdmVFdmVudHMuYWRkKGV2ZW50LmlkKTtcbiAgICB9XG4gICAgcmV0dXJuIGlkc1RoYXRIYXZlRXZlbnRzO1xufVxuXG4vLyB0aGUgb3Bwb3NpdGUgb2YgdGhlIHByZXZpb3VzIGZ1bmN0aW9uXG5mdW5jdGlvbiBsb2FkQW5pbWF0aW9uUGFyYW1zKCk6IHZvaWQge1xuXG4gICAgLy8gYSBsaXR0bGUgb3B0aW1pemF0aW9uLCBub3Qgc3VyZSBpZiBuZWNlc3Nhcnk6IHdlIHdpbGwgb25seSBsb29rIGF0IGlkcyBvZiBvYmplY3RzIHRoYXQgaGF2ZSBzb21lIG92ZXJsYXkgYXNzb2NpYXRlZCB0byB0aGVtXG4gICAgY29uc3QgaGF2ZUV2ZW50cyA9IGlkc1RoYXRIYXZlRXZlbnRzKCk7XG5cbiAgICBmb3IgKGNvbnN0IGlkIG9mIGhhdmVFdmVudHMpIHtcbiAgICAgICAgZm9yIChjb25zdCBub2RlIG9mIHN0YXRlLmN1cnJlbnRTbGlkZS5jaGlsZHJlbikge1xuICAgICAgICAgICAgaWYgKG92ZXJsYXlJZChub2RlKSA9PSBpZCkge1xuICAgICAgICAgICAgICAgIC8vIHRoZSBsYXN0IGFyZ3VtZW50IGlzIDAuMSwgc2luY2Ugd2Ugd2FudCBoaWRkZW4gZXZlbnRzIHRvIGJlIGEgYml0IHZpc2libGVcbiAgICAgICAgICAgICAgICBjb25zdCBwYXJhbXMgPSBjdXJyZW50UGFyYW1zKGlkLCBzdGF0ZS5kYXRhYmFzZS5zZWxlY3RlZCwgc3RhdGUuZGF0YWJhc2UuZXZlbnRzLCBzdGF0ZS5kYXRhYmFzZS5vcmlnaW5hbFBhcmFtcywgMC4xKTtcbiAgICAgICAgICAgICAgICBpZiAoJ3gnIGluIHBhcmFtcykge1xuICAgICAgICAgICAgICAgICAgICBub2RlLnggPSBwYXJhbXMueDtcbiAgICAgICAgICAgICAgICAgICAgbm9kZS55ID0gcGFyYW1zLnk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChwYXJhbXMub3BhY2l0eSAhPSB1bmRlZmluZWQgJiYgJ29wYWNpdHknIGluIG5vZGUpIHtcbiAgICAgICAgICAgICAgICAgICAgbm9kZS5vcGFjaXR5ID0gcGFyYW1zLm9wYWNpdHk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufVxuXG4iLCIvKiBcbi8vIFRoaXMgaXMgdGhlIGJhY2tlbmQgb2YgdGhlIHBsdWdpbi4gSXQgZWRpdHMgdGhlIGZpZ21hIGFydGJvYXJkLiBJdCBzZW5kcyBtZXNzYWdlcyB0byB0aGUgZnJvbnRlbmQgKGluIHRoZSBmaWxlIHNyYy9wbHVnaW4vdWkudHMpLCB3aGljaCBoYW5kbGVzIHVzZXIgaW50ZXJhY3Rpb24gYW5kIHRoZSBjb250ZW50cyBvZiB0aGUgcGx1Z2luIHdpbmRvdy5cbiovXG5cbmltcG9ydCB7IH0gZnJvbSAnQGZpZ21hL3BsdWdpbi10eXBpbmdzJ1xuXG5leHBvcnQge1xuICAgIGFsbFNsaWRlcywgZGVsZXRlSG92ZXJGcmFtZXMsIGZpbmRFdmVudE9iamVjdCwgZmluZE92ZXJsYXlOb2RlQnlJZCwgZmluZFNsaWRlLCBnZXREYXRhYmFzZSwgZ2V0Um9vdCwgbG9hZEN1cnJlbnREYXRhLCBzYXZlQ3VycmVudERhdGEsIHNlbENoYW5nZSwgc2VuZFRvVUksIHNsaWRlSWQsIHN0YXRlXG59XG5cblxuaW1wb3J0IHsgRGF0YWJhc2UsIFByZXNlbnRhdGlvbk5vZGUgfSBmcm9tICcuLi9jb21tb24vdHlwZXMnXG5pbXBvcnQgeyBjcmVhdGVDaGlsZEV2ZW50LCBjcmVhdGVOZXdTbGlkZSB9IGZyb20gJy4vY29kZS1jaGlsZC1ldmVudHMnXG5pbXBvcnQgeyBmaW5kU2xpZGUsIG92ZXJsYXlJZCwgc2xpZGVJZCB9IGZyb20gJy4vY29kZS1uYW1lLW1hbmFnZW1lbnQnXG5pbXBvcnQgeyBjYW5CZU92ZXJsYXlUYXJnZXQsIGNyZWF0ZU92ZXJsYXlFdmVudCB9IGZyb20gJy4vY29kZS1vdmVybGF5LWV2ZW50cydcbmltcG9ydCB7IGdldExhdGV4U2V0dGluZ3MsIGluaXRTZXR0aW5ncyB9IGZyb20gJy4vY29kZS1zZXR0aW5ncydcbmltcG9ydCB7IHVwZGF0ZVRodW1ibmFpbHMgfSBmcm9tICcuL2NvZGUtdGh1bWJuYWlscydcbmltcG9ydCB7IGxvYWRBbmltYXRpb25QYXJhbXMsIHNhdmVBbmltYXRpb25QYXJhbXMgfSBmcm9tICcuL2NvZGUtdGltZWxpbmUnXG5pbXBvcnQgeyBleHBvcnRTbGlkZXMgfSBmcm9tICcuL2V4cG9ydCdcbmltcG9ydCB7IGxhdGV4aXRPbmUsIGxhdGV4aXRUd28sIG1hdGVtYXR5a0RhdGEsIG1hdGVtYXR5a1dvcmQgfSBmcm9tICcuL21hdGVtYXR5aydcbmltcG9ydCB7IFBsdWdpbkNvZGVUb1VJLCBQbHVnaW5VSVRvQ29kZSB9IGZyb20gJy4vbWVzc2FnZXMtdWktcGx1Z2luJ1xuaW1wb3J0IHsgTGF0ZXhTdGF0ZSB9IGZyb20gJy4vcGx1Z2luLXR5cGVzJ1xuXG5cblxuXG4vLyoqKiBnbG9iYWwgdmFyaWFibGVzICovXG5cbmNvbnN0IHN0YXRlID0ge1xuICAgIC8vdGhlIGRhdGEgZm9yIHRoZSBjdXJyZW50IHNsaWRlLCBtYWlubHkgdGhlIGV2ZW50IGxpc3RcbiAgICBkYXRhYmFzZTogbnVsbCBhcyBEYXRhYmFzZSxcbiAgICAvL3RoZSBjdXJyZW50IHNsaWRlLCBhcyBhIGZyYW1lIG9mIGZpZ21hXG4gICAgY3VycmVudFNsaWRlOiBudWxsIGFzIEZyYW1lTm9kZSxcbn1cblxuXG5mdW5jdGlvbiBzZW5kVG9VSShtc2c6IFBsdWdpbkNvZGVUb1VJKTogdm9pZCB7XG4gICAgZmlnbWEudWkucG9zdE1lc3NhZ2UobXNnKVxufVxuXG5cblxuXG4vL3NlbmQgdGhlICBsaXN0IHdoaWNoIHNheXMgd2hhdCBhcmUgdGhlIHBvc3NpYmxlIGNhbmRpZGF0ZXMgZm9yIGNoaWxkIHNsaWRlcy4gXG5mdW5jdGlvbiBzZW5kRHJvcERvd25MaXN0KCkge1xuICAgIGNvbnN0IG1zZzogUGx1Z2luQ29kZVRvVUkgPSB7XG4gICAgICAgIHR5cGU6ICdkcm9wRG93bkNvbnRlbnRzJyxcbiAgICAgICAgc2xpZGVzOiBbXSBhcyB7XG4gICAgICAgICAgICBuYW1lOiBzdHJpbmcsXG4gICAgICAgICAgICBpZDogc3RyaW5nXG4gICAgICAgIH1bXVxuICAgIH1cblxuXG4gICAgZm9yIChjb25zdCBub2RlIG9mIGFsbFNsaWRlcygpKVxuICAgICAgICBpZiAobm9kZSAhPSBzdGF0ZS5jdXJyZW50U2xpZGUpIHtcbiAgICAgICAgICAgIGxldCBhbHJlYWR5Q2hpbGQgPSBmYWxzZTtcbiAgICAgICAgICAgIGZvciAoY29uc3QgZSBvZiBzdGF0ZS5kYXRhYmFzZS5ldmVudHMpIHtcbiAgICAgICAgICAgICAgICBpZiAoZS50eXBlID09IFwiY2hpbGRcIiAmJiBlLmlkID09IHNsaWRlSWQobm9kZSkpIHtcbiAgICAgICAgICAgICAgICAgICAgYWxyZWFkeUNoaWxkID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoIWFscmVhZHlDaGlsZClcbiAgICAgICAgICAgICAgICBtc2cuc2xpZGVzLnB1c2goe1xuICAgICAgICAgICAgICAgICAgICBuYW1lOiBub2RlLm5hbWUsXG4gICAgICAgICAgICAgICAgICAgIGlkOiBzbGlkZUlkKG5vZGUpXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cblxuXG4gICAgc2VuZFRvVUkobXNnKTtcbn1cblxuXG5cbi8vc2VuZCB0aGUgZXZlbnQgbGlzdCBvZiB0aGUgY3VycmVudCBzbGlkZVxuZnVuY3Rpb24gc2VuZEV2ZW50TGlzdCgpIHtcbiAgICAvL3RoZSBzbGlkZSBtaWdodCBiZSByZW1vdmVkXG4gICAgaWYgKHN0YXRlLmN1cnJlbnRTbGlkZSAhPSBudWxsICYmICFzdGF0ZS5jdXJyZW50U2xpZGUucmVtb3ZlZCkge1xuICAgICAgICBjbGVhbkRhdGFiYXNlKCk7XG4gICAgICAgIHNlbmRUb1VJKHtcbiAgICAgICAgICAgIHR5cGU6ICdldmVudExpc3QnLFxuICAgICAgICAgICAgZXZlbnRzOiBzdGF0ZS5kYXRhYmFzZS5ldmVudHMsXG4gICAgICAgICAgICBzZWxlY3RlZDogc3RhdGUuZGF0YWJhc2Uuc2VsZWN0ZWRcbiAgICAgICAgfSk7XG4gICAgfVxufVxuXG5cbi8vIGNyZWF0ZSBuZXcgZXZlbnQgXG4vL21zZy5pZCBpcyB1c2VkIGZvciB0aGUgJ2NoaWxkJyBldmVudFxuZnVuY3Rpb24gY3JlYXRlRXZlbnQoZXZlbnRJbmZvOiB7XG4gICAgdHlwZTogJ2NyZWF0ZUV2ZW50JyxcbiAgICBzdWJ0eXBlOiAnY2hpbGQnIHwgJ3Nob3cnIHwgJ2hpZGUnIHwgJ2FuaW1hdGUnLFxuICAgIGlkOiBzdHJpbmcsXG4gICAgbmFtZTogc3RyaW5nXG59KTogdm9pZCB7XG5cblxuICAgIHNhdmVBbmltYXRpb25QYXJhbXMoKTtcblxuXG4gICAgbGV0IGNyZWF0ZWRFdmVudHM6IFByZXNlbnRhdGlvbk5vZGVbXTtcblxuICAgIGlmIChldmVudEluZm8uc3VidHlwZSA9PSAnY2hpbGQnKSB7XG4gICAgICAgIC8vIHdlIGFyZSBjcmVhdGluZyBhIGNoaWxkIGV2ZW50XG4gICAgICAgIGlmIChldmVudEluZm8uaWQgPT0gbnVsbCkge1xuICAgICAgICAgICAgY29uc3QgbmV3U2xpZGUgPSBjcmVhdGVOZXdTbGlkZShzdGF0ZS5jdXJyZW50U2xpZGUud2lkdGgsIHN0YXRlLmN1cnJlbnRTbGlkZS5oZWlnaHQsIGV2ZW50SW5mby5uYW1lKTtcbiAgICAgICAgICAgIGV2ZW50SW5mby5pZCA9IHNsaWRlSWQobmV3U2xpZGUpXG4gICAgICAgIH1cbiAgICAgICAgY3JlYXRlZEV2ZW50cyA9IGNyZWF0ZUNoaWxkRXZlbnQoZXZlbnRJbmZvLmlkKTtcbiAgICB9XG4gICAgZWxzZSB7XG5cbiAgICAgICAgLy93ZSBhcmUgY3JlYXRpbmcgYW4gb3ZlcmxheSBldmVudFxuICAgICAgICBjcmVhdGVkRXZlbnRzID0gY3JlYXRlT3ZlcmxheUV2ZW50KGV2ZW50SW5mby5zdWJ0eXBlKTtcbiAgICB9XG5cblxuXG4gICAgLy8gaW5zZXJ0IHRoZSBuZXcgZXZlbnQgaW50byB0aGUgZGF0YWJhc2UsIGF0IHBvc2l0aW9uIHNlbGVjdGVkXG4gICAgZm9yIChjb25zdCBuZXdFdmVudCBvZiBjcmVhdGVkRXZlbnRzKSB7XG4gICAgICAgIHN0YXRlLmRhdGFiYXNlLmV2ZW50cy5zcGxpY2Uoc3RhdGUuZGF0YWJhc2Uuc2VsZWN0ZWQsIDAsIG5ld0V2ZW50KTtcbiAgICAgICAgc3RhdGUuZGF0YWJhc2Uuc2VsZWN0ZWQrKztcbiAgICB9XG5cblxuXG4gICAgc2F2ZUN1cnJlbnREYXRhKCk7XG4gICAgY29uc29sZS5sb2coJ2JlZm9yZSBsb2FkIGFuaW1hdGlvbiBwYXJhbXMnLCBKU09OLnN0cmluZ2lmeShzdGF0ZS5kYXRhYmFzZSkpO1xuICAgIGxvYWRBbmltYXRpb25QYXJhbXMoKTtcbiAgICBjb25zb2xlLmxvZygnYWZ0ZXIgbG9hZCBhbmltYXRpb24gcGFyYW1zJywgSlNPTi5zdHJpbmdpZnkoc3RhdGUuZGF0YWJhc2UpKTtcbiAgICBzZW5kRXZlbnRMaXN0KCk7XG59XG5cblxuLy9yZW1vdmUgYW4gZXZlbnQgZnJvbSB0aGUgY3VycmVudCBldmVudCBsaXN0XG5mdW5jdGlvbiByZW1vdmVFdmVudChpbmRleDogbnVtYmVyKTogdm9pZCB7XG4gICAgc2F2ZUFuaW1hdGlvblBhcmFtcygpO1xuICAgIGNvbnN0IGV2ZW50ID0gc3RhdGUuZGF0YWJhc2UuZXZlbnRzW2luZGV4XTtcbiAgICBpZiAoZXZlbnQudHlwZSA9PSBcImNoaWxkXCIpIHtcbiAgICAgICAgY29uc3QgcmVjdCA9IGZpbmRFdmVudE9iamVjdChldmVudCwgc3RhdGUuY3VycmVudFNsaWRlKTtcbiAgICAgICAgaWYgKHJlY3QgIT0gbnVsbClcbiAgICAgICAgICAgIHJlY3QucmVtb3ZlKCk7XG4gICAgfVxuXG4gICAgaWYgKHN0YXRlLmRhdGFiYXNlLnNlbGVjdGVkID4gaW5kZXgpXG4gICAgICAgIHN0YXRlLmRhdGFiYXNlLnNlbGVjdGVkLS07XG5cbiAgICBzdGF0ZS5kYXRhYmFzZS5ldmVudHMuc3BsaWNlKGluZGV4LCAxKTtcbiAgICBzYXZlQ3VycmVudERhdGEoKTtcbiAgICBsb2FkQW5pbWF0aW9uUGFyYW1zKCk7XG4gICAgc2VuZEV2ZW50TGlzdCgpO1xufVxuXG4vL21lcmdlIG9yIGRlLW1lcmdlIGFuIGV2ZW50IHdpdGggdGhlIHByZXZpb3VzIG9uZSBcbmZ1bmN0aW9uIG1lcmdlRXZlbnQoaW5kZXg6IG51bWJlcik6IHZvaWQge1xuICAgIGNvbnN0IGV2ZW50ID0gc3RhdGUuZGF0YWJhc2UuZXZlbnRzW2luZGV4XTtcbiAgICBldmVudC5tZXJnZWQgPSAhZXZlbnQubWVyZ2VkO1xuICAgIHNhdmVDdXJyZW50RGF0YSgpO1xuICAgIHNlbmRFdmVudExpc3QoKTtcbn1cblxuXG4vL2NoYW5nZSBvcmRlciBvZiBldmVudCBsaXN0IHNvIHRoYXQgc291cmNlIGJlY29tZXMgdGFyZ2V0LiBUaGUgc291cmNlIGFuZCB0YXJnZXQgYXJlIGNvdW50ZWQgYW1vbmcgbWVyZ2VkIGJsb2NrcyBvZiBldmVudHNcbmZ1bmN0aW9uIHJlb3JkZXJFdmVudHMoc291cmNlQmxvY2s6IG51bWJlciwgdGFyZ2V0QmxvY2s6IG51bWJlcik6IHZvaWQge1xuXG4gICAgc2F2ZUFuaW1hdGlvblBhcmFtcygpO1xuICAgIC8vdGhlIHNvdXJjZSBpcyBhIGJsb2NrLCBhbmQgc28gaXMgdGhlIHRhcmdldFxuICAgIGNvbnN0IGJsb2NrU3RhcnRzOiBudW1iZXJbXSA9IFtdO1xuICAgIGxldCBpOiBudW1iZXI7XG4gICAgZm9yIChpID0gMDsgaSA8IHN0YXRlLmRhdGFiYXNlLmV2ZW50cy5sZW5ndGg7IGkrKykge1xuICAgICAgICBpZiAoc3RhdGUuZGF0YWJhc2UuZXZlbnRzW2ldLm1lcmdlZCA9PSBmYWxzZSlcbiAgICAgICAgICAgIGJsb2NrU3RhcnRzLnB1c2goaSk7XG4gICAgfVxuICAgIGJsb2NrU3RhcnRzLnB1c2goaSk7XG4gICAgY29uc3Qgc291cmNlID0gYmxvY2tTdGFydHNbc291cmNlQmxvY2tdO1xuICAgIGNvbnN0IHRhcmdldCA9IGJsb2NrU3RhcnRzW3RhcmdldEJsb2NrXTtcbiAgICBjb25zdCBzb3VyY2VDb3VudCA9IGJsb2NrU3RhcnRzW3NvdXJjZUJsb2NrICsgMV0gLSBzb3VyY2U7XG4gICAgY29uc3QgdGFyZ2V0Q291bnQgPSBibG9ja1N0YXJ0c1t0YXJnZXRCbG9jayArIDFdIC0gdGFyZ2V0O1xuXG4gICAgbGV0IHJlYWxUYXJnZXQ7XG4gICAgaWYgKHNvdXJjZSA+IHRhcmdldCkge1xuICAgICAgICByZWFsVGFyZ2V0ID0gdGFyZ2V0O1xuICAgIH0gZWxzZSB7XG4gICAgICAgIHJlYWxUYXJnZXQgPSB0YXJnZXQgKyB0YXJnZXRDb3VudCAtIHNvdXJjZUNvdW50O1xuICAgIH1cblxuICAgIGNvbnN0IGJsb2NrID0gc3RhdGUuZGF0YWJhc2UuZXZlbnRzLnNwbGljZShzb3VyY2UsIHNvdXJjZUNvdW50KTtcbiAgICB3aGlsZSAoYmxvY2subGVuZ3RoID4gMCkge1xuICAgICAgICBzdGF0ZS5kYXRhYmFzZS5ldmVudHMuc3BsaWNlKHJlYWxUYXJnZXQsIDAsIGJsb2NrLnBvcCgpKTtcbiAgICB9XG5cbiAgICBzYXZlQ3VycmVudERhdGEoKTtcbiAgICBsb2FkQW5pbWF0aW9uUGFyYW1zKCk7XG4gICAgc2VuZEV2ZW50TGlzdCgpO1xuXG59XG5cblxuLy8gdGhpcyBmdW5jdGlvbiBpcyBjbGlja2VkIHdoZW4gdGhlIHVzZXIgY2xpY2tzIG9uIHRoZSBhbmltYXRlIGJhclxuZnVuY3Rpb24gY2xpY2tBbmltYXRlQmFyKG5ld0luZGV4OiBudW1iZXIpIHtcbiAgICBpZiAobmV3SW5kZXggPT0gc3RhdGUuZGF0YWJhc2Uuc2VsZWN0ZWQpXG4gICAgICAgIHJldHVybjtcbiAgICBkZWxldGVIb3ZlckZyYW1lcygpO1xuICAgIHNhdmVBbmltYXRpb25QYXJhbXMoKTtcbiAgICBzdGF0ZS5kYXRhYmFzZS5zZWxlY3RlZCA9IG5ld0luZGV4O1xuICAgIHNhdmVDdXJyZW50RGF0YSgpO1xuICAgIGxvYWRBbmltYXRpb25QYXJhbXMoKTtcbiAgICBzZW5kRXZlbnRMaXN0KCk7XG59XG5cblxuXG4vL3RoZXNlIGZyYW1lcyBhcmUgZGlzcGxheWVkIHdoZW4gdGhlIG1vdXNlIGhvdmVycyBvdmVyIGFuIGV2ZW50LiBJbiBwcmluY2lwbGUsIHRoZXJlIHNob3VsZCBiZSBhdCBtb3N0IG9uZSwgYnV0IGZvciBzb21lIHJlYXNvbiB0aGUgZGVsZXRlIGV2ZW50cyBhcmUgbm90IG1hdGNoZWQgd2l0aCB0aGUgY3JlYXRlIGV2ZW50cywgYW5kIHRoZXJlZm9yZSBJIGtlZXAgYSBsaXN0IG9mIGFsbCBmcmFtZXMsIGFuZCBkZWxldGUgYWxsIG9mIHRoZW0uXG5jb25zdCBob3ZlckZyYW1lczogUmVjdGFuZ2xlTm9kZVtdID0gW11cblxuLy9kZWxldGVzIGFsbCBob3ZlciBmcmFtZXNcbmZ1bmN0aW9uIGRlbGV0ZUhvdmVyRnJhbWVzKCkge1xuICAgIHdoaWxlIChob3ZlckZyYW1lcy5sZW5ndGggPiAwKVxuICAgICAgICBob3ZlckZyYW1lcy5wb3AoKS5yZW1vdmUoKTtcbn1cblxuLy93aGVuIHRoZSBtb3VzZSBob3ZlcnMgb3ZlciBhbiBldmVudCwgdGhlbiBpdCBzaG91bGQgYmUgaGlnaGxpZ2h0ZWQgYSBsaXR0bGUgZnJhbWVcbmZ1bmN0aW9uIGhvdmVyRXZlbnQoaW5kZXg6IG51bWJlcik6IHZvaWQge1xuXG4gICAgaWYgKGluZGV4ID09IC0xKSB7XG4gICAgICAgIC8vaWYgdGhlIGluZGV4IGlzIC0xLCB0aGVuIHRoZSBtb3VzZSBoYXMgbGVmdCwgYW5kIHRoZSBmcmFtZXMgc2hvdWxkIGJlIGRlbGV0ZWRcbiAgICAgICAgZGVsZXRlSG92ZXJGcmFtZXMoKTtcbiAgICB9XG4gICAgZWxzZSB7XG5cblxuICAgICAgICAvL290aGVyd2lzZSwgdGhlIGluZGV4IHNheXMgd2hpY2ggZXZlbnQgaXMgaG92ZXJlZCBvdmVyLiBJdCB3aWxsIGJlIHN1cnJvdW5kZWQgYnkgYSBmcmFtZVxuICAgICAgICBjb25zdCBldmVudCA9IHN0YXRlLmRhdGFiYXNlLmV2ZW50c1tpbmRleF07XG4gICAgICAgIGNvbnN0IGxpbmsgPSBmaW5kRXZlbnRPYmplY3QoZXZlbnQsIHN0YXRlLmN1cnJlbnRTbGlkZSk7XG4gICAgICAgIGlmIChsaW5rICE9IG51bGwpIHtcblxuICAgICAgICAgICAgY29uc3QgbWFyZ2luID0gMjA7XG4gICAgICAgICAgICAvLyBjcmVhdGUgYSBob3ZlciBmcmFtZVxuICAgICAgICAgICAgY29uc3QgaG92ZXJGcmFtZSA9IGZpZ21hLmNyZWF0ZVJlY3RhbmdsZSgpO1xuICAgICAgICAgICAgaG92ZXJGcmFtZS5yZXNpemUobGluay53aWR0aCArIDIgKiBtYXJnaW4sIGxpbmsuaGVpZ2h0ICsgMiAqIG1hcmdpbik7XG4gICAgICAgICAgICBob3ZlckZyYW1lLnggPSBsaW5rLnggLSBtYXJnaW5cbiAgICAgICAgICAgIGhvdmVyRnJhbWUueSA9IGxpbmsueSAtIG1hcmdpbjtcbiAgICAgICAgICAgIGhvdmVyRnJhbWUuZmlsbHMgPSBbe1xuICAgICAgICAgICAgICAgIHR5cGU6ICdTT0xJRCcsXG4gICAgICAgICAgICAgICAgY29sb3I6IHtcbiAgICAgICAgICAgICAgICAgICAgcjogMTczIC8gMjU1LFxuICAgICAgICAgICAgICAgICAgICBnOiAyMTYgLyAyNTUsXG4gICAgICAgICAgICAgICAgICAgIGI6IDIzMCAvIDI1NVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1dO1xuICAgICAgICAgICAgaG92ZXJGcmFtZS5uYW1lID0gJ3NsYWpkb21hdCBzZWxlY3Rpb24nO1xuICAgICAgICAgICAgaG92ZXJGcmFtZS5vcGFjaXR5ID0gMC41O1xuICAgICAgICAgICAgLy8gbWFrZSB0aGUgaG92ZXJmcmFtZSBiZSBiZWhpbmQgZXZlcnl0aGluZ1xuICAgICAgICAgICAgc3RhdGUuY3VycmVudFNsaWRlLmluc2VydENoaWxkKDAsIGhvdmVyRnJhbWUpO1xuICAgICAgICAgICAgaG92ZXJGcmFtZXMucHVzaChob3ZlckZyYW1lKTtcblxuICAgICAgICB9XG4gICAgfVxufVxuXG4vL2NvZGUgdGhhdCBpcyBydW4gd2hlbiB0aGUgcGx1Z2luIGlzIGNsb3NlZFxuZnVuY3Rpb24gY2xvc2VQbHVnaW4oKTogdm9pZCB7XG4gICAgZGVsZXRlSG92ZXJGcmFtZXMoKTtcbn1cblxuXG4vL2lmIHRoZSBldmVudCBvbiBhIHBsdWdpbiBpcyBjbGlja2VkLCB0aGVuIHRoZSBjb3JyZXNwb25kaW5nIG9iamVjdCBpbiBmaWdtYSBzaG91bGQgYmUgc2VsZWN0ZWRcbmZ1bmN0aW9uIGNsaWNrRXZlbnQoaW5kZXg6IG51bWJlcik6IHZvaWQge1xuICAgIGNvbnN0IGV2ZW50ID0gc3RhdGUuZGF0YWJhc2UuZXZlbnRzW2luZGV4XTtcbiAgICBpZiAoZXZlbnQudHlwZSA9PSAnY2hpbGQnKSB7XG4gICAgICAgIGdvdG9TbGlkZShmaW5kU2xpZGUoZXZlbnQuaWQpKTtcbiAgICB9XG59XG5cbi8vIHNhdmUgdGhlIHBsdWdpbiBkYXRhLCBmb3IgdGhlIGN1cnJlbnQgc2xpZGUsIHRvIHRoZSBmaWxlXG5mdW5jdGlvbiBzYXZlQ3VycmVudERhdGEoKTogdm9pZCB7XG4gICAgc3RhdGUuZGF0YWJhc2UubmFtZSA9IHN0YXRlLmN1cnJlbnRTbGlkZS5uYW1lO1xuICAgIHN0YXRlLmN1cnJlbnRTbGlkZS5zZXRQbHVnaW5EYXRhKFwiZGF0YWJhc2VcIiwgSlNPTi5zdHJpbmdpZnkoc3RhdGUuZGF0YWJhc2UpKTtcbn1cblxuXG4vLyB0aGUgb3Bwb3NpdGUgb2YgdGhlIHByZXZpb3VzIGZ1bmN0aW9uXG5mdW5jdGlvbiBsb2FkQ3VycmVudERhdGEoc2xpZGU6IEZyYW1lTm9kZSk6IHZvaWQge1xuICAgIHN0YXRlLmN1cnJlbnRTbGlkZSA9IHNsaWRlO1xuICAgIHN0YXRlLmRhdGFiYXNlID0gZ2V0RGF0YWJhc2Uoc3RhdGUuY3VycmVudFNsaWRlKTtcbiAgICBjbGVhbkRhdGFiYXNlKCk7XG59XG5cblxuZnVuY3Rpb24gZml4VmVyc2lvbihkYXRhYmFzZTogRGF0YWJhc2UpOiB2b2lkIHtcbiAgICBpZiAoZGF0YWJhc2Uub3JpZ2luYWxQYXJhbXMgPT0gdW5kZWZpbmVkKVxuICAgICAgICBkYXRhYmFzZS5vcmlnaW5hbFBhcmFtcyA9IHt9O1xufVxuXG5cbi8vZ2V0IHRoZSBkYXRhYmFzZSBmb3IgYSBzbGlkZVxuZnVuY3Rpb24gZ2V0RGF0YWJhc2Uoc2xpZGU6IEZyYW1lTm9kZSk6IERhdGFiYXNlIHtcbiAgICBjb25zdCBzID0gc2xpZGUuZ2V0UGx1Z2luRGF0YShcImRhdGFiYXNlXCIpO1xuICAgIGlmIChzID09ICcnKVxuICAgICAgICByZXR1cm4gdW5kZWZpbmVkXG4gICAgZWxzZSB7XG4gICAgICAgIGNvbnN0IHBhcnNlZCA9IEpTT04ucGFyc2Uocyk7XG4gICAgICAgIGZpeFZlcnNpb24ocGFyc2VkKTtcbiAgICAgICAgcmV0dXJuIHBhcnNlZDtcbiAgICB9XG59XG5cblxuXG4vL2Egbm9kZSBpcyBhIHNsaWRlIGlmIGl0IGNvbnRhaW5zIGEgZGF0YWJhc2VcbmZ1bmN0aW9uIGlzU2xpZGVOb2RlKG5vZGU6IEZyYW1lTm9kZSk6IGJvb2xlYW4ge1xuICAgIGlmIChub2RlID09IG51bGwpXG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICByZXR1cm4gKGdldERhdGFiYXNlKG5vZGUpICE9IG51bGwpXG59XG5cbi8vcmV0dXJuIHRoZSBsaXN0IG9mIGFsbCBzbGlkZXNcbmZ1bmN0aW9uIGFsbFNsaWRlcygpOiBGcmFtZU5vZGVbXSB7XG4gICAgY29uc3QgcmV0dmFsID0gW10gYXMgRnJhbWVOb2RlW107XG4gICAgZm9yIChjb25zdCBub2RlIG9mIChmaWdtYS5jdXJyZW50UGFnZS5jaGlsZHJlbiBhcyBGcmFtZU5vZGVbXSkpIHtcbiAgICAgICAgaWYgKGlzU2xpZGVOb2RlKG5vZGUpKVxuICAgICAgICAgICAgcmV0dmFsLnB1c2gobm9kZSlcbiAgICB9XG4gICAgcmV0dXJuIHJldHZhbFxufVxuXG5cbi8vZmluZCBhbiBub2RlIGluIHRoZSBjdXJyZW50IHNsaWNkZSB3aXRoIHRoZSBnaXZlbiBpZFxuZnVuY3Rpb24gZmluZE92ZXJsYXlOb2RlQnlJZChpZDogc3RyaW5nLCBzbGlkZTogRnJhbWVOb2RlKTogU2NlbmVOb2RlIHtcbiAgICBmb3IgKGNvbnN0IGNoaWxkIG9mIHNsaWRlLmNoaWxkcmVuKVxuICAgICAgICBpZiAoaWQgPT0gb3ZlcmxheUlkKGNoaWxkKSlcbiAgICAgICAgICAgIHJldHVybiBjaGlsZCBhcyBTY2VuZU5vZGU7XG59XG5cbi8vR2l2ZXMgdGhlIG9iamVjdCBpbiB0aGUgc2xpZGUgdGhhdCBjb3JyZXNwb25kcyB0byB0aGUgZXZlbnQuIEZvciBhIHNob3cvaGlkZSBldmVudCB0aGlzIGlzIHRoZSBub2RlIHRoYXQgaXMgc2hvd24vaGlkZGVuLiBGb3IgYSBjaGlsZCBldmVudCwgdGhpcyBpcyB0aGUgbGluayB0byB0aGUgY2hpbGQuXG5mdW5jdGlvbiBmaW5kRXZlbnRPYmplY3QoZXZlbnQ6IFByZXNlbnRhdGlvbk5vZGUsIHNsaWRlOiBGcmFtZU5vZGUpOiBTY2VuZU5vZGUge1xuICAgIGlmIChldmVudC50eXBlID09ICdjaGlsZCcpIHtcbiAgICAgICAgLy9maW5kIHRoZSBvYmplY3QgaW4gdGhlIGN1cnJlbnQgc2xpZGUsIHdoaWNoIHJlcHJlc2VudHMgYSBsaW5rIHRvIGEgY2hpbGQgc2xpZGUuIFRoaXMgb2JqZWN0IGlzIGluZGljYXRlZCBieSBwbHVnaW4gZGF0YS4gQ3VycmVudGx5LCBpdCBpcyBhIHNlbWktdHJhbnNwYXJlbnQgcmVkIHJlY3RhbmdsZS5cbiAgICAgICAgY29uc3Qgbm9kZXMgPSBzbGlkZS5maW5kQWxsKChub2RlOiBTY2VuZU5vZGUpID0+IG5vZGUuZ2V0UGx1Z2luRGF0YShcImNoaWxkTGlua1wiKSA9PSBldmVudC5pZCk7XG4gICAgICAgIGlmIChub2Rlcy5sZW5ndGggPiAwKVxuICAgICAgICAgICAgcmV0dXJuIG5vZGVzWzBdIGFzIFNjZW5lTm9kZVxuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgLy8gZm9yIG92ZXJsYXkgZXZlbnRzLCB3ZSBzZWFyY2ggaWYgdGhlIGNvcnJlc3BvbmRpbmcgb2JqZWN0IGV4aXN0cyBpbiB0aGUgY3VycmVudCBzbGlkZVxuICAgICAgICByZXR1cm4gZmluZE92ZXJsYXlOb2RlQnlJZChldmVudC5pZCwgc2xpZGUpO1xuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbn1cblxuXG4vLyBkaXNhYmxlIGV2ZW50cyB0aGF0IGFyZSBub3QgYXZhaWxhYmxlLCBhbmQgZml4IHN0dWZmIGZyb20gb2xkZXIgdmVyc2lvbnNcbmZ1bmN0aW9uIGNsZWFuRGF0YWJhc2UoKTogdm9pZCB7XG4gICAgXG4gICAgc3RhdGUuZGF0YWJhc2UubmFtZSA9IHN0YXRlLmN1cnJlbnRTbGlkZS5uYW1lO1xuXG4gICAgLy8gdGhpcyB3aWxsIGJlIGNhbGxlZCB3aGVuIG9wZW5pbmcgdGhlIHNsaWRlIGZvciB0aGUgZmlyc3QgdGltZSwgb3IgXG4gICAgLy8gd2hlbiB1c2luZyBhIHNsaWRlIGNyZWF0ZWQgaW4gb2xkZXIgdmVyc2lvbnNcbiAgICBpZiAoc3RhdGUuZGF0YWJhc2Uuc2VsZWN0ZWQgPT0gdW5kZWZpbmVkKVxuICAgICAgICBzdGF0ZS5kYXRhYmFzZS5zZWxlY3RlZCA9IHN0YXRlLmRhdGFiYXNlLmV2ZW50cy5sZW5ndGg7XG5cbiAgICAvL2ZvciBlYWNoIGV2ZW50LCBjaGVjayBpZiBpdCBpcyBhY3RpdmVcbiAgICAvLyBhIGNoaWxkIGV2ZW50IGlzIGFjdGl2ZSBpZiB0aGUgbGlua2VkIGZyYW1lIGV4aXN0c1xuICAgIC8vIGEgc2hvdy9oaWRlIGV2ZW50IGlzIGFjdGl2ZSBpZiB0aGUgbGlua2VkIG9iamVjdCBleGlzdHNcbiAgICAvLyBmb3IgdGhlIGFjdGl2ZSBzaG93L2hpZGUgZXZlbnRzLCBzdG9yZSB0aGUgaW5kZXggb2YgdGhlIGNvcnJlc3BvbmRpbmcgaXRlbVxuICAgIGZvciAoY29uc3QgZXZlbnQgb2Ygc3RhdGUuZGF0YWJhc2UuZXZlbnRzKSB7XG4gICAgICAgIGV2ZW50LmVuYWJsZWQgPSAnZGlzYWJsZWQnO1xuICAgICAgICBjb25zdCBub2RlID0gZmluZEV2ZW50T2JqZWN0KGV2ZW50LCBzdGF0ZS5jdXJyZW50U2xpZGUpO1xuICAgICAgICBpZiAobm9kZSAhPSBudWxsKSB7XG4gICAgICAgICAgICBpZiAoZXZlbnQudHlwZSA9PSBcImNoaWxkXCIpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBmID0gZmluZFNsaWRlKGV2ZW50LmlkKTtcbiAgICAgICAgICAgICAgICBpZiAoZiAhPSBudWxsKSB7XG4gICAgICAgICAgICAgICAgICAgIGV2ZW50Lm5hbWUgPSBmLm5hbWU7XG4gICAgICAgICAgICAgICAgICAgIG5vZGUubmFtZSA9ICdsaW5rIHRvICcgKyBmLm5hbWU7XG4gICAgICAgICAgICAgICAgICAgIGV2ZW50LmVuYWJsZWQgPSAnZW5hYmxlZCc7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGV2ZW50LnR5cGUgPT0gXCJzaG93XCIgfHwgZXZlbnQudHlwZSA9PSBcImhpZGVcIiB8fCBldmVudC50eXBlID09IFwiYW5pbWF0ZVwiKSB7XG4gICAgICAgICAgICAgICAgZXZlbnQubmFtZSA9IG5vZGUubmFtZTtcbiAgICAgICAgICAgICAgICBldmVudC5lbmFibGVkID0gJ2VuYWJsZWQnO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufVxuXG5cbi8vcmV0dXJuIGFueSBzbGlkZSB0aGF0IHBvaW50cyB0byBzbGlkZSBhcyBhIGNoaWxkXG5mdW5jdGlvbiBwYXJlbnRTbGlkZShzbGlkZTogRnJhbWVOb2RlKTogRnJhbWVOb2RlIHtcbiAgICBmb3IgKGNvbnN0IG90aGVyIG9mIGFsbFNsaWRlcygpKSB7XG4gICAgICAgIGNvbnN0IGRiID0gZ2V0RGF0YWJhc2Uob3RoZXIpO1xuICAgICAgICBpZiAoZGIgIT0gdW5kZWZpbmVkKVxuICAgICAgICAgICAgZm9yIChjb25zdCBldmVudCBvZiBkYi5ldmVudHMpXG4gICAgICAgICAgICAgICAgaWYgKGV2ZW50LnR5cGUgPT0gJ2NoaWxkJyAmJiBldmVudC5pZCA9PSBzbGlkZUlkKHNsaWRlKSlcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG90aGVyO1xuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbn1cblxuXG4vL3NldCB0aGUgY3VycmVudCBzbGlkZSBvZiB0aGUgcGx1Z2luXG5mdW5jdGlvbiBzZXRDdXJyZW50U2xpZGUoc2xpZGU6IEZyYW1lTm9kZSk6IHZvaWQge1xuXG4gICAgaWYgKHNsaWRlICE9IG51bGwpIHtcbiAgICAgICAgbG9hZEN1cnJlbnREYXRhKHNsaWRlKTtcbiAgICAgICAgY29uc3QgaXNSb290ID0gZ2V0Um9vdCgpID09IHN0YXRlLmN1cnJlbnRTbGlkZTtcbiAgICAgICAgY29uc3QgbXNnOiBQbHVnaW5Db2RlVG9VSSA9IHtcbiAgICAgICAgICAgIHR5cGU6ICdzbGlkZUNoYW5nZScsXG4gICAgICAgICAgICBkb2NOYW1lOiBmaWdtYS5yb290Lm5hbWUsXG4gICAgICAgICAgICBzbGlkZTogc3RhdGUuY3VycmVudFNsaWRlLm5hbWUsXG4gICAgICAgICAgICBpc1Jvb3Q6IGlzUm9vdCxcbiAgICAgICAgICAgIHNsaWRlQ291bnQ6IGFsbFNsaWRlcygpLmxlbmd0aCxcbiAgICAgICAgfVxuXG4gICAgICAgIHNlbmRUb1VJKG1zZyk7XG4gICAgICAgIHNlbmRFdmVudExpc3QoKTtcbiAgICAgICAgdXBkYXRlVGh1bWJuYWlscygpO1xuXG4gICAgfSBlbHNlIHtcbiAgICAgICAgc2VuZFRvVUkoe1xuICAgICAgICAgICAgdHlwZTogJ25vU2xpZGUnXG4gICAgICAgIH0pXG4gICAgfVxufVxuXG4vL2dvIHRvIGEgc2xpZGUgYW5kIHNob3cgaXQgb24gdGhlIHNjcmVlblxuZnVuY3Rpb24gZ290b1NsaWRlKHNsaWRlOiBGcmFtZU5vZGUpOiB2b2lkIHtcbiAgICBmaWdtYS52aWV3cG9ydC5zY3JvbGxBbmRab29tSW50b1ZpZXcoW3NsaWRlXSk7XG4gICAgc2V0Q3VycmVudFNsaWRlKHNsaWRlKTtcbn1cblxuXG4vL3JldHVybnMgdGhlIHNsaWRlIHdpdGggdGhlIGN1cnJlbnRseSBzZWxlY3RlZCBvYmplY3RcbmZ1bmN0aW9uIHNsaWRlV2l0aFNlbGVjdGlvbigpOiBGcmFtZU5vZGUge1xuICAgIGNvbnN0IHNlbCA9IGZpZ21hLmN1cnJlbnRQYWdlLnNlbGVjdGlvbjtcbiAgICBpZiAoc2VsLmxlbmd0aCA+IDApIHtcbiAgICAgICAgbGV0IG5vZGUgPSBzZWxbMF07XG4gICAgICAgIHdoaWxlICghaXNTbGlkZU5vZGUobm9kZSBhcyBGcmFtZU5vZGUpICYmIG5vZGUgIT0gbnVsbClcbiAgICAgICAgICAgIG5vZGUgPSBub2RlLnBhcmVudCBhcyBTY2VuZU5vZGU7XG4gICAgICAgIHJldHVybiBub2RlIGFzIEZyYW1lTm9kZTtcbiAgICB9IGVsc2VcbiAgICAgICAgcmV0dXJuIG51bGw7XG59XG5cbi8vZmluZHMgdGhlIHJvb3QgZnJvbSBwcmV2aW91cyBzZXNzaW9uc1xuZnVuY3Rpb24gZ2V0Um9vdCgpOiBGcmFtZU5vZGUge1xuICAgIGNvbnN0IHJvb3RTbGlkZSA9IGZpbmRTbGlkZShmaWdtYS5yb290LmdldFBsdWdpbkRhdGEoJ3Jvb3RTbGlkZScpKTtcbiAgICBpZiAocm9vdFNsaWRlID09IG51bGwpIHtcbiAgICAgICAgc2V0Um9vdCgpO1xuICAgIH1cbiAgICByZXR1cm4gcm9vdFNsaWRlO1xuXG59XG5cbi8vY2hhbmdlIHRoZSByb290IHRvIHRoZSBjdXJyZW50IHNsaWRlXG5mdW5jdGlvbiBzZXRSb290KCk6IHZvaWQge1xuICAgIGZpZ21hLnJvb3Quc2V0UGx1Z2luRGF0YSgncm9vdFNsaWRlJywgc2xpZGVJZChzdGF0ZS5jdXJyZW50U2xpZGUpKTtcbn1cblxuXG5cbi8vZXZlbnQgaGFuZGxlciBmb3Igd2hlbiB0aGUgZG9jdW1lbnQgaGFzIGNoYW5nZWQuIFdlIHVzZSB0aGlzIHRvIHJlLXByb3BvcnRpb24gdGhlIHJlZCByZWN0YW5nbGVzIGZvciB0aGUgY2hpbGQgbGlua1xuZnVuY3Rpb24gZG9jQ2hhbmdlKGNoYW5nZXM6IERvY3VtZW50Q2hhbmdlRXZlbnQpOiB2b2lkIHtcbiAgICBmb3IgKGNvbnN0IHggb2YgY2hhbmdlcy5kb2N1bWVudENoYW5nZXMpIHtcbiAgICAgICAgaWYgKCh4LnR5cGUgPT0gJ1BST1BFUlRZX0NIQU5HRScpKSB7XG4gICAgICAgICAgICBjb25zdCBjaGFuZ2UgPSB4Lm5vZGUgYXMgU2NlbmVOb2RlO1xuICAgICAgICAgICAgaWYgKCghY2hhbmdlLnJlbW92ZWQpICYmIChjaGFuZ2UuZ2V0UGx1Z2luRGF0YSgnY2hpbGRMaW5rJykgIT0gJycpKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgcmVjdCA9IGNoYW5nZSBhcyBSZWN0YW5nbGVOb2RlO1xuICAgICAgICAgICAgICAgIHJlY3QucmVzaXplKHJlY3Qud2lkdGgsIHJlY3Qud2lkdGggKiBzdGF0ZS5jdXJyZW50U2xpZGUuaGVpZ2h0IC8gc3RhdGUuY3VycmVudFNsaWRlLndpZHRoKTtcbiAgICAgICAgICAgIH1cblxuXG4gICAgICAgIH1cbiAgICB9XG5cbn1cblxuLy9ldmVudCBoYW5kbGVyIGZvciB3aGVuIHRoZSBzZWxlY3Rpb24gaGFzIGNoYW5nZWRcbmZ1bmN0aW9uIHNlbENoYW5nZSgpOiB2b2lkIHtcbiAgICAvL2lmIHRoZXJlIGlzIGEgc2F2ZWQgc2VsZWN0aW9uLCB0aGlzIG1lYW5zIHRoYXQgdGhlIGNoYW5nZSB3YXMgdHJpZ2dlcmVkIGJ5IHRoZSB1c2VyIGhvdmVyaW5nIG92ZXIgdGhlIGV2ZW50IGxpc3QgaW4gdGhlIHBsdWdpbiwgYW5kIGhlbmNlIGl0IHNob3VsZCBub3QgY291bnRcblxuICAgIGNvbnN0IHNsaWRlID0gc2xpZGVXaXRoU2VsZWN0aW9uKCk7XG5cblxuICAgIC8vd2UgY2hhbmdlIHRoZSBjdXJyZW50IHNsaWRlIGlmIGl0IHNhdGlzZmllcyBjZXJ0YWluIGNvbmRpdGlvbnM6IG9yIHRoZSBzZWxlY3Rpb24gaGFzIG1vdmVkIHRvIHNvbWUgb3RoZXIgbm9uLW51bGwgc2xpZGUgKHRoZSBzZWxlY3Rpb24gaXMgaW4gYSBudWxsIHNsaWRlIGlmIGl0IGlzIG91dHNpZGUgYWxsIHNsaWRlcykgXG4gICAgaWZcbiAgICAgICAgLy9pdCBoYXMgYmVlbiByZW1vdmVkOyBvclxuICAgICAgICAoKHN0YXRlLmN1cnJlbnRTbGlkZSAhPSBudWxsICYmIHN0YXRlLmN1cnJlbnRTbGlkZS5yZW1vdmVkKSB8fFxuICAgICAgICAvL3RoZSBzZWxlY3Rpb24gaGFzIG1vdmVkIHRvIHNvbWUgb3RoZXIgbm9uLW51bGwgc2xpZGU7IG9yIFxuICAgICAgICAoc2xpZGUgIT0gc3RhdGUuY3VycmVudFNsaWRlICYmIHNsaWRlICE9IG51bGwpIHx8XG4gICAgICAgIC8vdGhlIG5hbWUgb2YgdGhlIHNsaWRlIGhhcyBjaGFuZ2VkXG4gICAgICAgIChzdGF0ZS5jdXJyZW50U2xpZGUgIT0gbnVsbCAmJiBzdGF0ZS5jdXJyZW50U2xpZGUgPT0gc2xpZGUgJiYgc3RhdGUuY3VycmVudFNsaWRlLm5hbWUgIT0gc2xpZGUubmFtZSkpXG4gICAgICAgIHNldEN1cnJlbnRTbGlkZShzbGlkZSk7XG4gICAgZWxzZSBpZiAoc3RhdGUuY3VycmVudFNsaWRlICE9IHVuZGVmaW5lZCAmJiBzdGF0ZS5kYXRhYmFzZS5uYW1lICE9IHN0YXRlLmN1cnJlbnRTbGlkZS5uYW1lKSB7XG4gICAgICAgIC8vaWYgdGhlIG5hbWUgb2YgdGhlIGN1cnJlbnQgc2xpZGUgd2FzIGNoYW5nZWQsIHRoZW4gd2UgYWxzbyBzZW5kIHRoaXMgdG8gdGhlIHVpXG4gICAgICAgIHNldEN1cnJlbnRTbGlkZShzdGF0ZS5jdXJyZW50U2xpZGUpO1xuICAgIH1cbiAgICBlbHNlIGlmIChzdGF0ZS5jdXJyZW50U2xpZGUgIT0gbnVsbClcbiAgICAgICAgc2VuZEV2ZW50TGlzdCgpO1xuXG4gICAgY29uc3Qgc2VsID0gZmlnbWEuY3VycmVudFBhZ2Uuc2VsZWN0aW9uO1xuXG4gICAgY29uc3QgbXNnOiBQbHVnaW5Db2RlVG9VSSA9IHtcbiAgICAgICAgdHlwZTogJ3NlbENoYW5nZScsXG4gICAgICAgIHNlbGVjdGVkOiBmYWxzZSwgLy8gaXMgdGhlcmUgYXQgbGVhc3Qgb25lIG9iamVjdCB0aGF0IGNhbiBiZSB1c2VkIGZvciBzaG93L2hpZGVcbiAgICAgICAgbGF0ZXhTdGF0ZTogTGF0ZXhTdGF0ZS5Ob25lLCAvLyBpcyB0aGUgY3VycmVudCBzZWxlY3Rpb24gYW4gb2JqZWN0IHRoYXQgY2FuIGJlIGxhdGV4ZWQvZGUtbGF0ZXhlZFxuICAgICAgICBjYW5JbnNlcnQ6IGZhbHNlLCAvLyBpcyB0aGUgY2FyZXQgaW4gYSB0ZXh0IGZpZWxkIHdoZXJlIGNoYXJhY3RlcnMgY2FuIGJlIGluc2VydGVkXG4gICAgICAgIGN1cnJlbnRGb250OiBudWxsIGFzIEZvbnROYW1lXG4gICAgfTtcblxuICAgIGZvciAoY29uc3QgaXRlbSBvZiBmaWdtYS5jdXJyZW50UGFnZS5zZWxlY3Rpb24pIHtcbiAgICAgICAgaWYgKGNhbkJlT3ZlcmxheVRhcmdldChpdGVtKSlcbiAgICAgICAgICAgIG1zZy5zZWxlY3RlZCA9IHRydWU7XG4gICAgfVxuXG4gICAgLy8gdGhpcyBwYXJ0IG9mIHRoZSBjb2RlIGlzIGZvciB0aGUgbWF0aCBmZWF0dXJlcyBvZiBsYXRleGl0IGFuZCBpbnNlcnRpbmcgY2hhcmFjdGVyc1xuXG4gICAgaWYgKHNlbC5sZW5ndGggPT0gMSkge1xuICAgICAgICBpZiAoc2VsWzBdLnR5cGUgPT0gXCJURVhUXCIpIC8vdGhlIHNlbGVjdGVkIG9iamVjdCBjYW4gYmUgbGF0ZXhlZFxuICAgICAgICAgICAgbXNnLmxhdGV4U3RhdGUgPSBMYXRleFN0YXRlLkxhdGV4O1xuICAgICAgICBpZiAobWF0ZW1hdHlrRGF0YShzZWxbMF0pICE9IG51bGwpIC8vdGhlIHNlbGVjdGVkIG9iamVjdCBjYW4gYmUgZGUtbGF0ZXhlZFxuICAgICAgICAgICAgbXNnLmxhdGV4U3RhdGUgPSBMYXRleFN0YXRlLkRlbGF0ZXhcbiAgICB9XG4gICAgaWYgKGZpZ21hLmN1cnJlbnRQYWdlLnNlbGVjdGVkVGV4dFJhbmdlICE9IG51bGwpIHtcbiAgICAgICAgY29uc3QgciA9IGZpZ21hLmN1cnJlbnRQYWdlLnNlbGVjdGVkVGV4dFJhbmdlLmVuZDtcbiAgICAgICAgaWYgKHIgPiAwKSB7XG4gICAgICAgICAgICBtc2cuY3VycmVudEZvbnQgPSAoc2VsWzBdIGFzIFRleHROb2RlKS5nZXRSYW5nZUZvbnROYW1lKHIgLSAxLCByKSBhcyBGb250TmFtZVxuICAgICAgICB9XG4gICAgICAgIG1zZy5jYW5JbnNlcnQgPSB0cnVlO1xuICAgIH1cbiAgICAvL3NlbmQgdGhlIGluZm9ybWF0aW9uIGFib3V0IHRoZSB1cGRhdGVkIHNlbGVjdGlvblxuICAgIHNlbmRUb1VJKG1zZylcbn1cblxuXG4vL2hhbmRsZSBtZXNzYWdlcyB0aGF0IGNvbWUgZnJvbSB0aGUgdWlcbmZ1bmN0aW9uIG9uTWVzc2FnZShtc2c6IFBsdWdpblVJVG9Db2RlKSB7XG5cbiAgICBzd2l0Y2ggKG1zZy50eXBlKSB7XG5cbiAgICAgICAgY2FzZSAnbm90aWZ5JzpcbiAgICAgICAgICAgIC8vd3JpdGUgYSB1c2VyIG5vdGlmaWNhdGlvblxuICAgICAgICAgICAgZmlnbWEubm90aWZ5KG1zZy50ZXh0KTtcbiAgICAgICAgICAgIGJyZWFrXG5cbiAgICAgICAgY2FzZSAnY2xpY2tBbmltYXRlQmFyJzpcbiAgICAgICAgICAgIGNsaWNrQW5pbWF0ZUJhcihtc2cuaW5kZXgpO1xuICAgICAgICAgICAgYnJlYWs7XG5cbiAgICAgICAgY2FzZSAnY3JlYXRlRXZlbnQnOlxuICAgICAgICAgICAgLy9jcmVhdGUgYSBuZXcgZXZlbnQgZm9yIHRoZSBjdXJyZW50IHNsaWRlXG4gICAgICAgICAgICAvL3RoaXMgY292ZXJzIHNob3cvaGlkZS9jaGlsZCBldmVudHNcbiAgICAgICAgICAgIGNyZWF0ZUV2ZW50KG1zZyk7XG4gICAgICAgICAgICBicmVhaztcblxuICAgICAgICBjYXNlICdzZXR0aW5ncyc6XG4gICAgICAgICAgICAvL2dldCBzZXR0aW5ncyBmcm9tIHRoZSBpbnRlcmZhY2VcbiAgICAgICAgICAgIGdldExhdGV4U2V0dGluZ3MobXNnLnBsdWdpblNldHRpbmdzKTtcbiAgICAgICAgICAgIGJyZWFrO1xuXG4gICAgICAgIGNhc2UgJ3JlbW92ZUV2ZW50JzpcbiAgICAgICAgICAgIC8vcmVtb3ZlIGFuIGV2ZW50XG4gICAgICAgICAgICByZW1vdmVFdmVudChtc2cuaW5kZXgpO1xuICAgICAgICAgICAgYnJlYWs7XG5cbiAgICAgICAgY2FzZSAnbWVyZ2VFdmVudCc6XG4gICAgICAgICAgICAvL21lcmdlIGFuIGV2ZW50IHdpdGggdGhlIHByZXZpb3VzIG9uZVxuICAgICAgICAgICAgbWVyZ2VFdmVudChtc2cuaW5kZXgpO1xuICAgICAgICAgICAgYnJlYWs7XG5cbiAgICAgICAgY2FzZSAnbW92ZUV2ZW50JzpcbiAgICAgICAgICAgIC8vc3dhcCB0aGUgb3JkZXIgb2YgdHdvIGV2ZW50c1xuICAgICAgICAgICAgcmVvcmRlckV2ZW50cyhtc2cuaW5kZXgsIG1zZy50YXJnZXQpO1xuICAgICAgICAgICAgZGVsZXRlSG92ZXJGcmFtZXMoKTtcbiAgICAgICAgICAgIGJyZWFrO1xuXG4gICAgICAgIGNhc2UgJ21ha2VGaXJzdCc6XG4gICAgICAgICAgICAvL21ha2UgYSBmaXJzdCBzbGlkZVxuICAgICAgICAgICAgc2V0Q3VycmVudFNsaWRlKGNyZWF0ZU5ld1NsaWRlKG1zZy53aWR0aCwgbXNnLmhlaWdodCwgJ25ldyBzbGlkZScpKTtcbiAgICAgICAgICAgIGZpZ21hLnZpZXdwb3J0LnNjcm9sbEFuZFpvb21JbnRvVmlldyhbc3RhdGUuY3VycmVudFNsaWRlXSk7XG4gICAgICAgICAgICBicmVhaztcblxuICAgICAgICBjYXNlICdzYXZlRmlsZSc6XG4gICAgICAgICAgICAvL2V4cG9ydCB0aGUgZmlsZXMgdG8gc3ZnIGZpbGVzXG4gICAgICAgICAgICBleHBvcnRTbGlkZXMoKTtcbiAgICAgICAgICAgIGJyZWFrO1xuXG4gICAgICAgIGNhc2UgJ2NoYW5nZVJvb3QnOlxuICAgICAgICAgICAgc2V0Um9vdCgpO1xuICAgICAgICAgICAgYnJlYWs7XG5cbiAgICAgICAgY2FzZSAnbW91c2VFbnRlclBsdWdpbic6XG4gICAgICAgICAgICAvLyAvL0knbSBub3Qgc3VyZSBpZiB0aGlzIGlzIG5lY2Vzc2FyeSwgYnV0IGp1c3QgaW4gY2FzZSBJIHJlZnJlc2ggdGhlIGV2ZW50IGxpc3Qgd2hlbiB0aGUgbW91c2UgZW50ZXJzIHRoZSBwbHVnaW4uXG4gICAgICAgICAgICAvLyBpZiAoc3RhdGUuY3VycmVudFNsaWRlICE9IG51bGwpXG4gICAgICAgICAgICAvLyAgICAgc2VuZEV2ZW50TGlzdCgpO1xuICAgICAgICAgICAgYnJlYWs7XG5cbiAgICAgICAgY2FzZSAnaG92ZXJFdmVudCc6XG4gICAgICAgICAgICAvL2hpZ2hsaWdodCBhbiBldmVudCB3aGVuIHRoZSBtb3VzZSBob3ZlcnMgb3ZlciBpdC4gRm9yIHNob3cvaGlkZSBldmVudCB3ZSBjaGFuZ2UgdGhlIHNlbGVjdGlvbiB0byB0aGUgY29uY2VybmVkIG9iamVjdCwgZm9yIGNoaWxkIGV2ZW50cyB3ZSBkbyB0aGlzIGZvciB0aGUgbGluay5cbiAgICAgICAgICAgIGhvdmVyRXZlbnQobXNnLmluZGV4KTtcbiAgICAgICAgICAgIGJyZWFrO1xuXG4gICAgICAgIGNhc2UgJ3JlcXVlc3REcm9wRG93bic6XG4gICAgICAgICAgICAvL3JlcXVlc3QgYSBsaXN0IG9mIGFsbCBzbGlkZXMgZm9yIHRoZSBjdXJyZW50IHNsaWRlXG4gICAgICAgICAgICBzZW5kRHJvcERvd25MaXN0KCk7XG4gICAgICAgICAgICBicmVhaztcblxuICAgICAgICBjYXNlICdtb3VzZUxlYXZlJzpcbiAgICAgICAgICAgIGJyZWFrO1xuXG4gICAgICAgIGNhc2UgJ2NsaWNrRXZlbnQnOlxuICAgICAgICAgICAgLy9pZiBhbiBldmVudCBpcyBjbGlja2VkLCB0aGVuIHRoZSBzZWxlY3Rpb24gc3RheXMgcGVybWFuZW50XG4gICAgICAgICAgICBjbGlja0V2ZW50KG1zZy5pbmRleClcbiAgICAgICAgICAgIGJyZWFrO1xuXG4gICAgICAgIGNhc2UgJ2dvdG9QYXJlbnQnOlxuICAgICAgICAgICAgLy90aGUgcGFyZW50IGJ1dHRvbiBpcyBjbGlja2VkXG4gICAgICAgICAgICBnb3RvU2xpZGUocGFyZW50U2xpZGUoc3RhdGUuY3VycmVudFNsaWRlKSk7XG4gICAgICAgICAgICBicmVhaztcblxuICAgICAgICBjYXNlICdhZGRXb3JkJzpcbiAgICAgICAgICAgIC8vZnVuY3Rpb25zIGZvciB0aGUgbWF0ZW1hdHlrIHBsdWdpbiAqKioqKipcbiAgICAgICAgICAgIG1hdGVtYXR5a1dvcmQobXNnLnRleHQpO1xuICAgICAgICAgICAgYnJlYWs7XG5cbiAgICAgICAgY2FzZSAnbGF0ZXhpdCc6XG4gICAgICAgICAgICAvL3RoZSB1c2VyIHJlcXVlc3RzIHR1cm5pbmcgdGV4dCBpbnRvIGxhdGV4XG4gICAgICAgICAgICBsYXRleGl0T25lKCk7XG4gICAgICAgICAgICBicmVhaztcblxuICAgICAgICBjYXNlICdsYXRleGl0VHdvJzpcbiAgICAgICAgICAgIC8vdGhlIHNlY29uZCBzdGFnZSBvZiBsYXRleGl0LCBpcyBuZWNlc3NhcnkgYmVjYXVzZSBvbmx5IHRoZSB1aSBjYW4gY29tbXVuaWNhdGUgd2l0aCB0aGUgd2ViXG4gICAgICAgICAgICBsYXRleGl0VHdvKG1zZy50ZXh0KTtcbiAgICAgICAgICAgIGJyZWFrO1xuXG5cbiAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgIHRocm93IFwidW5jb3ZlcmVkIG1lc3NhZ2UgdHlwZSBzZW50IHRvIGNvZGU6IFwiXG5cbiAgICB9XG59XG5cbmZpZ21hLm9uKCdkb2N1bWVudGNoYW5nZScsIGRvY0NoYW5nZSk7XG5maWdtYS5vbihcInNlbGVjdGlvbmNoYW5nZVwiLCBzZWxDaGFuZ2UpO1xuZmlnbWEub24oJ2Nsb3NlJywgY2xvc2VQbHVnaW4pO1xuZmlnbWEuc2hvd1VJKF9faHRtbF9fLCB7XG4gICAgd2lkdGg6IDIzMCxcbiAgICBoZWlnaHQ6IDUwMFxufSk7XG5maWdtYS51aS5vbm1lc3NhZ2UgPSBvbk1lc3NhZ2U7XG5cblxuXG5zZXRDdXJyZW50U2xpZGUoc2xpZGVXaXRoU2VsZWN0aW9uKCkpO1xuaW5pdFNldHRpbmdzKCk7XG5cblxuIiwiZXhwb3J0IHsgZXhwb3J0U2xpZGVzIH07XG5cblxuXG5pbXBvcnQge1xuICAgIEFuaW1hdGlvblBhcmFtcyxcbiAgICBEYXRhYmFzZSxcbiAgICBQcmVzZW50YXRpb25Ob2RlLCBTbGlkZVxufSBmcm9tICcuLi9jb21tb24vdHlwZXMnO1xuXG5pbXBvcnQge1xuICAgIGRlbGV0ZUhvdmVyRnJhbWVzLFxuICAgIGZpbmRFdmVudE9iamVjdCxcbiAgICBmaW5kT3ZlcmxheU5vZGVCeUlkLFxuICAgIGZpbmRTbGlkZSxcbiAgICBnZXRSb290LFxuICAgIGxvYWRDdXJyZW50RGF0YSxcbiAgICBzYXZlQ3VycmVudERhdGEsXG4gICAgc2VuZFRvVUksXG4gICAgc3RhdGVcbn0gZnJvbSAnLi9jb2RlJztcbmltcG9ydCB7IGFsbFRleHRzIH0gZnJvbSAnLi9jb2RlLW5hbWUtbWFuYWdlbWVudCc7XG5cblxuLy9kZWR1cGxpY2F0ZSBhIGxpc3Qgb2Ygc3RyaW5nc1xuZnVuY3Rpb24gZGVEdXBsaWNhdGUobGlzdDogc3RyaW5nW10pOiBzdHJpbmdbXSB7XG4gICAgY29uc3QgcmV0dmFsID0gW10gYXMgc3RyaW5nW107XG4gICAgZm9yIChjb25zdCBzdHJpbmcgb2YgbGlzdClcbiAgICAgICAgaWYgKCFyZXR2YWwuaW5jbHVkZXMoc3RyaW5nKSlcbiAgICAgICAgICAgIHJldHZhbC5wdXNoKHN0cmluZyk7XG4gICAgcmV0dXJuIHJldHZhbDtcbn1cblxuLy9jb21wbGllcyBhIGxpc3Qgb2Ygc2VhcmNoIGtleXdvcmRzIGZvciB0aGUgY3VycmVudCBzbGlkZVxuZnVuY3Rpb24gY29tcGlsZUtleXdvcmRzKGV2ZW50OiBTbGlkZSwgZnJhbWU6IEZyYW1lTm9kZSkge1xuXG5cbiAgICBjb25zdCBkb25lID0gW10gYXMgU2NlbmVOb2RlW107XG5cbiAgICBmb3IgKGNvbnN0IGNoaWxkIG9mIGV2ZW50LmNoaWxkcmVuKSB7XG4gICAgICAgIC8vd2Ugb25seSBjcmVhdGUga2V5d29yZHMgZm9yIHNob3cgY2hpbGRyZW4sIHdoaWNoIGFyZSBmaXJzdFxuICAgICAgICBpZiAoY2hpbGQudHlwZSA9PSAnc2hvdycpIHtcbiAgICAgICAgICAgIGNvbnN0IG5vZGUgPSBmaW5kRXZlbnRPYmplY3QoY2hpbGQsIGZyYW1lKTtcbiAgICAgICAgICAgIGlmICghZG9uZS5pbmNsdWRlcyhub2RlKSkge1xuICAgICAgICAgICAgICAgIGRvbmUucHVzaChub2RlKTtcbiAgICAgICAgICAgICAgICBjaGlsZC5rZXl3b3JkcyA9IGFsbFRleHRzKG5vZGUpO1xuICAgICAgICAgICAgICAgIGNoaWxkLmtleXdvcmRzLnB1c2goY2hpbGQubmFtZSk7XG4gICAgICAgICAgICAgICAgY2hpbGQua2V5d29yZHMgPSBkZUR1cGxpY2F0ZShjaGlsZC5rZXl3b3Jkcyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgLy90aGUga2V5d29yZHMgZm9yIHRoZSBzbGlkZSBpdHNlbGYgaXMgYWxsIG90aGVyIGtleXdvcmRzIHRoYXQgd2VyZSBub3QgaW5jbHVkZWQgYWJvdmVcbiAgICBldmVudC5rZXl3b3JkcyA9IGFsbFRleHRzKGZyYW1lLCBkb25lKTtcbiAgICBldmVudC5rZXl3b3Jkcy5wdXNoKGV2ZW50Lm5hbWUpO1xuICAgIGV2ZW50LmtleXdvcmRzID0gZGVEdXBsaWNhdGUoZXZlbnQua2V5d29yZHMpO1xufVxuXG5cbi8vc2VuZCB0aGUgc3ZnIGZpbGUgdG8gdGhlIHVpLCB3aGljaCB0aGVuIHNlbmRzIGl0IHRvIHRoZSBzZXJ2ZXJcbmZ1bmN0aW9uIGV4cG9ydFNsaWRlcygpOiB2b2lkIHtcblxuICAgIC8vaW4gY2FzZSB0aGVyZSBhcmUgc29tZSBzdHJhZ2dsZXIgYmx1ZSBmcmFtZXMsIGRlbGV0ZSB0aGVtXG4gICAgZGVsZXRlSG92ZXJGcmFtZXMoKTtcblxuICAgIC8vdGhlIGxpc3Qgb2Ygc2xpZGVzIGFuZCB0aGVpciBzdmcgZmlsZXNcbiAgICBjb25zdCBzbGlkZUxpc3Q6IHtcbiAgICAgICAgZGF0YWJhc2U6IERhdGFiYXNlLFxuICAgICAgICBzdmc6IFVpbnQ4QXJyYXlcbiAgICB9W10gPSBbXTtcblxuICAgIC8vc3RhY2sgb2YgdGhlIHJlY3Vyc2lvbiwgdG8gZmluZCBjeWNsZXMgaW4gc2xpZGVzXG4gICAgY29uc3Qgc3RhY2s6IEZyYW1lTm9kZVtdID0gW107XG5cbiAgICAvL1NhdmVzIGEgc2luZ2xlIHNsaWRlLCBhbmQgdGhlbiBjYWxscyBpdHNlbGYgZm9yIHRoZSBjaGlsZHJlbiBvZiB0aGF0IHNsaWRlLiBUaGUgcmVzdWx0IG9mIHNhdmluZyBpcyBhIG5ldyBpdGVtIG9uIHNsaWRlTGlzdC5cbiAgICBhc3luYyBmdW5jdGlvbiBzYXZlUmVjKHNsaWRlOiBGcmFtZU5vZGUsIGV2ZW50SWQ6IHN0cmluZyk6IFByb21pc2U8UHJlc2VudGF0aW9uTm9kZT4ge1xuICAgICAgICBpZiAoc3RhY2suaW5jbHVkZXMoc2xpZGUpKSB7XG4gICAgICAgICAgICBsZXQgY3ljbGUgPSBcIlRoZSBzbGlkZXMgY29udGFpbiBhIGN5Y2xlOiBcXG5cIjtcbiAgICAgICAgICAgIGZvciAoY29uc3QgbiBvZiBzdGFjaylcbiAgICAgICAgICAgICAgICBjeWNsZSArPSAobi5uYW1lICsgXCJcXG5cIik7XG4gICAgICAgICAgICBmaWdtYS5ub3RpZnkoY3ljbGUgKyBzbGlkZS5uYW1lKTtcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgc3RhY2sucHVzaChzbGlkZSk7XG4gICAgICAgICAgICBsb2FkQ3VycmVudERhdGEoc2xpZGUpO1xuXG5cblxuICAgICAgICAgICAgLy9XZSB0ZW1wb3JhcmlseSBjaGFuZ2UgdGhlIG5hbWVzIG9mIHRoZSBjaGlsZHJlbiB0byB0aGVpciBpZCdzLCBzbyB0aGF0IHRoZSBzdmcgd2lsbCBoYXZlIHRoZW0gYXMgaWQncy4gKFRoaXMgaXMgYmVjYXVzZSBGaWdtYSdzIHN2ZyBleHBvcnQgdXNlcyB0aGUgb2JqZWN0J3MgbmFtZSBhcyB0aGUgaWQgZm9yIHRoZSBzdmcuIClcbiAgICAgICAgICAgIC8vdGhlIGZ1bmN0aW9uIHJldHVybnMgYSBsaXN0IG9mIHBhaXJzIChub2RlLCBvbGQgbmFtZSkgdGhhdCBjYW4gYmUgdXNlZCB0byByZXZlcnQgdGhlc2UgY2hhbmdlc1xuICAgICAgICAgICAgY29uc3QgY2hhbmdlczoge1xuICAgICAgICAgICAgICAgIG5vZGU6IFNjZW5lTm9kZSxcbiAgICAgICAgICAgICAgICBzYXZlZE5hbWU6IHN0cmluZ1xuICAgICAgICAgICAgfVtdID0gW107XG4gICAgICAgICAgICBmb3IgKGNvbnN0IGV2ZW50IG9mIHN0YXRlLmRhdGFiYXNlLmV2ZW50cykge1xuICAgICAgICAgICAgICAgIGNvbnN0IG5vZGUgPSBmaW5kRXZlbnRPYmplY3QoZXZlbnQsIHNsaWRlKTtcbiAgICAgICAgICAgICAgICBpZiAobm9kZSAhPSBudWxsKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vd2Ugc3RvcmUgdGhlIGNoYW5nZXMgaW4gcmV2ZXJzZSBvcmRlciwgIHNvIHRoYXQgdGhlIG9yaWdpbmFsIG5hbWVzIGFyZSBhdCB0aGUgZW5kIG9mIHRoZSBjaGFuZ2UgbGlzdCBcbiAgICAgICAgICAgICAgICAgICAgY2hhbmdlcy51bnNoaWZ0KHsgLy91bnNoaWZ0IGluc3RlYWQgb2YgcHVzaCBtYWtlcyB0aGUgb3JkZXIgcmV2ZXJzZWRcbiAgICAgICAgICAgICAgICAgICAgICAgIG5vZGU6IG5vZGUsXG4gICAgICAgICAgICAgICAgICAgICAgICBzYXZlZE5hbWU6IG5vZGUubmFtZVxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgbm9kZS5uYW1lID0gZXZlbnQuaWQ7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBjb25zdCBzdmcgPSBhd2FpdCBzbGlkZS5leHBvcnRBc3luYyh7XG4gICAgICAgICAgICAgICAgZm9ybWF0OiAnU1ZHJyxcbiAgICAgICAgICAgICAgICBzdmdPdXRsaW5lVGV4dDogdHJ1ZSxcbiAgICAgICAgICAgICAgICBzdmdJZEF0dHJpYnV0ZTogdHJ1ZVxuICAgICAgICAgICAgfSk7XG5cblxuXG4gICAgICAgICAgICAvL3dlIG5vdyB1bmRvIHRoZSBuYW1lIGNoYW5nZXMuIFRoaXMgbmVlZHMgdG8gYmUgZG9uZSBpbiByZXZlcnNlIG9yZGVyIHRvIHJlY292ZXIgdGhlIG9yaWdpbmFsIG5hbWVzXG4gICAgICAgICAgICBmb3IgKGNvbnN0IGNoYW5nZSBvZiBjaGFuZ2VzKSB7XG4gICAgICAgICAgICAgICAgY2hhbmdlLm5vZGUubmFtZSA9IGNoYW5nZS5zYXZlZE5hbWU7XG4gICAgICAgICAgICB9XG5cblxuICAgICAgICAgICAgLy8gdGhlIHN2ZyBtaWdodCBiZSBleHBvcnRlZCBhdCBhIGRpZmZlcmVudCBwb3NpdGlvbiB0aGFuIHRoZSBvcmlnaW5hbCwgc28gd2UgbmVlZCB0byBvZmZzZXQgdGhlIGFuaW1hdGlvbiBwYXJhbWV0ZXJzXG4gICAgICAgICAgICBmdW5jdGlvbiBvZmZzZXRQYXJhbXMocGFyYW1zOiBBbmltYXRpb25QYXJhbXMsIGlkOiBzdHJpbmcpIHtcbiAgICAgICAgICAgICAgICBjb25zdCByZXR2YWwgPSB7IC4uLnBhcmFtcyB9O1xuICAgICAgICAgICAgICAgIGlmIChyZXR2YWwueCA9PSB1bmRlZmluZWQpIFxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gcmV0dmFsO1xuICAgICAgICAgICAgICAgIGNvbnN0IG5vZGUgPSBmaW5kT3ZlcmxheU5vZGVCeUlkKGlkLCBzbGlkZSk7XG4gICAgICAgICAgICAgICAgaWYgKG5vZGUgPT0gdW5kZWZpbmVkKSBcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICAgICAgICAgICAgICByZXR2YWwueCAtPSBub2RlLng7XG4gICAgICAgICAgICAgICAgcmV0dmFsLnkgLT0gbm9kZS55O1xuICAgICAgICAgICAgICAgIHJldHVybiByZXR2YWw7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vZm9yIGV4cG9ydCwgd2UgZ2VuZXJhdGUgYSBjb3B5IG9mIHRoZSBvcmlnaW5hbFBhcmFtcyBkaWN0aW9uYXJ5LCBpbiB3aGljaCBhbGwgcGFyYW1ldGVycyBhcmUgb2Zmc2V0XG4gICAgICAgICAgICBjb25zdCBvZmZzZXRPcmlnaW5hbFBhcmFtczogeyBbaWQ6IHN0cmluZ106IEFuaW1hdGlvblBhcmFtcyB9ID0gIHt9O1xuICAgICAgICAgICAgZm9yIChjb25zdCBpZCBpbiBzdGF0ZS5kYXRhYmFzZS5vcmlnaW5hbFBhcmFtcykgXG4gICAgICAgICAgICB7ICAgXG4gICAgICAgICAgICAgICAgY29uc3QgYWZ0ZXJPZmZzZXQgPSBvZmZzZXRQYXJhbXMoc3RhdGUuZGF0YWJhc2Uub3JpZ2luYWxQYXJhbXNbaWRdLCBpZCk7XG4gICAgICAgICAgICAgICAgb2Zmc2V0T3JpZ2luYWxQYXJhbXNbaWRdID0gYWZ0ZXJPZmZzZXQ7XG4gICAgICAgICAgICB9XG5cblxuICAgICAgICAgICAgY29uc3QgcmV0dmFsOiBTbGlkZSA9IHtcbiAgICAgICAgICAgICAgICB0eXBlOiAnY2hpbGQnLFxuICAgICAgICAgICAgICAgIG5hbWU6IHN0YXRlLmRhdGFiYXNlLm5hbWUsXG4gICAgICAgICAgICAgICAgaWQ6IHN0YXRlLmRhdGFiYXNlLmlkLFxuICAgICAgICAgICAgICAgIGVuYWJsZWQ6ICdlbmFibGVkJyxcbiAgICAgICAgICAgICAgICBtZXJnZWQ6IGZhbHNlLFxuICAgICAgICAgICAgICAgIGNoaWxkcmVuOiBbXSxcbiAgICAgICAgICAgICAgICBrZXl3b3JkczogW10sXG4gICAgICAgICAgICAgICAgZXZlbnRJZDogZXZlbnRJZCxcbiAgICAgICAgICAgICAgICBvcmlnaW5hbFBhcmFtczogb2Zmc2V0T3JpZ2luYWxQYXJhbXNcbiAgICAgICAgICAgIH07XG5cbiAgICAgICAgICAgIHNhdmVDdXJyZW50RGF0YSgpO1xuICAgICAgICAgICAgc2xpZGVMaXN0LnB1c2goe1xuICAgICAgICAgICAgICAgIGRhdGFiYXNlOiBzdGF0ZS5kYXRhYmFzZSxcbiAgICAgICAgICAgICAgICBzdmc6IHN2Z1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IGV2ZW50IG9mIHN0YXRlLmRhdGFiYXNlLmV2ZW50cykge1xuICAgICAgICAgICAgICAgIGlmIChldmVudC5lbmFibGVkID09ICdlbmFibGVkJykge1xuICAgICAgICAgICAgICAgICAgICBpZiAoZXZlbnQudHlwZSA9PSBcImNoaWxkXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGNoaWxkID0gYXdhaXQgc2F2ZVJlYyhmaW5kU2xpZGUoZXZlbnQuaWQpLCBldmVudC5ldmVudElkKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNoaWxkLm1lcmdlZCA9IGV2ZW50Lm1lcmdlZDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHZhbC5jaGlsZHJlbi5wdXNoKGNoaWxkKTtcbiAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IGNvcGllZCA9IHsgLi4uZXZlbnQgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvcGllZC5rZXl3b3JkcyA9IFtjb3BpZWQubmFtZV07XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBhbmltYXRlIGV2ZW50cyBuZWVkIHRvIGhhdmUgdGhlaXIgcGFyYW1ldGVycyBvZmZzZXRcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChjb3BpZWQudHlwZSA9PSAnYW5pbWF0ZScpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29waWVkLnBhcmFtcyA9IG9mZnNldFBhcmFtcyhjb3BpZWQucGFyYW1zLCBjb3BpZWQuaWQpO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dmFsLmNoaWxkcmVuLnB1c2goY29waWVkKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbG9hZEN1cnJlbnREYXRhKHN0YWNrLnBvcCgpKTtcbiAgICAgICAgICAgIGNvbXBpbGVLZXl3b3JkcyhyZXR2YWwsIHN0YXRlLmN1cnJlbnRTbGlkZSk7XG5cbiAgICAgICAgICAgIHJldHVybiByZXR2YWw7XG4gICAgICAgIH1cbiAgICB9XG5cblxuXG4gICAgY29uc3Qgc2F2ZWRTbGlkZSA9IHN0YXRlLmN1cnJlbnRTbGlkZTtcbiAgICBjb25zdCByb290U2xpZGUgPSBnZXRSb290KCk7XG4gICAgaWYgKHJvb3RTbGlkZSAhPSBudWxsKSB7XG4gICAgICAgIHNhdmVSZWMoZ2V0Um9vdCgpLCAncm9vdCcpLnRoZW4oeCA9PiB7XG4gICAgICAgICAgICBzZW5kVG9VSSh7XG4gICAgICAgICAgICAgICAgdHlwZTogJ3NhdmVQcmVzZW50YXRpb24nLFxuICAgICAgICAgICAgICAgIG5hbWU6IGZpZ21hLnJvb3QubmFtZSxcbiAgICAgICAgICAgICAgICBzbGlkZUxpc3Q6IHNsaWRlTGlzdCxcbiAgICAgICAgICAgICAgICB0cmVlOiB4XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGxvYWRDdXJyZW50RGF0YShzYXZlZFNsaWRlKTtcbiAgICAgICAgfSk7XG4gICAgfVxuXG59XG4iLCJcbmV4cG9ydCB7XG4gICAgbWF0ZW1hdHlrRGF0YSxcbiAgICBsYXRleGl0T25lLFxuICAgIGxhdGV4aXRUd28sXG4gICAgbWF0ZW1hdHlrV29yZFxufVxuXG5pbXBvcnQge1xuICAgIExhdGV4aXREYXRhLFxufSBmcm9tICcuL3BsdWdpbi10eXBlcydcblxuaW1wb3J0IHtcbiAgICBwbHVnaW5TZXR0aW5ncyxcbiAgICBzZW5kU2V0dGluZ3Ncbn0gZnJvbSAnLi9jb2RlLXNldHRpbmdzJ1xuXG5cbi8vIGZ1bmN0aW9ucyBmb3IgbWF0ZW1hdHlrICoqKioqKioqKioqKioqXG4vL2luc2VydHMgdGhlIHdvcmQgaW4gdGhlIGZvbnQgU1RJWEdlbmVyYWxcbmxldCBsYXRleGl0U2VsZWN0aW9uIDogU2NlbmVOb2RlO1xuXG5cblxuXG5cbi8vdGhlIGZpcnN0IHN0YWdlIG9mIGxhdGV4aXQsIHdoZW4gd2UgZmluZCB0aGUgb2JqZWN0IHRvIGJlIGxhdGV4ZWRcbmZ1bmN0aW9uIGxhdGV4aXRPbmUoKSA6IHZvaWQge1xuICAgIGlmIChmaWdtYS5jdXJyZW50UGFnZS5zZWxlY3Rpb24ubGVuZ3RoID4gMCkge1xuICAgICAgICBsYXRleGl0U2VsZWN0aW9uID0gZmlnbWEuY3VycmVudFBhZ2Uuc2VsZWN0aW9uWzBdO1xuICAgICAgICBjb25zdCBkYXRhID0gbWF0ZW1hdHlrRGF0YShsYXRleGl0U2VsZWN0aW9uKTtcblxuICAgICAgICBpZiAobGF0ZXhpdFNlbGVjdGlvbi50eXBlID09ICdURVhUJykge1xuICAgICAgICAgICAgY29uc3QgdXJsID0gcGx1Z2luU2V0dGluZ3MubGF0ZXhpdFVSTCArIGVuY29kZVVSSUNvbXBvbmVudCgobGF0ZXhpdFNlbGVjdGlvbiBhcyBUZXh0Tm9kZSkuY2hhcmFjdGVycyk7XG4gICAgICAgICAgICBmaWdtYS51aS5wb3N0TWVzc2FnZSh7XG4gICAgICAgICAgICAgICAgdHlwZTogJ2ZldGNobGF0ZXgnLFxuICAgICAgICAgICAgICAgIHVybDogdXJsXG4gICAgICAgICAgICB9KTtcblxuXG4gICAgICAgIH0gZWxzZVxuICAgICAgICBpZiAoZGF0YSAhPSBudWxsKSB7XG4gICAgICAgICAgICBjb25zdCB0ZXh0ID0gZmlnbWEuY3JlYXRlVGV4dCgpO1xuICAgICAgICAgICAgbGF0ZXhpdFNlbGVjdGlvbi5wYXJlbnQuYXBwZW5kQ2hpbGQodGV4dCk7XG4gICAgICAgICAgICBmaWdtYS5sb2FkRm9udEFzeW5jKHRleHQuZm9udE5hbWUgYXMgRm9udE5hbWUpLnRoZW4oKCkgPT4ge1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIHRleHQubmFtZSA9IGxhdGV4aXRTZWxlY3Rpb24ubmFtZTtcbiAgICAgICAgICAgICAgICAgICAgdGV4dC5jaGFyYWN0ZXJzID0gZGF0YS5jb2RlO1xuICAgICAgICAgICAgICAgICAgICB0ZXh0LmZvbnRTaXplID0gZGF0YS5mb250c2l6ZTtcbiAgICAgICAgICAgICAgICAgICAgdGV4dC54ID0gbGF0ZXhpdFNlbGVjdGlvbi54O1xuICAgICAgICAgICAgICAgICAgICB0ZXh0LnkgPSBsYXRleGl0U2VsZWN0aW9uLnk7XG4gICAgICAgICAgICAgICAgICAgIGxhdGV4aXRTZWxlY3Rpb24ucmVtb3ZlKCk7XG4gICAgICAgICAgICAgICAgICAgIGZpZ21hLmN1cnJlbnRQYWdlLnNlbGVjdGlvbiA9IFt0ZXh0XTtcbiAgICAgICAgICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgICAgICAgICBmaWdtYS5ub3RpZnkoXCJDb3VsZCBub3QgZGVsYXRleC5cIik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSlcbiAgICAgICAgfVxuICAgIH1cbn1cblxuLy9mdW5jdGlvbiByZXR1cm5zIHRoZSBtYXRlbWF0eWsgZGF0YSBmb3IgYSBub2RlXG5mdW5jdGlvbiBtYXRlbWF0eWtEYXRhKG5vZGUgOiBTY2VuZU5vZGUpIDogTGF0ZXhpdERhdGEge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHN0ciA9IG5vZGUuZ2V0UGx1Z2luRGF0YSgnbWF0ZW1hdHlrJyk7XG4gICAgICAgIHJldHVybiBKU09OLnBhcnNlKHN0cilcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbn1cblxuLy90aGUgc2Vjb25kIHN0YXRlIG9mIGxhdGV4aXQsIHdoZW4gd2UgZ290IHRoZSBzdmdcbmZ1bmN0aW9uIGxhdGV4aXRUd28oc3ZnIDogc3RyaW5nKSA6IHZvaWQge1xuICAgIGNvbnN0IG5vZGUgPSBmaWdtYS5jcmVhdGVOb2RlRnJvbVN2ZyhzdmcpO1xuICAgIFxuICAgIC8vaWYgd2UgZ290IGhlcmUsIHRoZW4gd2Uga25vdyB0aGF0IHRoZSBzZWxlY3Rpb24gd2FzIHRleHQsIGFuZCB3aWxsIGJlIHR1cm5lZCB0byBzdmdcbiAgICBjb25zdCBvcmlnaW5hbCA9IGxhdGV4aXRTZWxlY3Rpb24gYXMgVGV4dE5vZGU7XG5cbiAgICBjb25zdCBwYXJlbnQgPSBmaWdtYS5jdXJyZW50UGFnZS5zZWxlY3Rpb25bMF0ucGFyZW50O1xuICAgIHBhcmVudC5hcHBlbmRDaGlsZChub2RlKTtcblxuXG4gICAgY29uc3QgbGF0ZXhEYXRhIDogTGF0ZXhpdERhdGEgPSB7XG4gICAgICAgIGZvbnRzaXplOiBvcmlnaW5hbC5nZXRSYW5nZUZvbnRTaXplKDAsIDEpIGFzIG51bWJlcixcbiAgICAgICAgY29kZTogb3JpZ2luYWwuY2hhcmFjdGVyc1xuICAgIH1cbiAgICBub2RlLnNldFBsdWdpbkRhdGEoXCJtYXRlbWF0eWtcIiwgSlNPTi5zdHJpbmdpZnkobGF0ZXhEYXRhKSk7XG5cbiAgICBub2RlLm5hbWUgPSBsYXRleERhdGEuY29kZTtcbiAgICBub2RlLnJlc2NhbGUobGF0ZXhEYXRhLmZvbnRzaXplICogMC4wNjUpO1xuICAgIG5vZGUueCA9IGxhdGV4aXRTZWxlY3Rpb24ueDtcbiAgICBub2RlLnkgPSBsYXRleGl0U2VsZWN0aW9uLnk7XG5cbiAgICBsYXRleGl0U2VsZWN0aW9uLnJlbW92ZSgpO1xuICAgIGZpZ21hLmN1cnJlbnRQYWdlLnNlbGVjdGlvbiA9IFtub2RlXTtcblxufVxuXG4vL2luc2VydHMgdGhlIHdvcmQgdyBhZnRlciB0aGUgY2FyZXQsIFxuZnVuY3Rpb24gbWF0ZW1hdHlrV29yZChhZGRlZFN0cmluZyA6IHN0cmluZykgOiB2b2lkIHtcblxuICAgIC8vZmlnbWEgcmVxdWlyZXMgbWUgdG8gbG9hZCBsb3RzIG9mIGZvbnRzIGJlZm9yZSBjaGFuZ2luZyBhbnl0aGluZyBpbiB0aGUgdGV4dCBmaWVsZFxuICAgIGZ1bmN0aW9uIGxvYWRGb250cyhub2RlIDogVGV4dE5vZGUpIDogUHJvbWlzZTx2b2lkW10+IHtcbiAgICAgICAgY29uc3QgbGVuID0gbm9kZS5jaGFyYWN0ZXJzLmxlbmd0aDtcbiAgICAgICAgY29uc3QgZm9udEFycmF5ID0gW2ZpZ21hLmxvYWRGb250QXN5bmMocGx1Z2luU2V0dGluZ3MubWF0aEZvbnQpXTtcblxuICAgICAgICBpZiAodHlwZW9mIG5vZGUuZm9udE5hbWUgIT0gJ3N5bWJvbCcpIC8vdGhlcmUgaXMgbW9yZSB0aGFuIG9uZSBmb250XG4gICAgICAgIHtcbiAgICAgICAgICAgIGZvbnRBcnJheS5wdXNoKGZpZ21hLmxvYWRGb250QXN5bmMobm9kZS5mb250TmFtZSkpXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgICAgICAgICAgICAgZm9udEFycmF5LnB1c2goZmlnbWEubG9hZEZvbnRBc3luYyhub2RlLmdldFJhbmdlRm9udE5hbWUoaSwgaSArIDEpIGFzIEZvbnROYW1lKSlcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gUHJvbWlzZS5hbGwoZm9udEFycmF5KTtcbiAgICB9XG5cbiAgICAvL3RoZSBhZGRlZCBzdHJpbmcgc2hvdWxkIGJlIGF0IHRoZSBmcm9udCBvZiB0aGUgY2FjaGUsIHNvIGlmIGl0IGlzIHByZXNlbnQgaW4gdGhlIGNhY2hlLCB0aGVuIHdlIGRlbGV0ZSBpdFxuICAgIGNvbnN0IGluZGV4ID0gcGx1Z2luU2V0dGluZ3Mud29yZHMuaW5kZXhPZihhZGRlZFN0cmluZylcbiAgICBpZiAoaW5kZXggIT0gLTEpIC8vIGlmIGl0IGlzIGluIHRoZSBjYWNoZVxuICAgICAgICBwbHVnaW5TZXR0aW5ncy53b3Jkcy5zcGxpY2UoaW5kZXgsIDEpO1xuICAgIHBsdWdpblNldHRpbmdzLndvcmRzLnB1c2goYWRkZWRTdHJpbmcpO1xuICAgIHNlbmRTZXR0aW5ncygpO1xuICAgIGZpZ21hLmNsaWVudFN0b3JhZ2Uuc2V0QXN5bmMoJ3NsYWpkb21hdCcsIEpTT04uc3RyaW5naWZ5KHBsdWdpblNldHRpbmdzKSk7XG5cblxuICAgIC8vYWRkIHRoZSB3b3JkIGFmdGVyIHRoZSBzZWxlY3RlZCByYW5nZSBcbiAgICBjb25zdCByYW5nZSA9IGZpZ21hLmN1cnJlbnRQYWdlLnNlbGVjdGVkVGV4dFJhbmdlO1xuICAgIGlmIChyYW5nZSAhPSBudWxsKSB7XG4gICAgICAgIGxvYWRGb250cyhyYW5nZS5ub2RlKS50aGVuKCgpID0+IHtcbiAgICAgICAgICAgIHJhbmdlLm5vZGUuaW5zZXJ0Q2hhcmFjdGVycyhyYW5nZS5zdGFydCwgYWRkZWRTdHJpbmcgKyBcIiBcIik7XG4gICAgICAgICAgICBjb25zdCBzaXplID0gcmFuZ2Uubm9kZS5nZXRSYW5nZUZvbnRTaXplKHJhbmdlLnN0YXJ0LCByYW5nZS5zdGFydCArIDEpIGFzIG51bWJlcjtcbiAgICAgICAgICAgIHJhbmdlLm5vZGUuc2V0UmFuZ2VGb250TmFtZShyYW5nZS5zdGFydCwgcmFuZ2Uuc3RhcnQgKyBhZGRlZFN0cmluZy5sZW5ndGgsIHBsdWdpblNldHRpbmdzLm1hdGhGb250KTtcbiAgICAgICAgICAgIHJhbmdlLm5vZGUuc2V0UmFuZ2VGb250U2l6ZShyYW5nZS5zdGFydCwgcmFuZ2Uuc3RhcnQgKyBhZGRlZFN0cmluZy5sZW5ndGgsIHNpemUgKiBwbHVnaW5TZXR0aW5ncy5tYXRoRm9udFNpemUpO1xuICAgICAgICAgICAgLy9yYW5nZS5lbmQgPSByYW5nZS5zdGFydCArMTsgICAgICAgICAgXG4gICAgICAgICAgICBmaWdtYS5jdXJyZW50UGFnZS5zZWxlY3RlZFRleHRSYW5nZSA9IHtcbiAgICAgICAgICAgICAgICBub2RlOiByYW5nZS5ub2RlLFxuICAgICAgICAgICAgICAgIHN0YXJ0OiByYW5nZS5zdGFydCArIGFkZGVkU3RyaW5nLmxlbmd0aCArIDEsXG4gICAgICAgICAgICAgICAgZW5kOiByYW5nZS5zdGFydCArIGFkZGVkU3RyaW5nLmxlbmd0aCArIDFcbiAgICAgICAgICAgIH07XG4gICAgICAgIH0pO1xuICAgICAgICAvLyBcblxuICAgIH1cbn1cblxuIiwiaW1wb3J0IHtcbiAgUHJlc2VudGF0aW9uTm9kZVxufSBmcm9tIFwiLi4vY29tbW9uL3R5cGVzXCJcblxuaW1wb3J0IHt9IGZyb20gJ0BmaWdtYS9wbHVnaW4tdHlwaW5ncydcblxuZXhwb3J0IHtcbiAgTGF0ZXhQbHVnaW5TZXR0aW5ncyxcbiAgV2luZG93TW9kZSxcbiAgTGF0ZXhTdGF0ZSxcbiAgTGF0ZXhpdERhdGEsXG59XG5cblxuXG5cbi8vdGhlc2UgYXJlIHRoZSBzZXR0aW5ncyBmb3IgdGhlIGxhdGV4IHBhcnRlIG9mIHRoZSBwbHVnaW4sIGkuZS4gXCJtYXRlbWF0eWtcIiwgdGhhdCBhcmUgc3RvcmVkIGluIHRoZSBnbG9iYWwgcGx1Z2luIGRhdGFcbnR5cGUgTGF0ZXhQbHVnaW5TZXR0aW5ncyA9IHtcbiAgbWF0aEZvbnRTaXplOiBudW1iZXIsXG4gIG1hdGhGb250OiBGb250TmFtZSxcbiAgYWN0aXZlOiBib29sZWFuLFxuICB3b3Jkczogc3RyaW5nW10sXG4gIHNlcnZlclVSTCA6IHN0cmluZyxcbiAgbGF0ZXhpdFVSTCA6IHN0cmluZ1xufVxuXG4vL3RoZSBwb3NzaWJsZSBtb2RlcyBmb3IgdGhlIHBsdWdpblxuZW51bSBXaW5kb3dNb2RlIHtcbiAgU2V0dGluZ3MsXG4gIFNsaWRlLFxuICBOb1NsaWRlXG59XG5cbi8vdGhlIHBvc3NpYmxlIG1vZGUgb2YgdGhlIGxhdGV4IHBsdWdpblxuZW51bSBMYXRleFN0YXRlIHtcbiAgTm9uZSxcbiAgTGF0ZXgsXG4gIERlbGF0ZXhcbn1cblxuLy90aGlzIGlzIHRoZSBkYXRhIHN0b3JlZCBpbiBhIG5vZGUgYWZ0ZXIgaXQgaGFzIGJlZW4gbGF0ZXhlZFxudHlwZSBMYXRleGl0RGF0YSA9IHtcbiAgZm9udHNpemU6IG51bWJlcixcbiAgY29kZTogc3RyaW5nXG59XG4iLCJcbmV4cG9ydCB7XG4gICAgdXBncmFkZVZlcnNpb25cbn1cbmltcG9ydCB7IH0gZnJvbSAnQGZpZ21hL3BsdWdpbi10eXBpbmdzJ1xuXG5pbXBvcnQge1xuICAgIGFsbFNsaWRlcyxcbiAgICBsb2FkQ3VycmVudERhdGEsXG4gICAgc2F2ZUN1cnJlbnREYXRhLFxuICAgIHN0YXRlXG59IGZyb20gJy4vY29kZSdcblxuXG4vLyBpbXBvcnQgeyB2ZXJzaW9uIGFzIHZlcnNpb25OdW1iZXIgfSBmcm9tICcuLi8uLi8vcGFja2FnZS5qc29uJztcblxuXG5cblxuLy90aGlzIGZ1bmN0aW9uIHVwZ3JhZGVzIHRoZSBkYXRhIHRvIHRoZSBjdXJyZW50IHZlcnNpb24gb2YgdGhlIHBsdWdpbi4gSSBleHBlY3QgdGhlIGZ1bmN0aW9uIHRvIGdyb3cgaW50byBhIHRvdGFsIG1lc3MuXG4vLyBjdXJyZW50bHkgdGhlIHZlcnNpb24gcHJvZ3Jlc3Npb24gaXMgXG4vLyBlbXB0eTogb3JpZ2luYWwgdmVyc2lvblxuLy8gMC44MTogdGhlIGlkJ3MgYXJlIG5vdCBmcm9tIGZpZ21hLCBhbmQgdGhlcmUgaXMgYSBtZXJnZWQgcHJvcGVydHkgZm9yIGV2ZW50c1xuXG5mdW5jdGlvbiB1cGdyYWRlVmVyc2lvbigpOiB2b2lkIHtcblxuXG4gICAgY29uc3Qgc3RvcmVkVmVyc2lvbiA9IHBhcnNlRmxvYXQoZmlnbWEucm9vdC5nZXRQbHVnaW5EYXRhKCd2ZXJzaW9uJykpO1xuXG4gICAgLypcbiAgICAvL3dlIHVwZ3JhZGUgaW5jcmVtZW50YWxseSwgdmVyc2lvbiBhZnRlciB2ZXJzaW9uXG4gICAgaWYgKHN0b3JlZFZlcnNpb24gPT0gJycpIHtcbiAgICAgICAgZm9yIChjb25zdCBzbGlkZSBvZiBhbGxTbGlkZXMoKSkge1xuICAgICAgICAgICAgLy9pbiBvbGQgdmVyc2lvbnMsIHRoZSBtZXJnZWQgYXR0cmlidXRlIGRpZCBub3QgZXhpc3RcbiAgICAgICAgICAgIGNvbnN0IGRhdGFiYXNlIDpEYXRhYmFzZSA9IGdldERhdGFiYXNlKHNsaWRlKTtcbiAgICAgICAgICAgIGZvciAoY29uc3QgZXZlbnQgb2YgZGF0YWJhc2UuZXZlbnRzKSB7XG4gICAgICAgICAgICAgICAgaWYgKGV2ZW50Lm1lcmdlZCA9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgZXZlbnQubWVyZ2VkID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBmb3IgKGNvbnN0IGV2ZW50IG9mIGRhdGFiYXNlLmV2ZW50cykge1xuICAgICAgICAgICAgICAgIGZvciAoY29uc3QgY2hpbGQgb2Ygc2xpZGUuY2hpbGRyZW4pIFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGV2ZW50LmlkID09IGNoaWxkLmlkKVxuICAgICAgICAgICAgICAgICAgICAgICAgY2hpbGQuc2V0UGx1Z2luRGF0YSgnaWQnLGV2ZW50LmlkKVxuXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgIH1cbiAgICAgICAgY29uc29sZS5sb2coJ1VwZ3JhZGVkIHRvIHNsYWpkb21hdCBkYXRhIHZlcnNpb24gMC44MScpO1xuICAgICAgICBmaWdtYS5yb290LnNldFBsdWdpbkRhdGEoJ3ZlcnNpb24nLCAnMC44MScpO1xuICAgIH1cbiAgICAqL1xuXG4gICAgaWYgKHN0b3JlZFZlcnNpb24gPCAwLjg4KSB7XG4gICAgICAgIC8vYmVmb3JlIHRoaXMgdmVyc2lvbiwgdGhlcmUgd2FzIG5vIGV2ZW50SWQgYXR0cmlidXRlXG4gICAgICAgIGNvbnN0IHNhdmVkU2xpZGUgPSBzdGF0ZS5jdXJyZW50U2xpZGU7XG4gICAgICAgIGZvciAoY29uc3Qgc2xpZGUgb2YgYWxsU2xpZGVzKCkpIHtcbiAgICAgICAgICAgIC8vaW4gb2xkIHZlcnNpb25zLCB0aGUgZXZlbnRJZCBhdHRyaWJ1dGUgZGlkIG5vdCBleGlzdFxuICAgICAgICAgICAgbG9hZEN1cnJlbnREYXRhKHNsaWRlKTtcbiAgICAgICAgICAgIGxldCBpID0gLTE7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IGV2ZW50IG9mIHN0YXRlLmRhdGFiYXNlLmV2ZW50cykge1xuICAgICAgICAgICAgICAgIGkrKztcbiAgICAgICAgICAgICAgICBldmVudC5ldmVudElkID0gaS50b1N0cmluZygpO1xuXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBzdGF0ZS5jdXJyZW50U2xpZGUuc2V0UGx1Z2luRGF0YSgnZXZlbnRJZCcsIGkudG9TdHJpbmcoKSk7XG4gICAgICAgICAgICBzYXZlQ3VycmVudERhdGEoKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoc2F2ZWRTbGlkZSA9PSBudWxsKVxuICAgICAgICAgICAgY29uc29sZS5sb2coJ2l0IHdhcyBudWxsJylcbiAgICAgICAgZWxzZVxuICAgICAgICAgICAgbG9hZEN1cnJlbnREYXRhKHNhdmVkU2xpZGUpO1xuICAgICAgICBjb25zb2xlLmxvZygnVXBncmFkZWQgdG8gc2xhamRvbWF0IGRhdGEgdmVyc2lvbiAwLjg4Jyk7XG4gICAgICAgIGZpZ21hLnJvb3Quc2V0UGx1Z2luRGF0YSgndmVyc2lvbicsICcwLjg4Jyk7XG4gICAgfVxuXG59IiwiLy8gVGhlIG1vZHVsZSBjYWNoZVxudmFyIF9fd2VicGFja19tb2R1bGVfY2FjaGVfXyA9IHt9O1xuXG4vLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcblx0dmFyIGNhY2hlZE1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF07XG5cdGlmIChjYWNoZWRNb2R1bGUgIT09IHVuZGVmaW5lZCkge1xuXHRcdHJldHVybiBjYWNoZWRNb2R1bGUuZXhwb3J0cztcblx0fVxuXHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuXHR2YXIgbW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXSA9IHtcblx0XHQvLyBubyBtb2R1bGUuaWQgbmVlZGVkXG5cdFx0Ly8gbm8gbW9kdWxlLmxvYWRlZCBuZWVkZWRcblx0XHRleHBvcnRzOiB7fVxuXHR9O1xuXG5cdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuXHRfX3dlYnBhY2tfbW9kdWxlc19fW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuXHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuXHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG59XG5cbiIsIiIsIi8vIHN0YXJ0dXBcbi8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuLy8gVGhpcyBlbnRyeSBtb2R1bGUgaXMgcmVmZXJlbmNlZCBieSBvdGhlciBtb2R1bGVzIHNvIGl0IGNhbid0IGJlIGlubGluZWRcbnZhciBfX3dlYnBhY2tfZXhwb3J0c19fID0gX193ZWJwYWNrX3JlcXVpcmVfXyhcIi4vc3JjL3BsdWdpbi9jb2RlLnRzXCIpO1xuIiwiIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9